﻿#pragma once

#include <atldbcli.h>

#include "Typedefs.h"

#include "BaseTable.h"

class CCitiesAccessor
{
protected:
	CITIES m_recCity;

	BEGIN_ACCESSOR_MAP(CCitiesAccessor, ACCESSOR_COUNT)
		BEGIN_ACCESSOR(FIRST_ACCESSOR, true)
			COLUMN_ENTRY(FIRST_COLUMN, m_recCity.lID)
		END_ACCESSOR()

		BEGIN_ACCESSOR(FIRST_COLUMN, true)
			COLUMN_ENTRY(SECOND_COLUMN, m_recCity.lUpdateCounter)
			COLUMN_ENTRY(THIRD_COLUMN, m_recCity.szCityName)
			COLUMN_ENTRY(FOURTH_COLUMN, m_recCity.szRegion)
		END_ACCESSOR()
	END_ACCESSOR_MAP()
};

///<summary>Клас за работа с таблица CITIES</summary>
class CCitiesTable : public CBaseTable<CCitiesAccessor, CITIES>
{
public:
	CCitiesTable(CString strTableName, CSession* oSession);
private:
	virtual CITIES& GetRowSet() override;
	virtual void SetRowSetValue(CITIES recCity) override;
	virtual long GetUpdateCounter(CITIES recCity) override;
	virtual void IncrementUpdateCounter(CITIES& recCity) override;
};