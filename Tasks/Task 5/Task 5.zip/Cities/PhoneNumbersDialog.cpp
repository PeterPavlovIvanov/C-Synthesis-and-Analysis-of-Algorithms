// PhoneNumbersDialog.cpp : implementation file
//

#include "stdafx.h"
#include "PhoneBook.h"
#include "PhoneNumbersDialog.h"
#include "afxdialogex.h"


// CPhoneNumbersDialog dialog

IMPLEMENT_DYNAMIC(CPhoneNumbersDialog, CDialog)

CPhoneNumbersDialog::CPhoneNumbersDialog(CWnd* pParent /*=NULL*/)
	: CDialog(IDD_DIALOG4, pParent)
{

}

CPhoneNumbersDialog::~CPhoneNumbersDialog()
{
}

void CPhoneNumbersDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT1, editNumber);
	DDX_Control(pDX, IDC_COMBO1, comboPhoneType);
}


BEGIN_MESSAGE_MAP(CPhoneNumbersDialog, CDialog)
END_MESSAGE_MAP()


// CPhoneNumbersDialog message handlers
