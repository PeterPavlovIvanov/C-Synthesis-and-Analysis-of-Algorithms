#pragma once

#include "Typedefs.h"

class CNumbersPerson
{
	//Constructors
public:
	CNumbersPerson(PERSONS recPerson);
	CNumbersPerson();

	//Methods
public:

	//Members
public:
	PERSONS recPerson;
	CPhoneNumbersArray oPhoneNumbersArray;
};