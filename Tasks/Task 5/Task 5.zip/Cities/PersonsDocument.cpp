// PersonsDocument.cpp : implementation file
//

#include "stdafx.h"

#include "PhoneBook.h"

#include "PersonsDocument.h"

// CPersonsDocument

IMPLEMENT_DYNCREATE(CPersonsDocument, CDocument)

CPersonsDocument::CPersonsDocument()
{
};

BOOL CPersonsDocument::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;
	return TRUE;
};

CPersonsDocument::~CPersonsDocument()
{
};

void CPersonsDocument::OnUpdateAllViews(UpdateCodes eUpdateCode, PERSONS recPerson)
{
	UpdateAllViews(NULL, eUpdateCode, (CObject*)&recPerson);
};

BOOL CPersonsDocument::SelectAllCities(CCitiesArray & oCitiesArray)
{
	return m_oCitiesData.SelectAll(oCitiesArray);
};

BOOL CPersonsDocument::SelectAll()
{
    return m_oPersonsData.SelectAll(m_oPersonsArray);
};

BOOL CPersonsDocument::InsertPerson(PERSONS & recPersons)
{
	BOOL bResult = m_oPersonsData.Insert(recPersons);

	if (bResult != TRUE)
	{
		return FALSE;
	}

	PERSONS* pPerson = new PERSONS();
	pPerson->lID = recPersons.lID;
	pPerson->lCityID = recPersons.lCityID;
	pPerson->lUpdateCounter = recPersons.lUpdateCounter;
	wcscpy_s(pPerson->szFirstName, recPersons.szFirstName);
	wcscpy_s(pPerson->szMiddleName, recPersons.szMiddleName);
	wcscpy_s(pPerson->szLastName, recPersons.szLastName);
	wcscpy_s(pPerson->szUCN, recPersons.szUCN);
	wcscpy_s(pPerson->szAddress, recPersons.szAddress);
	m_oPersonsArray.Add(pPerson);

	UpdateCodes eUpdateCode = UpdateCodeInsert;
	OnUpdateAllViews(eUpdateCode, recPersons);
	return bResult;
};

BOOL CPersonsDocument::DeleteByID(int nID)
{
	BOOL bResult = m_oPersonsData.DeleteWhereID(nID);

	if (bResult != TRUE)
	{
		return FALSE;
	}

	for (int i = 0; i < m_oPersonsArray.GetCount(); i++)
	{
		if (m_oPersonsArray.GetAt(i)->lID == nID)
		{
			delete m_oPersonsArray.GetAt(i);
		}
	}

	PERSONS recPerson;
	recPerson.lID = nID;

	UpdateCodes eUpdateCode = UpdateCodeDelete;
	OnUpdateAllViews(eUpdateCode, recPerson);
	return bResult;
};

BOOL CPersonsDocument::UpdatePerson(const PERSONS& recPerson)
{
	BOOL bResult = m_oPersonsData.Update(recPerson);

	if (bResult != TRUE)
	{
		return FALSE;
	}

	for (int i = 0; i < m_oPersonsArray.GetCount(); i++)
	{
		if (m_oPersonsArray.GetAt(i)->lID == recPerson.lID)
		{
			m_oPersonsArray.GetAt(i)->lID = recPerson.lID;
			m_oPersonsArray.GetAt(i)->lCityID = recPerson.lCityID;
			m_oPersonsArray.GetAt(i)->lUpdateCounter = recPerson.lUpdateCounter;
			wcscpy_s(m_oPersonsArray.GetAt(i)->szFirstName, recPerson.szFirstName);
			wcscpy_s(m_oPersonsArray.GetAt(i)->szMiddleName, recPerson.szMiddleName);
			wcscpy_s(m_oPersonsArray.GetAt(i)->szLastName, recPerson.szLastName);
			wcscpy_s(m_oPersonsArray.GetAt(i)->szUCN, recPerson.szUCN);
			wcscpy_s(m_oPersonsArray.GetAt(i)->szAddress, recPerson.szAddress);
			break;
		}
	}

	UpdateCodes eUpdateCode = UpdateCodeUpdate;
	OnUpdateAllViews(eUpdateCode, recPerson);
	return bResult;
};

BOOL CPersonsDocument::SelectByID(int nID, CNumbersPerson& oNumbersPerson)
{
	return m_oPersonsData.SelectWhereID(nID, oNumbersPerson);
};

BEGIN_MESSAGE_MAP(CPersonsDocument, CDocument)
END_MESSAGE_MAP()


// CPersonsDocument diagnostics

#ifdef _DEBUG
void CPersonsDocument::AssertValid() const
{
	CDocument::AssertValid();
}

#ifndef _WIN32_WCE
void CPersonsDocument::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif
#endif //_DEBUG

#ifndef _WIN32_WCE
// CPersonsDocument serialization

void CPersonsDocument::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}
#endif


// CPersonsDocument commands
