// PersonsDialog.cpp : implementation file
//

#include "stdafx.h"

#include "PhoneBook.h"

#include "PersonsDialog.h"

#include "afxdialogex.h"

// CPersonsDialog dialog

IMPLEMENT_DYNAMIC(CPersonsDialog, CDialog)

CPersonsDialog::CPersonsDialog(PERSONS & recPerson, CCitiesArray& oCitiesArray, DialogModes eDialogMode, CWnd* pParent /*=NULL*/)
	: CDialog(IDD_DIALOG3, pParent), m_recPerson(recPerson), m_oCitiesArray(oCitiesArray)
{
	switch (eDialogMode)
	{
	case DialogModeUpdate:
		m_strDlgCaption = _T("Update Person");
		break;
	case DialogModeDelete:
		m_strDlgCaption = _T("Are you sure you want to delete this Person?");
		break;
	case DialogModeView:
		m_strDlgCaption = _T("View Person");
		break;
	case DialogModeInsert:
		m_strDlgCaption = _T("Insert Person");
		break;
	};

	m_eDialogMode = eDialogMode;
	m_recPerson = recPerson;
	//for (int i = 0; i < oCitiesArray.GetCount(); i++)
	//{
	//	m_oCitiesArray.Add(oCitiesArray.GetAt(i));
	//}
};

CPersonsDialog::~CPersonsDialog()
{
};

void CPersonsDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_PERSONS_FIRST_NAME, editFirstName);
	DDX_Control(pDX, IDC_EDIT_PERSONS_MIDDLE_NAME, editMiddleName);
	DDX_Control(pDX, IDC_EDIT_PERSONS_LAST_NAME, editLastName);
	DDX_Control(pDX, IDC_EDIT_PERSONS_UCN, editUCN);
	DDX_Control(pDX, IDC_COMBO_PERSONS_CITY, comboCity);
	DDX_Control(pDX, IDC_EDIT_PERSONS_ADDRESS, editAddress);
	DDX_Control(pDX, IDC_LIST_PERSONS_NUMBERS, listCtrlPhoneNumbers);
};

void CPersonsDialog::DialogToBuf()
{
	CString strWindowText;

	editFirstName.GetWindowText(strWindowText);
	wcscpy_s(m_recPerson.szFirstName, strWindowText);

	editMiddleName.GetWindowText(strWindowText);
	wcscpy_s(m_recPerson.szMiddleName, strWindowText);

	editLastName.GetWindowText(strWindowText);
	wcscpy_s(m_recPerson.szLastName, strWindowText);

	editUCN.GetWindowText(strWindowText);
	wcscpy_s(m_recPerson.szUCN, strWindowText);

	editAddress.GetWindowText(strWindowText);
	wcscpy_s(m_recPerson.szAddress, strWindowText);

};

BOOL CPersonsDialog::OnInitDialog()
{
	__super::OnInitDialog();
	SetWindowText(m_strDlgCaption);
	if (m_eDialogMode == DialogModes::DialogModeView || m_eDialogMode == DialogModes::DialogModeDelete)
	{
		editAddress.SetReadOnly();
		editLastName.SetReadOnly();
		editMiddleName.SetReadOnly();
		editFirstName.SetReadOnly();
		editAddress.SetReadOnly();
		//comboCity.
		//listCtrlPhoneNumbers.
	}
	SetDlgItemText(IDC_EDIT_PERSONS_FIRST_NAME, m_recPerson.szFirstName);
	SetDlgItemText(IDC_EDIT_PERSONS_LAST_NAME, m_recPerson.szLastName);
	SetDlgItemText(IDC_EDIT_PERSONS_MIDDLE_NAME, m_recPerson.szMiddleName);
	SetDlgItemText(IDC_EDIT_PERSONS_ADDRESS, m_recPerson.szAddress);
	SetDlgItemText(IDC_EDIT_PERSONS_UCN, m_recPerson.szUCN);
	//comboCity
	//listCtrlPhoneNumbers
	return TRUE;
};

BEGIN_MESSAGE_MAP(CPersonsDialog, CDialog)
	ON_BN_CLICKED(IDOK, &CPersonsDialog::OnBnClickedOk)
END_MESSAGE_MAP()


// CPersonsDialog message handlers


void CPersonsDialog::OnBnClickedOk()
{
	DialogToBuf();
	CDialog::OnOK();
}
