#pragma once


// ContextMenu

class CContextMenu : public CWnd
{
	DECLARE_DYNAMIC(CContextMenu)

public:
	CContextMenu();
	virtual ~CContextMenu();

protected:
	DECLARE_MESSAGE_MAP()
};


