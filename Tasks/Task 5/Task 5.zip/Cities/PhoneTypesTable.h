﻿#pragma once

#include "BaseTable.h"

class CPhoneTypesAccessor
{
protected:
	PHONE_TYPES m_recPhoneType;

	BEGIN_ACCESSOR_MAP(CPhoneTypesAccessor, ACCESSOR_COUNT)
		BEGIN_ACCESSOR(FIRST_ACCESSOR, true)
		COLUMN_ENTRY(FIRST_COLUMN, m_recPhoneType.lID)
		END_ACCESSOR()

		BEGIN_ACCESSOR(FIRST_COLUMN, true)
		COLUMN_ENTRY(SECOND_COLUMN, m_recPhoneType.lUpdateCounter)
		COLUMN_ENTRY(THIRD_COLUMN, m_recPhoneType.szPhoneType)
		END_ACCESSOR()
	END_ACCESSOR_MAP()
};

///<summary>Клас за работа с таблица PHONE_TYPES</summary>
class CPhoneTypesTable : public CBaseTable<CPhoneTypesAccessor, PHONE_TYPES>
{
public:
	CPhoneTypesTable(CString strTableName, CSession oSession);
private:
	virtual PHONE_TYPES& GetRowSet() override;
	virtual void SetRowSetValue(PHONE_TYPES recPhoneType) override;
	virtual long GetUpdateCounter(PHONE_TYPES recPhoneType) override;
	virtual void IncrementUpdateCounter(PHONE_TYPES& recPhoneType) override;
};