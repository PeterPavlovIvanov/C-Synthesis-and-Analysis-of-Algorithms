﻿#pragma once

#include "BaseTable.h"

class CPersonsAccessor
{
protected:
	PERSONS m_recPerson;

	BEGIN_ACCESSOR_MAP(CPersonsAccessor, ACCESSOR_COUNT)
		BEGIN_ACCESSOR(FIRST_ACCESSOR, true)
		COLUMN_ENTRY(FIRST_COLUMN, m_recPerson.lID)
		END_ACCESSOR()

		BEGIN_ACCESSOR(FIRST_COLUMN, true)
		COLUMN_ENTRY(SECOND_COLUMN, m_recPerson.lUpdateCounter)
		COLUMN_ENTRY(THIRD_COLUMN, m_recPerson.szFirstName)
		COLUMN_ENTRY(FOURTH_COLUMN, m_recPerson.szMiddleName)
		COLUMN_ENTRY(FIFTH_COLUMN, m_recPerson.szLastName)
		COLUMN_ENTRY(SIXTH_COLUMN, m_recPerson.szUCN)
		COLUMN_ENTRY(SEVENTH_COLUMN, m_recPerson.lCityID)
		COLUMN_ENTRY(EIGHT_COLUMN, m_recPerson.szAddress)

		END_ACCESSOR()
	END_ACCESSOR_MAP()
};

///<summary>Клас за работа с таблица PERSONS</summary>
class CPersonsTable : public CBaseTable<CPersonsAccessor, PERSONS>
{
public:
	CPersonsTable(CString strTableName, CSession* oSession);
private:
	virtual PERSONS& GetRowSet() override;
	virtual void SetRowSetValue(PERSONS recPerson);
	virtual long GetUpdateCounter(PERSONS recPerson) override;
	virtual void IncrementUpdateCounter(PERSONS& recPerson) override;
};