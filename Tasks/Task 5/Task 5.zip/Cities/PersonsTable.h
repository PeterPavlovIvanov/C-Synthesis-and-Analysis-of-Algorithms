﻿#pragma once

#include "BaseTable.h"

class CPersonsAccessor
{
protected:
	PERSONS m_recPerson;

	BEGIN_ACCESSOR_MAP(CPersonsAccessor, ACCESSOR_COUNT)
		BEGIN_ACCESSOR(FIRST_ACCESSOR, true)
		COLUMN_ENTRY(FIRST_COLUMN, m_recPerson.lID)
		END_ACCESSOR()

		BEGIN_ACCESSOR(FIRST_COLUMN, true)
		COLUMN_ENTRY(SECOND_COLUMN, m_recPerson.lUpdateCounter)
		COLUMN_ENTRY(THIRD_COLUMN, m_recPerson.szFirstName)
		COLUMN_ENTRY(FOURTH_COLUMN, m_recPerson.szMiddleName)
		COLUMN_ENTRY(FIFTH_COLUMN, m_recPerson.szLastName)
		COLUMN_ENTRY(SIXTH_COLUMN, m_recPerson.szUCN)
		COLUMN_ENTRY(SEVENTH_COLUMN, m_recPerson.lCityID)
		COLUMN_ENTRY(EIGHT_COLUMN, m_recPerson.szAddress)

		END_ACCESSOR()
	END_ACCESSOR_MAP()
};

///<summary>Клас за работа с таблица PERSONS</summary>
class CPersonsTable : public CBaseTable<CPersonsAccessor, PERSONS>
{
	//Constructors
public:
	///<summary>Конструктор по име на таблицата и сесия</summary>
	CPersonsTable(CString strTableName, CSession* oSession);

	//Methods
private:
	///<summary>Взима rowset-а</summary>
	virtual PERSONS& GetRowSet() override;

	///<summary>Задава стойност на rowset-а</summary>
	///<param "recPerson">Стойност за задаване</summary>
	virtual void SetRowSetValue(PERSONS recPerson);

	///<summary>Взима update_counter-а на абонат</summary>
	///<param "recPerson">Абоната от който се взима uprade_counter-с</summary>
	virtual long GetUpdateCounter(PERSONS recPerson) override;

	///<summary>Увеличава update_counter-а на абонат с едно</summary>
	///<param "recPerson">Абоната на който се увеличава uprade_counter-с</summary>
	virtual void IncrementUpdateCounter(PERSONS& recPerson) override;
};