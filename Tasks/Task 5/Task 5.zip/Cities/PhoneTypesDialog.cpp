// PhoneTypeDialog.cpp : implementation file
//

#include "stdafx.h"
#include "PhoneBook.h"
#include "PhoneTypesDialog.h"
#include "afxdialogex.h"


// CPhoneTypesDialog dialog

IMPLEMENT_DYNAMIC(CPhoneTypesDialog, CDialog)

CPhoneTypesDialog::CPhoneTypesDialog(CString m_strDlgCaption, PHONE_TYPES recPhoneType, CWnd* pParent /*=NULL*/)
	: CDialog(IDD_DIALOG2, pParent)
{
	SetRecPhoneType(recPhoneType);
	this->m_strDlgCaption = m_strDlgCaption;
}

CPhoneTypesDialog::~CPhoneTypesDialog()
{
};

void CPhoneTypesDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDB_PHONE_TYPES_NAME, editPhoneType);
	DDX_Control(pDX, IDC_EDIT1, editPhoneType);
}

BOOL CPhoneTypesDialog::OnInitDialog()
{
	__super::OnInitDialog();
	SetWindowText(m_strDlgCaption);
	SetDlgItemText(IDC_EDB_PHONE_TYPES_NAME, recPhoneType.szPhoneType);
	return TRUE;
};

BEGIN_MESSAGE_MAP(CPhoneTypesDialog, CDialog)
	ON_BN_CLICKED(IDOK, &CPhoneTypesDialog::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &CPhoneTypesDialog::OnBnClickedCancel)
END_MESSAGE_MAP()


// CPhoneTypesDialog message handlers

void CPhoneTypesDialog::OnBnClickedOk()
{
	AddToFields();
	CDialog::OnOK();
};

void CPhoneTypesDialog::OnBnClickedCancel()
{
	CleanFields();
	CDialog::OnCancel();
};

void CPhoneTypesDialog::CleanFields()
{
	recPhoneType.lID = -1;
	recPhoneType.lUpdateCounter = -1;
	wcscpy_s(recPhoneType.szPhoneType, _T(""));
};

void CPhoneTypesDialog::AddToFields()
{
	CString strWindowText;

	editPhoneType.GetWindowText(strWindowText);
	wcscpy_s(recPhoneType.szPhoneType, strWindowText);
}

void CPhoneTypesDialog::SetRecPhoneType(PHONE_TYPES recPhoneType)
{
	this->recPhoneType = recPhoneType;
}