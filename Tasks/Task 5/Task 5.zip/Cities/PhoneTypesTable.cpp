#include "stdafx.h"

#include <atlbase.h>

#include <atldbcli.h>

#include <atldbsch.h>

#include "Typedefs.h"

#include "PhoneTypesTable.h"

CPhoneTypesTable::CPhoneTypesTable(CString strTableName, CSession* oSession) 
	: CBaseTable(strTableName, oSession)
{
};

PHONE_TYPES & CPhoneTypesTable::GetRowSet()
{
	return m_recPhoneType;
};

void CPhoneTypesTable::SetRowSetValue(PHONE_TYPES recPhoneType)
{
	m_recPhoneType = recPhoneType;
};

long CPhoneTypesTable::GetUpdateCounter(PHONE_TYPES recPhoneType)
{
	return recPhoneType.lUpdateCounter;
};

void CPhoneTypesTable::IncrementUpdateCounter(PHONE_TYPES & recPhoneType)
{
	recPhoneType.lUpdateCounter += 1;
};
