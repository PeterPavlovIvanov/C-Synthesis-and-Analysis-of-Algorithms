﻿#pragma once

#include "Typedefs.h"

#include "PhoneTypesData.h"

#include "UpdateCodes.h"

/////////////////////////////////////////////////////////////////////////////
// CPhoneTypesDocument

class CPhoneTypesDocument : public CDocument
{
	DECLARE_DYNCREATE(CPhoneTypesDocument)

	// Constructor / Destructor
	// ----------------
protected:
	///<summary>Default-ен конструктор</summary>
	CPhoneTypesDocument();
	virtual ~CPhoneTypesDocument();

	//Methods
	// ----------------
public:
	///<summary>Взима всички телефонни типове</summary>
	///<returns>Връща BOOL дали е упешна операцията</returns>
	BOOL SelectAll();

	///<summary>Взима телефонен тип по ID</summary>
	///<param = "nID">ID на телефонния тип</param>
	///<param = "recPhoneType">Хранилище на резултата</param>
	///<returns>Връща BOOL дали е упешна операцията</returns>
	BOOL SelectByID(int nID, PHONE_TYPES& recPhoneType);

	///<summary>Изтрива телефонен тип по ID</summary>
	///<param = "nID">ID на телефонния тип</param>
	///<returns>Връща BOOL дали е упешна операцията</returns>
	BOOL DeleteByID(int nID);

	///<summary>Променя телефонен тип</summary>
	///<param = "recPhoneType">Променения телефонен тип</param>
	///<returns>Връща BOOL дали е упешна операцията</returns>
	BOOL UpdatePhoneType(const PHONE_TYPES& recPhoneType);

	///<summary>Добавя телефонен тип</summary>
	///<param = "телефонен тип">Телефонният тип за добавяне</param>
	///<returns>Връща BOOL дали е упешна операцията</returns>
	BOOL InsertPhoneType(PHONE_TYPES& recPhoneTypes);

	///<summary>Геттър на телефонните типове</summary>
	///<returns>Връща телефонните типове</returns>
	CPhoneTypesArray& GetPhoneTypesArray()
	{
		return m_oPhoneTypesArray;
	}

	///<summary>Update-ва всички View-та</summary>
	///<param = "eUpdateCodes">Enum - информация какъв ще бъде update-а</param>
	///<param = "recPhoneType">Телефонен тип за update-ване</param>
	void OnUpdateAllViews(UpdateCodes eUpdateCode, PHONE_TYPES recPhoneType);

	//Members
	// ----------------
public:
	///<summary>Инстанция на класа за бизнес логика</summary>
	CPhoneTypesData m_oPhoneTypesData;

private:
	///<summary>Хранилище за телефонни типове - типовете във view-то</summary>
	CPhoneTypesArray m_oPhoneTypesArray;

#ifndef _WIN32_WCE
	virtual void Serialize(CArchive& ar);   // overridden for document i/o
#endif
#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif

protected:
	virtual BOOL OnNewDocument();

	DECLARE_MESSAGE_MAP()
};
