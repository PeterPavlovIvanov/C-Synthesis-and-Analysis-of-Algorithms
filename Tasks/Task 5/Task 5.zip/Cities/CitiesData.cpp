#include "stdafx.h"

#include "CitiesData.h"

#include "DBConnectionCreator.h"

CCitiesData::CCitiesData()
{
};

BOOL CCitiesData::SelectAll(CCitiesArray& oCitiesArray)
{
	CSession oSession;
	CString strTableName;
	strTableName.Format(_T("CITIES"));

	if (FAILED(oSession.Open(CDBConnectionCreator::GetInstance().GetDataSource())))
		return FALSE;

	CCitiesTable oCitiesTable(strTableName, &oSession);

	BOOL hResult = oCitiesTable.SelectAll(oCitiesArray);

	oSession.Close();
	return hResult;
};

BOOL CCitiesData::Insert(CITIES& recCities) {
	CSession oSession;
	CString strTableName;
	strTableName.Format(_T("CITIES"));

	if (FAILED(oSession.Open(CDBConnectionCreator::GetInstance().GetDataSource())))
		return FALSE;

	CCitiesTable oCitiesTable(strTableName, &oSession);

	BOOL hResult = oCitiesTable.Insert(recCities);

	oSession.Close();
	return hResult;
};

BOOL CCitiesData::DeleteWhereID(int nID)
{
	CSession oSession;
	CString strTableName;
	strTableName.Format(_T("CITIES"));

	if (FAILED(oSession.Open(CDBConnectionCreator::GetInstance().GetDataSource())))
		return FALSE;

	CCitiesTable oCitiesTable(strTableName, &oSession);

	BOOL hResult = oCitiesTable.DeleteWhereID(nID);

	oSession.Close();
	return hResult;
};

BOOL CCitiesData::Update(const CITIES & recCity)
{
	CSession oSession;
	CString strTableName;
	strTableName.Format(_T("CITIES"));

	if (FAILED(oSession.Open(CDBConnectionCreator::GetInstance().GetDataSource())))
		return FALSE;

	CCitiesTable oCitiesTable(strTableName, &oSession);

	BOOL hResult = oCitiesTable.UpdateWhereID(recCity.lID, recCity);

	oSession.Close();
	return hResult;
};

BOOL CCitiesData::SelectWhereID(int nID, CITIES& recCity)
{
	CSession oSession;
	CString strTableName;
	strTableName.Format(_T("CITIES"));

	if (FAILED(oSession.Open(CDBConnectionCreator::GetInstance().GetDataSource())))
		return FALSE;

	CCitiesTable oCitiesTable(strTableName, &oSession);

	BOOL hResult = oCitiesTable.SelectWhereID(nID, recCity);

	oSession.Close();
	return hResult;
};