#include "stdafx.h"

#include "PersonsData.h"

#include "DBConnectionCreator.h"

#include "PhoneNumbersTable.h"

CPersonsData::CPersonsData()
{
};

BOOL CPersonsData::SelectAll(CPersonsArray& oPersonsArray)
{
	CSession oSession;
	CString strTableName;
	strTableName.Format(_T("PERSONS"));
	
	if (FAILED(oSession.Open(CDBConnectionCreator::GetInstance().GetDataSource())))
		return FALSE;

	CPersonsTable oPersonsTable(strTableName, &oSession);

	BOOL hResult = oPersonsTable.SelectAll(oPersonsArray);

	oSession.Close();
	return hResult;
};

BOOL CPersonsData::Insert(CNumbersPerson& oNumbersPerson)
{
	CSession oSession;
	CString strTableName;

	if (FAILED(oSession.Open(CDBConnectionCreator::GetInstance().GetDataSource())))
		return FALSE;

	strTableName.Format(_T("PERSONS"));
	CPersonsTable oPersonsTable(strTableName, &oSession);

	if (FAILED(oPersonsTable.Insert(oNumbersPerson.recPerson)))
		return FALSE;

	strTableName.Format(_T("PHONE_NUMBERS"));
	CPhoneNumbersTable oPhoneNumbersTable(strTableName, &oSession);

	for (int i = 0; i < oNumbersPerson.oPhoneNumbersArray.GetCount(); i++)
	{
		PHONE_NUMBERS* pPhoneNumber = oNumbersPerson.oPhoneNumbersArray.GetAt(i);
		pPhoneNumber->lPersonID = oNumbersPerson.recPerson.lID;

		if (FAILED(oPhoneNumbersTable.Insert(*pPhoneNumber)))
			return FALSE;
	}

	oSession.Close();
	return TRUE;
};

BOOL CPersonsData::DeleteWhereID(int nID)
{
	CSession oSession;
	CString strTableName;
	strTableName.Format(_T("PERSONS"));

	if (FAILED(oSession.Open(CDBConnectionCreator::GetInstance().GetDataSource())))
		return FALSE;

	CPersonsTable oPersonsTable(strTableName, &oSession);

	//todo delete first from PHONE_NUMBERS
	BOOL hResult = oPersonsTable.DeleteWhereID(nID);

	oSession.Close();
	return hResult;
};

BOOL CPersonsData::Update(const CNumbersPerson& oNumbersPerson)
{
	CSession oSession;
	CString strTableName;
	strTableName.Format(_T("PERSONS"));
	CPersonsTable oPersonsTable(strTableName, &oSession);

	if (FAILED(oSession.Open(CDBConnectionCreator::GetInstance().GetDataSource())))
		return FALSE;

	BOOL hResult = oPersonsTable.UpdateWhereID(oNumbersPerson.recPerson.lID, oNumbersPerson.recPerson);
	//todo update PHONE_NUMBERS after

	oSession.Close();
	return hResult;
};

BOOL CPersonsData::SelectWhereID(int nID, CNumbersPerson& oNumbersPerson)
{
	CSession oSession;
	CString strTableName;

	strTableName.Format(_T("PERSONS"));
	CPersonsTable oPersonsTable(strTableName, &oSession);

	strTableName.Format(_T("PHONE_NUMBERS"));
	CPhoneNumbersTable oPhoneNumbersTable(strTableName, &oSession);

	if (FAILED(oSession.Open(CDBConnectionCreator::GetInstance().GetDataSource())))
		return FALSE;

	if (FAILED(oPersonsTable.SelectWhereID(nID, oNumbersPerson.recPerson)))
		return FALSE;

	if (FAILED(oPhoneNumbersTable.SelectAllByPersonID(nID, oNumbersPerson.oPhoneNumbersArray)))
		return FALSE;

	oSession.Close();
	return TRUE;
}

BOOL CPersonsData::InsertPhoneNumber(PHONE_NUMBERS & recPhoneNumber)
{
	CSession oSession;
	CString strTableName;
	strTableName.Format(_T("PHONE_NUMBERS"));
	CPhoneNumbersTable oPhoneNumbersTable(strTableName, &oSession);

	if (FAILED(oSession.Open(CDBConnectionCreator::GetInstance().GetDataSource())))
		return FALSE;

	BOOL hResult = oPhoneNumbersTable.Insert(recPhoneNumber);

	oSession.Close();
	return hResult;
};