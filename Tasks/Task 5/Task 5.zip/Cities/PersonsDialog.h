﻿#pragma once
#include "afxwin.h"

#include "afxcmn.h"

#include "Typedefs.h"

#include "DialogModes.h"

#include "NumbersPerson.h"


// CPersonsDialog dialog

class CPersonsDialog : public CDialog
{
	DECLARE_DYNAMIC(CPersonsDialog)

	//Constructors
public:
	CPersonsDialog(CNumbersPerson& oNumbersPerson, CCitiesArray* oCitiesArray, DialogModes eDialogMode,
		CPhoneTypesArray* oPhoneTypesArray, CWnd* pParent = NULL);   

	CPersonsDialog(CNumbersPerson& oNumbersPerson, DialogModes eDialogMode, CWnd* pParent = NULL);

	virtual ~CPersonsDialog();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG3 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()

	//Methods
public:
	void OnPhoneNumbersInsert();
	void OnPhoneNumbersUpdate();
	void OnPhoneNumbersDelete();
	afx_msg void OnRclickList(NMHDR* pNMHDR, LRESULT* pResult);

	///<summary>Пълни полетата</summary>
	void DialogToBuf();

	///<summary>Задава заглавие и полетата на диалога</summary>
	///<returns>Дали операцията е упсешна</returns>
	BOOL OnInitDialog() override;

	//Members
public:
	CEdit editFirstName;
	CEdit editMiddleName;
	CEdit editLastName;
	CEdit editUCN;
	CComboBox comboCity;
	CEdit editAddress;
	CListCtrl listCtrlPhoneNumbers;

private:
	///<summary>Режим на диалога</summary>
	DialogModes m_eDialogMode;

	///<summary>Номера на абонат и абонат с които се оперира в различните методи</summary>
	CNumbersPerson& m_oNumbersPerson;

	///<summary>Градове с които се оперира в различните методи</summary>
	CCitiesArray m_oCitiesArray;

	///<summary>Името на диалога</summary>
	CString m_strDlgCaption;

	CPhoneTypesArray m_oPhoneTypesArray;
public:
	afx_msg void OnBnClickedOk();
};
