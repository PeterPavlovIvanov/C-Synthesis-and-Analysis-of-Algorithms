// PhoneTypeDialog.cpp : implementation file
//

#include "stdafx.h"
#include "PhoneBook.h"
#include "PhoneTypesDialog.h"
#include "afxdialogex.h"


// CPhoneTypesDialog dialog

IMPLEMENT_DYNAMIC(CPhoneTypesDialog, CDialog)

CPhoneTypesDialog::CPhoneTypesDialog(CString m_strDlgCaption, PHONE_TYPES& recPhoneType, CWnd* pParent /*=NULL*/)
	: CDialog(IDD_DIALOG2, pParent), m_recPhoneType(recPhoneType)
{
	m_recPhoneType = recPhoneType;
	this->m_strDlgCaption = m_strDlgCaption;
}

CPhoneTypesDialog::~CPhoneTypesDialog()
{
};

void CPhoneTypesDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDB_PHONE_TYPES_NAME, editPhoneType);
	DDX_Control(pDX, IDC_EDIT1, editPhoneType);
}

BOOL CPhoneTypesDialog::OnInitDialog()
{
	__super::OnInitDialog();
	SetWindowText(m_strDlgCaption);
	SetDlgItemText(IDC_EDB_PHONE_TYPES_NAME, m_recPhoneType.szPhoneType);
	return TRUE;
};

BEGIN_MESSAGE_MAP(CPhoneTypesDialog, CDialog)
	ON_BN_CLICKED(IDOK, &CPhoneTypesDialog::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &CPhoneTypesDialog::OnBnClickedCancel)
END_MESSAGE_MAP()


// CPhoneTypesDialog message handlers

void CPhoneTypesDialog::OnBnClickedOk()
{
	DialogToBuf();
	CDialog::OnOK();
};

void CPhoneTypesDialog::OnBnClickedCancel()
{
	CDialog::OnCancel();
};

void CPhoneTypesDialog::CleanFields()
{
	m_recPhoneType.lID = -1;
	m_recPhoneType.lUpdateCounter = -1;
	wcscpy_s(m_recPhoneType.szPhoneType, _T(""));
};

void CPhoneTypesDialog::DialogToBuf()
{
	CString strWindowText;

	editPhoneType.GetWindowText(strWindowText);
	wcscpy_s(m_recPhoneType.szPhoneType, strWindowText);
};