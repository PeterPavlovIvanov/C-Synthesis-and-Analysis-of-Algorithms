﻿#include "stdafx.h"

#include <atlbase.h>

#include <atldbcli.h>

#include <atldbsch.h>

#include <typeinfo>

#include "Typedefs.h"

#include "CitiesTable.h"

#include "PropertiesConnectionDB.h"

#include "DBConnectionCreator.h"

CCitiesTable::CCitiesTable()
{
};

BOOL CCitiesTable::ExecuteQuery(CString strQuery)
{
	HRESULT hResult;
	CDBPropSet pPropSet(DBPROPSET_ROWSET);
	CPropertiesConnectionDB oPropConDB;
	oPropConDB.SetPropertiesRows(pPropSet);

	hResult = Open(m_oSession, strQuery, &pPropSet);

	if (FAILED(hResult))
	{
		return FALSE;
	}
	return TRUE;
};

BOOL CCitiesTable::SelectByID(const long lID, CITIES& recCities)
{
	CString strQuery;
	strQuery.Format(_T("SELECT * FROM CITIES WHERE ID = %d"), lID);

	if (FAILED(ExecuteQuery(strQuery)))
	{
		return FALSE;
	}

	if (MoveNext() == S_OK)
	{
		recCities = m_recCity;
	}
	else
	{
		return FALSE;
	}
	return TRUE;
}

BOOL CCitiesTable::SelectAll(CCitiesArray& oCitiesArray)
{
	m_oSession.Open(CDBConnectionCreator::GetInstance().GetDataSource());
	HRESULT hResult;
	CString strQuery;

	strQuery = _T("SELECT * FROM CITIES");

	if (FAILED(ExecuteQuery(strQuery)))
	{
		return FALSE;
	}

	while (true)
	{
		hResult = MoveNext();
		if (hResult == S_OK)
		{
			CITIES* pCity = new CITIES();
			*pCity = m_recCity;

			oCitiesArray.Add(pCity);
		}
		else if (hResult == DB_S_ENDOFROWSET)
		{
			break;
		}
		else
		{
			return FALSE;
		}
	}

	CloseCommandSessionConnection();
	return TRUE;
};

BOOL CCitiesTable::SelectWhereID(const long lID, CITIES& recCities)
{
	m_oSession.Open(CDBConnectionCreator::GetInstance().GetDataSource());
	if (FAILED(SelectByID(lID, recCities))) 
	{
		return FALSE;
	}

	CloseCommandSessionConnection();
	return TRUE;
};

BOOL CCitiesTable::UpdateWhereID(const long lID, const CITIES& recCities)
{
	m_oSession.Open(CDBConnectionCreator::GetInstance().GetDataSource());

	CITIES recCity;

	if (FAILED(m_oSession.StartTransaction()))
	{
		return FALSE;
	}

	if (FAILED(SelectByID(lID, recCity))) 
	{
		m_oSession.Abort();
		return FALSE;
	}

	if (m_recCity.lUpdateCounter != recCities.lUpdateCounter)
	{
		m_oSession.Abort();
		AfxMessageBox(_T("Session invalid, please try again."));
		CloseCommandSessionConnection();
		return FALSE;
	}

	m_recCity = recCities;
	m_recCity.lUpdateCounter += UPDATE_COUNTER_NUMBER;

	if (FAILED(SetData(SECOND_ACCESSOR)))
	{
		m_oSession.Abort();
		return FALSE;
	}

	m_oSession.Commit();

	CloseCommandSessionConnection();
	return TRUE;
};

BOOL CCitiesTable::Insert(CITIES& recCities)
{
	m_oSession.Open(CDBConnectionCreator::GetInstance().GetDataSource());

	HRESULT hResult;
	CString strQuery;

	strQuery.Format(_T("SELECT TOP 0 * FROM CITIES"));

	if (FAILED(m_oSession.StartTransaction()))
	{
		return FALSE;
	}

	if (FAILED(ExecuteQuery(strQuery)))
	{
		m_oSession.Abort();
		return FALSE;
	}

	hResult = MoveNext();

	if (FAILED(hResult))
	{
		m_oSession.Abort();
		return FALSE;
	}
	
	m_recCity = recCities;
	hResult = __super::Insert(SECOND_ACCESSOR);

	if (FAILED(hResult))
	{
		return FALSE;
	}

	MoveNext();
	recCities = m_recCity;

	m_oSession.Commit();

	CloseCommandSessionConnection();
	return TRUE;
};

BOOL CCitiesTable::DeleteWhereID(const long lID)
{
	m_oSession.Open(CDBConnectionCreator::GetInstance().GetDataSource());

	HRESULT hResult;

	CITIES oCity;
	if (FAILED(m_oSession.StartTransaction()))
	{
		return FALSE;
	}

	if (FAILED(SelectByID(lID, oCity)))
	{
		m_oSession.Abort();
		return FALSE;
	}

	hResult = Delete();

	if (FAILED(hResult))
	{
		return FALSE;
	}

	m_oSession.Commit();

	CloseCommandSessionConnection();
	return TRUE;
};

CSession & CCitiesTable::GetSession()
{
	return m_oSession;
}

void CCitiesTable::CloseCommandSessionConnection()
{
	Close();
	m_oSession.Close();
}