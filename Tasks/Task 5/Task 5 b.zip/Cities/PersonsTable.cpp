#include "stdafx.h"

#include <atlbase.h>

#include <atldbcli.h>

#include <atldbsch.h>

#include "Typedefs.h"

#include "PersonsTable.h"

PERSONS& CPersonsTable::GetRowSet()
{
	return m_recPerson;
};

long CPersonsTable::GetUpdateCounter(PERSONS person)
{
	return person.lUpdateCounter;
};
