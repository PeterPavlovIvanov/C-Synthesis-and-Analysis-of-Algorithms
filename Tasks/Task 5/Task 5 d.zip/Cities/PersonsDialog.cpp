// PersonsDialog.cpp : implementation file
//

#include "stdafx.h"

#include "PhoneBook.h"

#include "PersonsDialog.h"

#include "afxdialogex.h"

#include "PhoneNumbersDialog.h"

// CPersonsDialog dialog

IMPLEMENT_DYNAMIC(CPersonsDialog, CDialog)

CPersonsDialog::CPersonsDialog(PERSONS & recPerson, CCitiesArray* oCitiesArray, DialogModes eDialogMode, 
	CPhoneTypesArray* oPhoneTypesArray, CWnd* pParent /*=NULL*/)
	: CDialog(IDD_PERSONS_DIALOG, pParent), m_recPerson(recPerson)
{
	switch (eDialogMode)
	{
	case DialogModeUpdate:
		m_strDlgCaption = _T("Update Person");
		break;
	case DialogModeDelete:
		m_strDlgCaption = _T("Are you sure you want to delete this Person?");
		break;
	case DialogModeView:
		m_strDlgCaption = _T("View Person");
		break;
	case DialogModeInsert:
		m_strDlgCaption = _T("Insert Person");
		break;
	};

	m_eDialogMode = eDialogMode;
	m_recPerson = recPerson;

	for (int i = 0; i < oCitiesArray->GetCount(); i++)
	{
		m_oCitiesArray.Add(oCitiesArray->GetAt(i));
	}

	for (int i = 0; i < oPhoneTypesArray->GetCount(); i++)
	{
		m_oPhoneTypesArray.Add(oPhoneTypesArray->GetAt(i));
	}
};

CPersonsDialog::~CPersonsDialog()
{
};

void CPersonsDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_PERSONS_FIRST_NAME, editFirstName);
	DDX_Control(pDX, IDC_EDIT_PERSONS_MIDDLE_NAME, editMiddleName);
	DDX_Control(pDX, IDC_EDIT_PERSONS_LAST_NAME, editLastName);
	DDX_Control(pDX, IDC_EDIT_PERSONS_UCN, editUCN);
	DDX_Control(pDX, IDC_COMBO_PERSONS_CITY, comboCity);
	DDX_Control(pDX, IDC_EDIT_PERSONS_ADDRESS, editAddress);
	DDX_Control(pDX, IDC_LIST_PERSONS_NUMBERS, listCtrlPhoneNumbers);
};

void CPersonsDialog::DialogToBuf()
{
	CString strWindowText;

	editFirstName.GetWindowText(strWindowText);
	wcscpy_s(m_recPerson.szFirstName, strWindowText);

	editMiddleName.GetWindowText(strWindowText);
	wcscpy_s(m_recPerson.szMiddleName, strWindowText);

	editLastName.GetWindowText(strWindowText);
	wcscpy_s(m_recPerson.szLastName, strWindowText);

	editUCN.GetWindowText(strWindowText);
	wcscpy_s(m_recPerson.szUCN, strWindowText);

	editAddress.GetWindowText(strWindowText);
	wcscpy_s(m_recPerson.szAddress, strWindowText);

	long lIndex = comboCity.GetCurSel();
	lCityID = comboCity.GetItemData(lIndex);
};

BOOL CPersonsDialog::OnInitDialog()
{
	__super::OnInitDialog();
	SetWindowText(m_strDlgCaption);
	if (m_eDialogMode == DialogModes::DialogModeView || m_eDialogMode == DialogModes::DialogModeDelete)
	{
		editAddress.SetReadOnly();
		editLastName.SetReadOnly();
		editMiddleName.SetReadOnly();
		editFirstName.SetReadOnly();
		editAddress.SetReadOnly();
		//comboCity.AllowSelection(false);
		//listCtrlPhoneNumbers.
	}

	//Edit controls
	SetDlgItemText(IDC_EDIT_PERSONS_FIRST_NAME, m_recPerson.szFirstName);
	SetDlgItemText(IDC_EDIT_PERSONS_LAST_NAME, m_recPerson.szLastName);
	SetDlgItemText(IDC_EDIT_PERSONS_MIDDLE_NAME, m_recPerson.szMiddleName);
	SetDlgItemText(IDC_EDIT_PERSONS_ADDRESS, m_recPerson.szAddress);
	SetDlgItemText(IDC_EDIT_PERSONS_UCN, m_recPerson.szUCN);
	
	//ComboBox
	for (int i = 0; i < m_oCitiesArray.GetCount(); i++)
	{
		int nIndex = comboCity.AddString(m_oCitiesArray.GetAt(i)->szCityName);
		comboCity.SetItemData(nIndex, m_oCitiesArray.GetAt(i)->lID);
	}

	//CListCtrl
	listCtrlPhoneNumbers.SetView(LVS_REPORT);
	listCtrlPhoneNumbers.SetExtendedStyle(listCtrlPhoneNumbers.GetExtendedStyle() | LVS_EX_FULLROWSELECT);
	listCtrlPhoneNumbers.InsertColumn(ZERO_COLUMN, _T("NUMBER"), LVCFMT_CENTER, COLUMN_WIDTH);
	listCtrlPhoneNumbers.InsertColumn(ZERO_COLUMN, _T("PHONE_TYPE"), LVCFMT_CENTER, COLUMN_WIDTH / 2);

	return TRUE;
};

BEGIN_MESSAGE_MAP(CPersonsDialog, CDialog)
	ON_BN_CLICKED(IDOK, &CPersonsDialog::OnBnClickedOk)
	ON_NOTIFY(NM_RCLICK, IDC_LIST_PERSONS_NUMBERS, &CPersonsDialog::OnRclickList)
	ON_WM_PAINT()
	ON_WM_CONTEXTMENU()
	ON_COMMAND(INSERT_PHONE_NUMBERS_OPTION_ID, &CPersonsDialog::OnPhoneNumbersInsert)
	ON_COMMAND(UPDATE_PHONE_NUMBERS_OPTION_ID, &CPersonsDialog::OnPhoneNumbersUpdate)
	ON_COMMAND(DELETE_PHONE_NUMBERS_OPTION_ID, &CPersonsDialog::OnPhoneNumbersDelete)
END_MESSAGE_MAP()

// CPersonsDialog message handlers
void CPersonsDialog::OnRclickList(NMHDR * pNMHDR, LRESULT * pResult)
{
	//ContextMenu
	CRect client_rect;
	GetClientRect(&client_rect);
	ClientToScreen(&client_rect);

	CPoint point;
	point.x = GetCurrentMessage()->pt.x;
	point.y = GetCurrentMessage()->pt.y;

	if (client_rect.PtInRect(point))
	{
		CMenu* menu = new CMenu();
		menu->CreatePopupMenu();

		menu->AppendMenu(MF_STRING, INSERT_PHONE_NUMBERS_OPTION_ID, _T("Insert"));
		menu->AppendMenu(MF_STRING, UPDATE_PHONE_NUMBERS_OPTION_ID, _T("Update"));
		menu->AppendMenu(MF_STRING, DELETE_PHONE_NUMBERS_OPTION_ID, _T("Delete"));

		menu->TrackPopupMenu(TPM_LEFTALIGN, point.x, point.y, this);
		listCtrlPhoneNumbers.SetMenu(menu);
	}
};

void CPersonsDialog::OnBnClickedOk()
{
	DialogToBuf();
	CDialog::OnOK();
};

void CPersonsDialog::OnPhoneNumbersInsert()
{
	DialogModes eDialogMode = DialogModeInsert;
	PHONE_NUMBERS recPhoneNumber;

	CPhoneTypesArray* oPhoneTypesArray = new CPhoneTypesArray();
	for (int i = 0; i < m_oPhoneTypesArray.GetCount(); i++)
	{
		oPhoneTypesArray->Add(m_oPhoneTypesArray.GetAt(i));
	}

	CPhoneNumbersDialog oPhoneNumbersDialog(eDialogMode, recPhoneNumber, oPhoneTypesArray);
	oPhoneNumbersDialog.DoModal();
};

void CPersonsDialog::OnPhoneNumbersUpdate()
{
	DialogModes eDialogMode = DialogModeUpdate;
	PHONE_NUMBERS recPhoneNumber;

	CPhoneTypesArray* oPhoneTypesArray = new CPhoneTypesArray();
	for (int i = 0; i < m_oPhoneTypesArray.GetCount(); i++)
	{
		oPhoneTypesArray->Add(m_oPhoneTypesArray.GetAt(i));
	}

	CPhoneNumbersDialog oPhoneNumbersDialog(eDialogMode, recPhoneNumber, oPhoneTypesArray);
	oPhoneNumbersDialog.DoModal();
};

void CPersonsDialog::OnPhoneNumbersDelete()
{
	DialogModes eDialogMode = DialogModeDelete;
	PHONE_NUMBERS recPhoneNumber;

	CPhoneTypesArray* oPhoneTypesArray = new CPhoneTypesArray();
	for (int i = 0; i < m_oPhoneTypesArray.GetCount(); i++)
	{
		oPhoneTypesArray->Add(m_oPhoneTypesArray.GetAt(i));
	}

	CPhoneNumbersDialog oPhoneNumbersDialog(eDialogMode, recPhoneNumber, oPhoneTypesArray);
	oPhoneNumbersDialog.DoModal();
};
