﻿#pragma once
#include "afxwin.h"
#include "DialogModes.h"
#include "Typedefs.h"

// CPhoneNumbersDialog dialog

class CPhoneNumbersDialog : public CDialog
{
	DECLARE_DYNAMIC(CPhoneNumbersDialog)

public:
	CPhoneNumbersDialog(DialogModes eDialogMode, PHONE_NUMBERS& recPHONE_NUMBERS, 
		CPhoneTypesArray* oPhoneTypesArray, CWnd* pParent = NULL);   // standard constructor
	virtual ~CPhoneNumbersDialog();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG4 };
#endif

	//Methods
public:
	void OnPhoneNumbersInsert();
	void OnPhoneNumbersUpdate();
	void OnPhoneNumbersDelete();

	///<summary>Задава заглавие и полетата на диалога</summary>
	///<returns>Дали операцията е упсешна</returns>
	BOOL OnInitDialog() override;

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()

	//Members
public:
	CEdit editNumber;
	CComboBox comboPhoneType;

private:
	DialogModes m_eDialogMode;
	PHONE_NUMBERS& m_recPhoneNumber;
	CString m_strDlgCaption;
	CPhoneTypesArray m_oPhoneTypesArray;

public:
	afx_msg void OnBnClickedOk();
	afx_msg void OnBnClickedCancel();
};
