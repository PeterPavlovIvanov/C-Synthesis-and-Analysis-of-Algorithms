#include "stdafx.h"

#include <atlbase.h>

#include <atldbcli.h>

#include <atldbsch.h>

#include "Typedefs.h"

#include "PhoneNumbersTable.h"

PHONE_NUMBERS& CPhoneNumbersTable::GetRowSet()
{
	return m_recPhoneNumber;
};

long CPhoneNumbersTable::GetUpdateCounter(PHONE_NUMBERS recPhoneNumber)
{
	return recPhoneNumber.lUpdateCounter;
};
