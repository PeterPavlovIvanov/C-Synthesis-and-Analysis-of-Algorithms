#include "stdafx.h"

#include <atlbase.h>

#include <atldbcli.h>

#include <atldbsch.h>

#include "Typedefs.h"

#include "PhoneNumbersTable.h"

CPhoneNumbersTable::CPhoneNumbersTable(CString strTableName, CSession oSession) : CBaseTable(strTableName, oSession)
{
}

PHONE_NUMBERS& CPhoneNumbersTable::GetRowSet()
{
	return m_recPhoneNumber;
};

long CPhoneNumbersTable::GetUpdateCounter(PHONE_NUMBERS recPhoneNumber)
{
	return recPhoneNumber.lUpdateCounter;
};

void CPhoneNumbersTable::SetRowSetValue(PHONE_NUMBERS recPhoneNumber)
{
	m_recPhoneNumber = recPhoneNumber;
};

void CPhoneNumbersTable::IncrementUpdateCounter(PHONE_NUMBERS & recPhoneNumber)
{
	m_recPhoneNumber.lUpdateCounter += 1;
};
