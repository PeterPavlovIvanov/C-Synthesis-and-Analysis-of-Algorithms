﻿#pragma once

#include "afxwin.h"

#include "DialogModes.h"

#include "PhoneTypesView.h"

// CPhoneTypesDialog dialog

class CPhoneTypesDialog : public CDialog
{
	DECLARE_DYNAMIC(CPhoneTypesDialog)

	// Constructor / Destructor
	// ----------------
public:
	///<summary>Standard-ен конструктор</summary>
	CPhoneTypesDialog(DialogModes eDialogMode, PHONE_TYPES& recPhoneType, CWnd* pParent = NULL);   // standard constructor

	///<summary>Виртуален Деструктор<summary>
	virtual ~CPhoneTypesDialog();

public:
	CPhoneTypesDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG2 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()


	//Methods
	// ----------------
public:
	///<summary>При OK взима стойностите от диалога и Set-ва името и региона в recCity.</summary>
	afx_msg void OnBnClickedOk();

	///<summary>При Cancel чисти полетата.</summary>
	afx_msg void OnBnClickedCancel();

	///<summary>Чисти полетата</summary>
	void CleanFields();

	///<summary>Пълни полетата</summary>
	void DialogToBuf();

	///<summary>Задава заглавие и полетата на диалога</summary>
	///<returns>Дали операцията е упсешна</returns>
	BOOL OnInitDialog() override;

	//Members
	// ----------------
private:
	///<summary>Режим на диалога</summary>
	DialogModes m_eDialogMode;

	///<summary>Телефонен тип с който се оперира в различните методи</summary>
	PHONE_TYPES& m_recPhoneType;
public:
	///<summary>CEdit - input-а за името на телефонния тип</summary>
	CEdit editPhoneType;

	///<summary>Името на диалога</summary>
	CString m_strDlgCaption;

};
