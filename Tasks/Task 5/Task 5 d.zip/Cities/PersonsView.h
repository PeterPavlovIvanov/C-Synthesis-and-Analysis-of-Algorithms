﻿#pragma once

#include "PersonsDocument.h"

/////////////////////////////////////////////////////////////////////////////
// CPersonsView view

///<summary>Клас View за Cities лист control-ата</summary>
class CPersonsView : public CListView
{
	DECLARE_DYNCREATE(CPersonsView)

	// Constructor / Destructor
	// ----------------
public:
	///<summary>Default-ен конструктор</summary>
	CPersonsView();

	///<summary>Деструктор<summary>
	virtual ~CPersonsView();


public:
#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif

	// Macros
	// ----------------
protected:
	DECLARE_MESSAGE_MAP()

	//Methods
	// ----------------
public:
	void OnInitialUpdate();

	///<summary>Добавя Абонат</summary>
	///<param = "recPersons">Абонат за добавяне</param>
	///<returns>Дали е упсешно изпълнена операцията</returns>
	BOOL InsertPerson(PERSONS& recPersons);

	/////<summary>Променя град</summary>
	/////<param = "recCity">Променения град</param>
	/////<returns>Дали е упсешно изпълнена операцията</returns>
	//BOOL UpdateCity(const CITIES& recCity);

	/////<summary>Изтрива град</summary>
	/////<param = "nID">ID на града за изтриване</param>
	/////<returns>Дали е упсешно изпълнена операцията</returns>
	//BOOL DeleteCity(int nID);

	/////<summary>Извиква метода на документа който взима град по ID</summary>
	/////<param = "nID">ID на града</param>
	/////<returns>Дали е упсешно изпълнена операцията</returns>
	//BOOL SelectCityByID(int nID, CITIES& recCity);

	///<summary>Взима документа</summary>
	///<returns>Pointer към документа</returns>
	CPersonsDocument* GetDocument() const;

	///<summary>Отваря контекстното меню при десен клавиш</summary>
	///<param = "pWnd"></param>
	///<param = "point"></param>
	void OnContextMenu(CWnd* pWnd, CPoint point);

	///<summary>Отваря диалога за Insert на град</summary>
	void OnPersonsInsert();

	/*///<summary>Отваря диалог за преглед на данни</summary>
	void OnView();

	///<summary>Отваря диалог за потвърждаване за изтриване на град</summary>
	void OnDelete();

	///<summary>Отваря диалог за Update на град и при изпълнения на диалога извършва съответното действие</summary>
	void OnCityUpdate();*/

	///<summary></summary>
	void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) override;

	//Members
	// ----------------
private:
	///<summary>Инстанция на List Control-ата</summary>
	CListCtrl& m_ListCtrl = GetListCtrl();
};


