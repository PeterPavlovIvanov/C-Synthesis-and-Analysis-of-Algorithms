#include "stdafx.h"

#include <atlbase.h>

#include <atldbcli.h>

#include <atldbsch.h>

#include "Typedefs.h"

#include "PersonsTable.h"

CPersonsTable::CPersonsTable(CString strTableName, CSession oSession) : CBaseTable(strTableName, oSession)
{

};

PERSONS& CPersonsTable::GetRowSet()
{
	return m_recPerson;
};

void CPersonsTable::SetRowSetValue(PERSONS recPerson)
{
	m_recPerson = recPerson;
};

long CPersonsTable::GetUpdateCounter(PERSONS recPerson)
{
	return recPerson.lUpdateCounter;
};

void CPersonsTable::IncrementUpdateCounter(PERSONS& recPerson)
{
	recPerson.lUpdateCounter += 1;
};
