﻿// CitiesView.cpp : implementation file
//

#include "stdafx.h"

#include "PhoneBook.h"

#include "CitiesView.h"

#include "CitiesDocument.h"

#include "Typedefs.h"

#include "CitiesDialog.h"

#include "UpdateCodes.h"

// CCitiesView

#define FIRST__COLUMN 0
#define SECOND__COLUMN 1
#define THIRD__COLUMN 2

IMPLEMENT_DYNCREATE(CCitiesView, CListView)

CCitiesView::CCitiesView()
{

}

CCitiesView::~CCitiesView()
{
}

BEGIN_MESSAGE_MAP(CCitiesView, CListView)
	ON_COMMAND(INSERT_OPTION_ID, &CCitiesView::OnCitiesInsert)
	ON_COMMAND(VIEW_OPTION_ID, &CCitiesView::OnView)
	ON_COMMAND(DELETE_OPTION_ID, &CCitiesView::OnDelete)
	ON_COMMAND(UPDATE_OPTION_ID, &CCitiesView::OnCityUpdate)
	ON_WM_PAINT()
	ON_WM_CONTEXTMENU()
END_MESSAGE_MAP()


// CCitiesView diagnostics

#ifdef _DEBUG
void CCitiesView::AssertValid() const
{
	CListView::AssertValid();
}

#ifndef _WIN32_WCE
void CCitiesView::Dump(CDumpContext& dc) const
{
	CListView::Dump(dc);
}
void CCitiesView::OnInitialUpdate()
{
	m_ListCtrl.SetView(LVS_REPORT);

	m_ListCtrl.SetExtendedStyle(m_ListCtrl.GetExtendedStyle() | LVS_EX_FULLROWSELECT);

	m_ListCtrl.InsertColumn(FIRST__COLUMN, _T("CITY_NAME"), LVCFMT_CENTER, COLUMN_WIDTH);
	m_ListCtrl.InsertColumn(SECOND__COLUMN, _T("REGION"), LVCFMT_CENTER, COLUMN_WIDTH);
	m_ListCtrl.InsertColumn(THIRD__COLUMN, _T("ID"), LVCFMT_CENTER, COLUMN_WIDTH);

	CListView::OnInitialUpdate();

	if (FAILED(GetDocument()->SelectAll()))
	{
		return;
	}

	for (int i = 0; i < GetDocument()->GetCitiesArray().GetCount(); i++)
	{
		CITIES* oCity = GetDocument()->GetCitiesArray().GetAt(i);
		CString strID;
		strID.Format(_T("%d"), oCity->lID);

		int nIndex = m_ListCtrl.InsertItem(FIRST__COLUMN, oCity->szCityName);
		m_ListCtrl.SetItemText(nIndex, SECOND__COLUMN, oCity->szRegion);
		m_ListCtrl.SetItemText(nIndex, THIRD__COLUMN, strID);
		m_ListCtrl.SetItemData(nIndex, oCity->lID);
	}
}
#endif
#endif //_DEBUG

void CCitiesView::OnUpdate(CView * pSender, LPARAM lHint, CObject * pHint)
{
	CString strID;

	switch (lHint)
	{
	case (UpdateCodes::UpdateCodeUpdate) :
	{
		for (int i = 0; i < m_ListCtrl.GetItemCount(); i++)
		{
			CITIES* pCity = (CITIES*)pHint;
			if (m_ListCtrl.GetItemData(i) == pCity->lID)
			{
				strID.Format(_T("%d"), pCity->lID);

				m_ListCtrl.SetItemText(i, FIRST__COLUMN, pCity->szCityName);
				m_ListCtrl.SetItemText(i, SECOND__COLUMN, pCity->szRegion);
				m_ListCtrl.SetItemText(i, THIRD__COLUMN, strID);

				break;
			}
		}
		break;
	}
	case (UpdateCodes::UpdateCodeInsert):
	{
		CITIES* pCity = (CITIES*)pHint;
		strID.Format(_T("%d"), pCity->lID);

		int nIndex = m_ListCtrl.InsertItem(FIRST__COLUMN, pCity->szCityName);
		m_ListCtrl.SetItemText(nIndex, SECOND__COLUMN, pCity->szRegion);
		m_ListCtrl.SetItemText(nIndex, THIRD__COLUMN, strID);
		m_ListCtrl.SetItemData(nIndex, pCity->lID);

		break;
	}
	case (UpdateCodes::UpdateCodeDelete):
	{
		for (int i = 0; i < m_ListCtrl.GetItemCount(); i++)
		{
			CITIES* pCity = (CITIES*)pHint;
			if (m_ListCtrl.GetItemData(i) == pCity->lID)
			{
				m_ListCtrl.DeleteItem(i);
				break;
			}
		}
	}
	default:
		break;
	}
	__super::OnUpdate(pSender, lHint, pHint);
};
CCitiesDocument * CCitiesView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CCitiesDocument)));
	return (CCitiesDocument*)m_pDocument;
};

//Методи които само викат документа
// ----------------
BOOL CCitiesView::InsertCity(CITIES& recCities)
{
	return GetDocument()->InsertCity(recCities);
};

BOOL CCitiesView::UpdateCity(const CITIES& recCity)
{
	return GetDocument()->UpdateCity(recCity);
};

BOOL CCitiesView::DeleteCity(int nID)
{
	return GetDocument()->DeleteByID(nID);
};

BOOL CCitiesView::SelectCityByID(int nID, CITIES& recCity)
{
	return GetDocument()->SelectByID(nID, recCity);
};

//Методи отварящи диалог или меню
// ----------------
void CCitiesView::OnContextMenu(CWnd* pWnd, CPoint point)
{
	//Sample 01: Declarations
	CRect client_rect;
	CMenu MainMenu;

	//Get Mouse Click position and convert it to the Screen Co-ordinate
	GetClientRect(&client_rect);
	ClientToScreen(&client_rect);

	//Check the mouse pointer position is inside the client area
	if (client_rect.PtInRect(point))
	{
		//Create the Main Menu
		MainMenu.CreatePopupMenu();
		MainMenu.AppendMenu(MF_STRING, INSERT_OPTION_ID, _T("Insert"));
		MainMenu.AppendMenu(MF_STRING, UPDATE_OPTION_ID, _T("Update"));
		MainMenu.AppendMenu(MF_STRING, DELETE_OPTION_ID, _T("Delete"));
		MainMenu.AppendMenu(MF_STRING, VIEW_OPTION_ID, _T("View"));

		//Display the Popup Menu
		MainMenu.TrackPopupMenu(TPM_LEFTALIGN, point.x, point.y, this);
	}
	else
	{
		CWnd::OnContextMenu(pWnd, point);
	}

};

void CCitiesView::OnCitiesInsert()
{
	CITIES recCity;
	DialogModes eDialogMode = DialogModeInsert;
	CCitiesDialog oDialog(recCity, eDialogMode);

	if (oDialog.DoModal() != IDOK)
		return;

	InsertCity(recCity);
};

void CCitiesView::OnView() 
{
	//Взимаме документа
	CCitiesDocument* pCitiesDocument = GetDocument();

	//Взимаме select-натия град
	int nIndex = m_ListCtrl.GetSelectionMark();
	long lID = m_ListCtrl.GetItemData(nIndex);

	//взимаме актуалния град от базата и го запазваме в recCity
	CITIES recCity;
	if (FAILED(pCitiesDocument->SelectByID(lID, recCity)))
		return;

	//Инициализираме диалога със съответните заглавие и полета
	DialogModes eDialogMode = DialogModeView;
	CCitiesDialog oDialog(recCity, eDialogMode);

	oDialog.DoModal();
};

void CCitiesView::OnDelete()
{
	//Взимаме документа
	CCitiesDocument* pCitiesDocument = GetDocument();

	//Взимаме select-натия град
	int nIndex = m_ListCtrl.GetSelectionMark();
	long lID = m_ListCtrl.GetItemData(nIndex);

	//взимаме актуалния град от базата и го запазваме в recCity
	CITIES recCity;
	if (FAILED(pCitiesDocument->SelectByID(lID, recCity)))
		return;

	//Инициализираме диалога със съответните заглавие и полета
	DialogModes eDialogMode = DialogModeDelete;
	CCitiesDialog oDialog(recCity, eDialogMode);

	if (oDialog.DoModal() != IDOK)
		return;
		
	GetDocument()->DeleteByID(lID);
};

void CCitiesView::OnCityUpdate() 
{
	//Взимаме документа
	CCitiesDocument* pCitiesDocument = GetDocument();

	//Взимаме ID на select-натия град
	int nIndex = m_ListCtrl.GetSelectionMark();
	long lID = m_ListCtrl.GetItemData(nIndex);

	//Взимаме актуалния град по ID и го запазваме в recCity
	CITIES recCity;
	if (FAILED(pCitiesDocument->SelectByID(lID, recCity)))
		return;

	//Инициализираме диалога със съответните заглавие и полета
	DialogModes eDialogMode = DialogModeUpdate;
	CCitiesDialog oDialog(recCity, eDialogMode);
	
	if (oDialog.DoModal() != IDOK)
		return;

	UpdateCity(recCity);
};