﻿#pragma once

#include "PhoneTypesDocument.h"

/////////////////////////////////////////////////////////////////////////////
// CPhoneTypesView

///<summary>Клас View за Phone_Types лист control-ата</summary>
class CPhoneTypesView : public CListView
{
	DECLARE_DYNCREATE(CPhoneTypesView)

	// Constructor / Destructor
	// ----------------
public:
	///<summary>Default-ен конструктор</summary>
	CPhoneTypesView();

	///<summary>Деструктор<summary>
	virtual ~CPhoneTypesView();

public:
#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif

	// Macros
	// ----------------
protected:
	DECLARE_MESSAGE_MAP()

	//Methods
	// ----------------
public:
	///<summary>Отваря диалога за Insert на град</summary>
	afx_msg void OnPhoneTypesInsert();

	///<summary>Добавя телефонен тип</summary>
	///<param = "recPhoneTypes">Телефонен тип за добавяне</param>
	///<returns>Дали е упсешно изпълнена операцията</returns>
	BOOL InsertPhoneType(PHONE_TYPES& recPhoneTypes);

	///<summary>Променя телефонен тип</summary>
	///<param = "recPhoneType">Променения телефонен тип</param>
	///<returns>Дали е упсешно изпълнена операцията</returns>
	BOOL UpdatePhoneType(const PHONE_TYPES& recPhoneType);

	///<summary>Изтрива телефонен тип</summary>
	///<param = "nID">ID на телефонния тип за изтриване</param>
	///<returns>Дали е упсешно изпълнена операцията</returns>
	BOOL DeletePhoneType(int nID);

	///<summary>Извиква метода на документа който взима телефонен тип по ID</summary>
	///<param = "nID">ID на телефонния тип</param>
	///<returns>Дали е упсешно изпълнена операцията</returns>
	BOOL SelectPhoneTypeByID(int nID, PHONE_TYPES& recPhoneType);

	///<summary>Взима документа</summary>
	///<returns>Pointer към документа</returns>
	CPhoneTypesDocument* GetDocument() const;

	///<summary>Отваря контекстното меню при десен клавиш</summary>
	///<param = "pWnd"></param>
	///<param = "point"></param>
	void OnContextMenu(CWnd* pWnd, CPoint point);

	///<summary>Отваря диалог за преглед на данни</summary>
	void OnView();

	///<summary>Отваря диалог за потвърждаване за изтриване на телефонен тип</summary>
	void OnDelete();

	///<summary>Отваря диалог за Update на телефонен тип и при изпълнения на диалога, извършва съответното действие</summary>
	void OnPhoneTypeUpdate();

	///<summary></summary>
	void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) override;

	void OnInitialUpdate();

	//Members
	// ----------------
private:
	///<summary>Инстанция на List Control-ата</summary>
	CListCtrl& m_ListCtrl = GetListCtrl();
public:
	afx_msg void OnTablesPhone();
};


