#include "stdafx.h"

#include "PersonsData.h"

CPersonsData::CPersonsData()
{
};

BOOL CPersonsData::SelectAll(CPersonsArray& oPersonsArray)
{
	return m_oPersonsTable.SelectAll(oPersonsArray);
};

BOOL CPersonsData::Insert(PERSONS& recPersons) {
	return m_oPersonsTable.Insert(recPersons);
	//todo add PHONE_NUMBERS after
};

BOOL CPersonsData::DeleteWhereID(int nID)
{
	//todo delete first from PHONE_NUMBERS
	return m_oPersonsTable.DeleteWhereID(nID);
};

BOOL CPersonsData::Update(const PERSONS& recPerson)
{
	return m_oPersonsTable.UpdateWhereID(recPerson.lID, recPerson);
	//todo update PHONE_NUMBERS after
};

BOOL CPersonsData::SelectWhereID(int nID, CNumbersPerson& oNumbersPerson)
{
	//todo take numbers
	return m_oPersonsTable.SelectWhereID(nID, oNumbersPerson.recPerson);
};