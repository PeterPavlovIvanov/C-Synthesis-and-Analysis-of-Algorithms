#include "stdafx.h"

#include "PersonsData.h"

#include "DBConnectionCreator.h"

CPersonsData::CPersonsData()
{
};

BOOL CPersonsData::SelectAll(CPersonsArray& oPersonsArray)
{
	CSession oSession;
	CString strTableName;
	strTableName.Format(_T("PERSONS"));
	CPersonsTable oPersonsTable(strTableName, oSession);

	if (FAILED(oPersonsTable.GetSession().Open(CDBConnectionCreator::GetInstance().GetDataSource())))
		return FALSE;

	BOOL hResult = oPersonsTable.SelectAll(oPersonsArray);

	oPersonsTable.GetSession().Close();
	return hResult;
};

BOOL CPersonsData::Insert(PERSONS& recPersons)
{
	CSession oSession;
	CString strTableName;
	strTableName.Format(_T("PERSONS"));
	CPersonsTable oPersonsTable(strTableName, oSession);

	if (FAILED(oPersonsTable.GetSession().Open(CDBConnectionCreator::GetInstance().GetDataSource())))
		return FALSE;

	BOOL hResult = oPersonsTable.Insert(recPersons);
	//todo add PHONE_NUMBERS after

	oPersonsTable.GetSession().Close();
	return hResult;
};

BOOL CPersonsData::DeleteWhereID(int nID)
{
	CSession oSession;
	CString strTableName;
	strTableName.Format(_T("PERSONS"));
	CPersonsTable oPersonsTable(strTableName, oSession);

	if (FAILED(oPersonsTable.GetSession().Open(CDBConnectionCreator::GetInstance().GetDataSource())))
		return FALSE;

	//todo delete first from PHONE_NUMBERS
	BOOL hResult = oPersonsTable.DeleteWhereID(nID);

	oPersonsTable.GetSession().Close();
	return hResult;
};

BOOL CPersonsData::Update(const PERSONS& recPerson)
{
	CSession oSession;
	CString strTableName;
	strTableName.Format(_T("PERSONS"));
	CPersonsTable oPersonsTable(strTableName, oSession);

	if (FAILED(oPersonsTable.GetSession().Open(CDBConnectionCreator::GetInstance().GetDataSource())))
		return FALSE;

	BOOL hResult = oPersonsTable.UpdateWhereID(recPerson.lID, recPerson);
	//todo update PHONE_NUMBERS after

	oPersonsTable.GetSession().Close();
	return hResult;
};

BOOL CPersonsData::SelectWhereID(int nID, CNumbersPerson& oNumbersPerson)
{
	CSession oSession;
	CString strTableName;
	strTableName.Format(_T("PERSONS"));
	CPersonsTable oPersonsTable(strTableName, oSession);

	if (FAILED(oPersonsTable.GetSession().Open(CDBConnectionCreator::GetInstance().GetDataSource())))
		return FALSE;

	//todo take numbers
	BOOL hResult = oPersonsTable.SelectWhereID(nID, oNumbersPerson.recPerson);

	oPersonsTable.GetSession().Close();
	return hResult;
};