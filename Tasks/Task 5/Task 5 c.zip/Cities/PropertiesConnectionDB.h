﻿#pragma once

#include <atldbcli.h>

///<summary>Клас за създаване на настройки за връзката с DB</summary>
class CPropertiesConnectionDB 
{
public:
	///<summary>Създава настройки за връзката с DB</summary>
	///<param = "oCDBPropSet">PropSet за настройки на връзката с DB</param>
	void SetPropertiesDB(CDBPropSet& oCDBPropSet);

	///<summary>Създава настройки за rowset-овете</summary>
	///<param = "oPropSet">PropSet за настройки на Rowset-овете</param>
	void SetPropertiesRows(CDBPropSet& oPropSet);
};