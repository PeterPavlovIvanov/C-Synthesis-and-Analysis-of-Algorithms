﻿#pragma once

#include "Structures.h"

#include "AutoReleaseMemoryTypedPtrArray.h"

#include "afxtempl.h"

#define QUOTE "/'"
#define FIRST_ACCESSOR 0
#define SECOND_ACCESSOR 1
#define UPDATE_COUNTER_NUMBER 1
#define ACCESSOR_COUNT 2
#define FIRST_COLUMN 1
#define SECOND_COLUMN 2
#define THIRD_COLUMN 3
#define FOURTH_COLUMN 4
#define FIFTH_COLUMN 5
#define SIXTH_COLUMN 6
#define SEVENTH_COLUMN 7
#define EIGHT_COLUMN 8
#define COLUMN_WIDTH 165

/// <summary>typedef-ове за градове</summary>
typedef CAutoReleaseMemoryTypedPtrArray<CITIES> CCitiesArray;

/// <summary>typedef-ове за типове на телефон</summary>
typedef CAutoReleaseMemoryTypedPtrArray<PHONE_TYPES> CPhoneTypesArray;

/// <summary>typedef-ове за абонати</summary>
typedef CAutoReleaseMemoryTypedPtrArray<PERSONS> CPersonsArray;

/// <summary>typedef-ове за телефонни номера</summary>
typedef CAutoReleaseMemoryTypedPtrArray<PHONE_NUMBERS> CPhoneNumbersArray;

/// <summary>typedef за мап от ID на абонати и съответните градове от който са</summary>
typedef CMap<int, int, CITIES, CITIES> CPersonsCitiesMap;

/// <summary> typedef за мап от ID на телефонен номер и телефонен номер</summary>
typedef CMap<int, int, PHONE_NUMBERS, PHONE_NUMBERS> CPhone_NumbersMap;