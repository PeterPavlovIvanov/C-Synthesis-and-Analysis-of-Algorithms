﻿#pragma once

#include <atldbcli.h>

#include "Typedefs.h"

#include "PropertiesConnectionDB.h"

///<summary>Клас за работа с таблица от базата данни</summary>
template <class AccessorType, class StructureType>
class CBaseTable : protected CCommand<CAccessor<AccessorType>>
{
	///Constructors...
public:
	///<summary>Конструктор по име на таблица</summary>
	CBaseTable(CString strTableName)
	{
		this->m_strTableName = strTableName;
		//TODO:m_oSession
		HRESULT hResult;
		CDBPropSet pPropSet(DBPROPSET_ROWSET);
		CPropertiesConnectionDB oPropConDB;
		oPropConDB.SetPropertiesRows(pPropSet);

		hResult = Open(m_oSession, strQuery, &pPropSet);

		if (FAILED(hResult))
		{
			return FALSE;
		}
		return TRUE;
	};

	///<summary>Конструктор по име на таблица и сесия</summary>
	CBaseTable(CString strTableName, CSession oSession)
	{
		this->m_strTableName = strTableName;
		m_oSession = oSession;
		
		HRESULT hResult;
		CDBPropSet pPropSet(DBPROPSET_ROWSET);
		CPropertiesConnectionDB oPropConDB;
		oPropConDB.SetPropertiesRows(pPropSet);

		hResult = Open(m_oSession, strQuery, &pPropSet);

		if (FAILED(hResult))
		{
			return FALSE;
		}
		return TRUE;
	};

	CBaseTable()
	{};
	///Methods...
public:
	/// <summary>Взима всички структури от таблицата AccessorType</summary>
	/// <param name="oStructureArray">Контейнер за резултата</param>
	/// <returns>Булева стойност отговаряща дали методът е приключил успешно</returns>
	BOOL SelectAll(CAutoReleaseMemoryTypedPtrArray<StructureType>& oStructureArray)
	{
		HRESULT hResult;
		CString strQuery;
		strQuery.Format(_T("SELECT * FROM %s"), m_strTableName);

		if (FAILED(ExecuteQuery(strQuery)))
		{
			return FALSE;
		}

		while (true)
		{
			hResult = MoveNext();
			if (hResult == S_OK)
			{
				StructureType* pStructure = new StructureType();
				*pStructure = GetRowSet();

				oStructureArray.Add(pStructure);
			}
			else if (hResult == DB_S_ENDOFROWSET)
			{
				break;
			}
			else
			{
				return FALSE;
			}
		}

		return TRUE;
	};

	/// <summary>Взима структура от таблицата по посочено ID</summary>
	/// <param name="lID">ID на търсената структура</param>
	/// <param name="recStructure">Структура за пазене на резултата</param>
	/// <returns>Булева стойност отговаряща дали методът е приключил успешно</returns>
	BOOL SelectWhereID(const long lID, StructureType& recStructure)
	{
		if (FAILED(SelectByID(lID, recStructure)))
		{
			return FALSE;
		}
		return TRUE;
	};

	/// <summary>Update-ва структура по посочено ID</summary>
	/// <param name="lID">ID на дадената структура</param>
	/// <param name="recStructure">Структура съдържащ новите данни</param>
	/// <returns>Булева стойност отговаряща дали методът е приключил успешно</returns>
	BOOL UpdateWhereID(const long lID, const StructureType& recStructure)
	{
		StructureType recStructureContainer;
		StructureType m_recStructure = GetRowSet();

		if (FAILED(m_oSession.StartTransaction()))
		{
			return FALSE;
		}

		if (FAILED(SelectByID(lID, recStructureContainer)))
		{
			m_oSession.Abort();
			return FALSE;
		}

		if (GetUpdateCounter(m_recStructure) != GetUpdateCounter(recStructure))
		{
			m_oSession.Abort();
			AfxMessageBox(_T("Session invalid, please try again."));
			CloseCommandSessionConnection();
			return FALSE;
		}

		m_recStructure = recStructure;
		m_recStructure.lUpdateCounter += UPDATE_COUNTER_NUMBER;

		if (FAILED(SetData(SECOND_ACCESSOR)))
		{
			m_oSession.Abort();
			return FALSE;
		}

		m_oSession.Commit();
		return TRUE;
	};

	/// <summary>Вмъква структура в таблицата AccessorType</summary>
	/// <param name="recStructure">Структура съдържаща новите данни</param>
	/// <returns>Булева стойност отговаряща дали методът е приключил успешно</returns>
	BOOL Insert(StructureType& recStructure)
	{
		HRESULT hResult;
		CString strQuery;
		StructureType m_recStructure = GetRowSet();

		strQuery.Format(_T("SELECT TOP 0 * FROM %s"), m_strTableName);

		if (FAILED(m_oSession.StartTransaction()))
		{
			return FALSE;
		}

		if (FAILED(ExecuteQuery(strQuery)))
		{
			m_oSession.Abort();
			return FALSE;
		}

		hResult = MoveNext();

		if (FAILED(hResult))
		{
			m_oSession.Abort();
			return FALSE;
		}

		m_recStructure = recStructure;
		hResult = __super::Insert(SECOND_ACCESSOR);

		if (FAILED(hResult))
		{
			return FALSE;
		}

		MoveNext();
		recStructure = m_recStructure;

		m_oSession.Commit();
		return TRUE;
	};

	/// <summary>Изтрива структура по посочено ID</summary>
	/// <param name="lID">ID на дадената структура</param>
	/// <returns>Булева стойност отговаряща дали методът е приключил успешно</returns>
	BOOL DeleteWhereID(const long lID)
	{
		HRESULT hResult;

		StructureType oStructure;
		if (FAILED(m_oSession.StartTransaction()))
		{
			return FALSE;
		}

		if (FAILED(SelectByID(lID, oStructure)))
		{
			m_oSession.Abort();
			return FALSE;
		}

		hResult = Delete();

		if (FAILED(hResult))
		{
			return FALSE;
		}

		m_oSession.Commit();
		return TRUE;
	};

	/// <summary>Прави връзката с DB</summary>
	/// <param name="strQuery">Заявката за изпълнение</param>
	/// <returns>Булева стойност отговаряща дали методът е приключил успешно</returns>
	BOOL ExecuteQuery(CString strQuery)
	{
		HRESULT hResult;
		CDBPropSet pPropSet(DBPROPSET_ROWSET);
		CPropertiesConnectionDB oPropConDB;
		oPropConDB.SetPropertiesRows(pPropSet);

		hResult = Open(m_oSession, strQuery, &pPropSet);

		if (FAILED(hResult))
		{
			return FALSE;
		}
		return TRUE;
	};

	/// <summary>Геттър на сесията</summary>
	CSession& GetSession()
	{
		return m_oSession;
	};

	/// <summary>Затваря row-сета и сесията</summary>
	void CloseCommandSessionConnection()
	{
		Close();
		m_oSession.Close();
	};

private:
	/// <summary>Update-ва структура по посочено ID без да затваря сесията</summary>
	/// <param name="lID">ID на дадената структура</param>
	/// <param name="recStructure">Структура за пазене на резултата</param>
	/// <returns>Булева стойност отговаряща дали методът е приключил успешно</returns>
	BOOL SelectByID(const long lID, StructureType& recStructure)
	{
		CString strQuery;
		strQuery.Format(_T("SELECT * FROM %s WHERE ID = %d"), m_strTableName, lID);

		ExecuteQuery(strQuery);

		if (MoveNext() == S_OK)
		{
			recStructure = GetRowSet();
		}
		else
		{
			return FALSE;
		}
		return TRUE;
	};

	///<summary>Pure Virtual метод взимащ rowset-а</summary>
	///<returns>връща rowset-а</returns>
	virtual StructureType& GetRowSet() = 0;

	///<summary>Pure Virtual метод взимащ UpdateCounter-а</summary>
	///<returns>връща UpdateCounter-а</returns>
	virtual long GetUpdateCounter(StructureType recStructure) = 0;

	//Members...
private:
	/// <summary>Текуща сесия</summary>
	CSession m_oSession;

	/// <summary>Име на таблицата</summary>
	CString m_strTableName;
};