#pragma once
enum UpdateCodes 
{
	UpdateCodeInsert = 1,
	UpdateCodeUpdate = 2,
	UpdateCodeDelete = 3 
};