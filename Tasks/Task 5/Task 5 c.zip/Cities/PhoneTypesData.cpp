#include "stdafx.h"

#include "PhoneTypesData.h"

CPhoneTypesData::CPhoneTypesData()
{
};

BOOL CPhoneTypesData::SelectAll(CPhoneTypesArray& oPhoneTypesArray)
{
	return m_oPhoneTypesTable.SelectAll(oPhoneTypesArray);
};

BOOL CPhoneTypesData::Insert(PHONE_TYPES& recPhoneTypes) {
	return m_oPhoneTypesTable.Insert(recPhoneTypes);
};

BOOL CPhoneTypesData::DeleteWhereID(int nID)
{
	return m_oPhoneTypesTable.DeleteWhereID(nID);
};

BOOL CPhoneTypesData::Update(const PHONE_TYPES & recPhoneType)
{
	return m_oPhoneTypesTable.UpdateWhereID(recPhoneType.lID, recPhoneType);
};

BOOL CPhoneTypesData::SelectWhereID(int nID, PHONE_TYPES& recPhoneType)
{
	return m_oPhoneTypesTable.SelectWhereID(nID, recPhoneType);
};