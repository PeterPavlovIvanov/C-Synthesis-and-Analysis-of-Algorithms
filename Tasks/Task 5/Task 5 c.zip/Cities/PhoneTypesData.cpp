#include "stdafx.h"

#include "PhoneTypesData.h"

#include "DBConnectionCreator.h"

CPhoneTypesData::CPhoneTypesData()
{
};

BOOL CPhoneTypesData::SelectAll(CPhoneTypesArray& oPhoneTypesArray)
{
	CSession oSession;
	CString strTableName;
	strTableName.Format(_T("PHONE_TYPES"));
	CPhoneTypesTable oPhoneTypesTable(strTableName, oSession);

	if (FAILED(oPhoneTypesTable.GetSession().Open(CDBConnectionCreator::GetInstance().GetDataSource())))
		return FALSE;

	BOOL hResult = oPhoneTypesTable.SelectAll(oPhoneTypesArray);

	oPhoneTypesTable.GetSession().Close();
	return hResult;
};

BOOL CPhoneTypesData::Insert(PHONE_TYPES& recPhoneTypes)
{
	CSession oSession;
	CString strTableName;
	strTableName.Format(_T("PHONE_TYPES"));
	CPhoneTypesTable oPhoneTypesTable(strTableName, oSession);

	if (FAILED(oPhoneTypesTable.GetSession().Open(CDBConnectionCreator::GetInstance().GetDataSource())))
		return FALSE;

	BOOL hResult = oPhoneTypesTable.Insert(recPhoneTypes);

	oPhoneTypesTable.GetSession().Close();
	return hResult;
};

BOOL CPhoneTypesData::DeleteWhereID(int nID)
{
	CSession oSession;
	CString strTableName;
	strTableName.Format(_T("PHONE_TYPES"));
	CPhoneTypesTable oPhoneTypesTable(strTableName, oSession);

	if (FAILED(oPhoneTypesTable.GetSession().Open(CDBConnectionCreator::GetInstance().GetDataSource())))
		return FALSE;

	BOOL hResult = oPhoneTypesTable.DeleteWhereID(nID);

	oPhoneTypesTable.GetSession().Close();
	return hResult;
};

BOOL CPhoneTypesData::Update(const PHONE_TYPES & recPhoneType)
{
	CSession oSession;
	CString strTableName;
	strTableName.Format(_T("PHONE_TYPES"));
	CPhoneTypesTable oPhoneTypesTable(strTableName, oSession);

	if (FAILED(oPhoneTypesTable.GetSession().Open(CDBConnectionCreator::GetInstance().GetDataSource())))
		return FALSE;

	BOOL hResult = oPhoneTypesTable.UpdateWhereID(recPhoneType.lID, recPhoneType);

	oPhoneTypesTable.GetSession().Close();
	return hResult;
};

BOOL CPhoneTypesData::SelectWhereID(int nID, PHONE_TYPES& recPhoneType)
{
	CSession oSession;
	CString strTableName;
	strTableName.Format(_T("PHONE_TYPES"));
	CPhoneTypesTable oPhoneTypesTable(strTableName, oSession);

	if (FAILED(oPhoneTypesTable.GetSession().Open(CDBConnectionCreator::GetInstance().GetDataSource())))
		return FALSE;

	BOOL hResult = oPhoneTypesTable.SelectWhereID(nID, recPhoneType);

	oPhoneTypesTable.GetSession().Close();
	return hResult;
};