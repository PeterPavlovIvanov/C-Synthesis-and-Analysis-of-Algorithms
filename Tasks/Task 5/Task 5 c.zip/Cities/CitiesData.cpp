#include "stdafx.h"

#include "CitiesData.h"

#include "DBConnectionCreator.h"

CCitiesData::CCitiesData()
{
};

BOOL CCitiesData::SelectAll(CCitiesArray& oCitiesArray)
{
	CSession oSession;
	CString strTableName;
	strTableName.Format(_T("CITIES"));
	CCitiesTable oCitiesTable(strTableName, oSession);

	if (FAILED(oCitiesTable.GetSession().Open(CDBConnectionCreator::GetInstance().GetDataSource())))
		return FALSE;

	BOOL hResult = oCitiesTable.SelectAll(oCitiesArray);

	oCitiesTable.GetSession().Close();
	return hResult;
};

BOOL CCitiesData::Insert(CITIES& recCities) {
	CSession oSession;
	CString strTableName;
	strTableName.Format(_T("CITIES"));
	CCitiesTable oCitiesTable(strTableName, oSession);

	if (FAILED(oCitiesTable.GetSession().Open(CDBConnectionCreator::GetInstance().GetDataSource())))
		return FALSE;

	BOOL hResult = oCitiesTable.Insert(recCities);

	oCitiesTable.GetSession().Close();
	return hResult;
};

BOOL CCitiesData::DeleteWhereID(int nID)
{
	CSession oSession;
	CString strTableName;
	strTableName.Format(_T("CITIES"));
	CCitiesTable oCitiesTable(strTableName, oSession);

	if (FAILED(oCitiesTable.GetSession().Open(CDBConnectionCreator::GetInstance().GetDataSource())))
		return FALSE;

	BOOL hResult = oCitiesTable.DeleteWhereID(nID);

	oCitiesTable.GetSession().Close();
	return hResult;
};

BOOL CCitiesData::Update(const CITIES & recCity)
{
	CSession oSession;
	CString strTableName;
	strTableName.Format(_T("CITIES"));
	CCitiesTable oCitiesTable(strTableName, oSession);

	if (FAILED(oCitiesTable.GetSession().Open(CDBConnectionCreator::GetInstance().GetDataSource())))
		return FALSE;

	BOOL hResult = oCitiesTable.UpdateWhereID(recCity.lID, recCity);

	oCitiesTable.GetSession().Close();
	return hResult;
};

BOOL CCitiesData::SelectWhereID(int nID, CITIES& recCity)
{
	CSession oSession;
	CString strTableName;
	strTableName.Format(_T("CITIES"));
	CCitiesTable oCitiesTable(strTableName, oSession);

	if (FAILED(oCitiesTable.GetSession().Open(CDBConnectionCreator::GetInstance().GetDataSource())))
		return FALSE;

	BOOL hResult = oCitiesTable.SelectWhereID(nID, recCity);

	oCitiesTable.GetSession().Close();
	return hResult;
};