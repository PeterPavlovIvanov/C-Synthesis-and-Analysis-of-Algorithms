﻿// PersonsView.cpp : implementation file
//

#include "stdafx.h"

#include "PhoneBook.h"

#include "PersonsView.h"

#include "DialogModes.h"

#include "PersonsDialog.h"

// CPersonsView

#define FIRST__COLUMN 0
#define SECOND__COLUMN 1
#define THIRD__COLUMN 2
#define FOURTH__COLUMN 3
#define FIFTH__COLUMN 4
#define SIXTH__COLUMN 5
#define SEVENTH__COLUMN 6
#define EIGHT__COLUMN 7

IMPLEMENT_DYNCREATE(CPersonsView, CListView)

CPersonsView::CPersonsView()
{

}

CPersonsView::~CPersonsView()
{
}

BEGIN_MESSAGE_MAP(CPersonsView, CListView)
	ON_COMMAND(INSERT_PERSON_OPTION_ID, &CPersonsView::OnPersonsInsert)
	ON_COMMAND(DELETE_PERSON_OPTION_ID, &CPersonsView::OnPersonsDelete)
	ON_WM_PAINT()
	ON_WM_CONTEXTMENU()
END_MESSAGE_MAP()


// CPersonsView diagnostics

#ifdef _DEBUG
void CPersonsView::AssertValid() const
{
	CListView::AssertValid();
}

#ifndef _WIN32_WCE
void CPersonsView::Dump(CDumpContext& dc) const
{
	CListView::Dump(dc);
}

void CPersonsView::OnInitialUpdate()
{
	m_ListCtrl.SetView(LVS_REPORT);

	m_ListCtrl.SetExtendedStyle(m_ListCtrl.GetExtendedStyle() | LVS_EX_FULLROWSELECT);

	m_ListCtrl.InsertColumn(FIRST__COLUMN, _T("FIRST_NAME"), LVCFMT_CENTER, COLUMN_WIDTH);
	m_ListCtrl.InsertColumn(SECOND__COLUMN, _T("MIDDLE_NAME"), LVCFMT_CENTER, COLUMN_WIDTH);
	m_ListCtrl.InsertColumn(THIRD__COLUMN, _T("LAST_NAME"), LVCFMT_CENTER, COLUMN_WIDTH);
	m_ListCtrl.InsertColumn(FOURTH__COLUMN, _T("UCN"), LVCFMT_CENTER, COLUMN_WIDTH);
	m_ListCtrl.InsertColumn(FIFTH__COLUMN, _T("ADDRESS"), LVCFMT_CENTER, COLUMN_WIDTH);
	m_ListCtrl.InsertColumn(SIXTH__COLUMN, _T("ID"), LVCFMT_CENTER, COLUMN_WIDTH);

	CListView::OnInitialUpdate();

	if (FAILED(GetDocument()->SelectAll()))
	{
		return;
	}

	for (int i = 0; i < GetDocument()->GetPersonsArray().GetCount(); i++)
	{
		PERSONS* recPerson = GetDocument()->GetPersonsArray().GetAt(i);
		CString strID;
		strID.Format(_T("%d"), recPerson->lID);

		int nIndex = m_ListCtrl.InsertItem(FIRST__COLUMN, recPerson->szFirstName);
		m_ListCtrl.SetItemText(nIndex, SECOND__COLUMN, recPerson->szMiddleName);
		m_ListCtrl.SetItemText(nIndex, THIRD__COLUMN, recPerson->szLastName);
		m_ListCtrl.SetItemText(nIndex, FOURTH__COLUMN, recPerson->szUCN);
		m_ListCtrl.SetItemText(nIndex, FIFTH__COLUMN, recPerson->szAddress);
		m_ListCtrl.SetItemText(nIndex, SIXTH__COLUMN, strID);
		m_ListCtrl.SetItemData(nIndex, recPerson->lID);
	}
}
#endif
#endif //_DEBUG

void CPersonsView::OnUpdate(CView * pSender, LPARAM lHint, CObject * pHint)
{
	CString strID;

	switch (lHint)
	{
	case (UpdateCodes::UpdateCodeUpdate) :
	{
		for (int i = 0; i < m_ListCtrl.GetItemCount(); i++)
		{
			PERSONS* pPerson = (PERSONS*)pHint;
			if (m_ListCtrl.GetItemData(i) == pPerson->lID)
			{
				strID.Format(_T("%d"), pPerson->lID);

				m_ListCtrl.SetItemText(i, FIRST__COLUMN, pPerson->szFirstName);
				m_ListCtrl.SetItemText(i, SECOND__COLUMN, pPerson->szMiddleName);
				m_ListCtrl.SetItemText(i, THIRD__COLUMN, pPerson->szLastName);
				m_ListCtrl.SetItemText(i, FOURTH__COLUMN, pPerson->szUCN);
				m_ListCtrl.SetItemText(i, FIFTH__COLUMN, pPerson->szAddress);
				m_ListCtrl.SetItemText(i, SIXTH__COLUMN, strID);

				break;
			}
		}
		break;
	}
	case (UpdateCodes::UpdateCodeInsert) :
	{
		PERSONS* pPerson = (PERSONS*)pHint;
		strID.Format(_T("%d"), pPerson->lID);

		int nIndex = m_ListCtrl.InsertItem(FIRST__COLUMN, pPerson->szFirstName);
		m_ListCtrl.SetItemText(nIndex, SECOND__COLUMN, pPerson->szMiddleName);
		m_ListCtrl.SetItemText(nIndex, THIRD__COLUMN, pPerson->szLastName);
		m_ListCtrl.SetItemText(nIndex, FOURTH__COLUMN, pPerson->szUCN);
		m_ListCtrl.SetItemText(nIndex, FIFTH__COLUMN, pPerson->szAddress);
		m_ListCtrl.SetItemText(nIndex, SIXTH__COLUMN, strID);
		m_ListCtrl.SetItemData(nIndex, pPerson->lID);

		break;
	}
	case (UpdateCodes::UpdateCodeDelete) :
	{
		for (int i = 0; i < m_ListCtrl.GetItemCount(); i++)
		{
			PERSONS* pPerson = (PERSONS*)pHint;
			if (m_ListCtrl.GetItemData(i) == pPerson->lID)
			{
				m_ListCtrl.DeleteItem(i);
				break;
			}
		}
	}
	default:
		break;
	}
	__super::OnUpdate(pSender, lHint, pHint);
};

CPersonsDocument * CPersonsView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CPersonsDocument)));
	return (CPersonsDocument*)m_pDocument;
};

//Методи които само викат документа
// ----------------
BOOL CPersonsView::InsertPerson(CNumbersPerson& oNumbersPerson)
{
	if(FAILED(GetDocument()->InsertPerson(oNumbersPerson.recPerson)))
		return FALSE;
	
	for (int i = 0; i < oNumbersPerson.oPhoneNumbersArray.GetCount(); i++) 
	{

		PHONE_NUMBERS recPhoneNumber = *(oNumbersPerson.oPhoneNumbersArray.GetAt(i));

		if (FAILED(GetDocument()->InsertPhoneNumber(recPhoneNumber)))
			return FALSE;

	}

	return TRUE;
};

//BOOL CCitiesView::UpdateCity(const CITIES& recCity)
//{
//	return GetDocument()->UpdateCity(recCity);
//};
//
//BOOL CCitiesView::DeleteCity(int nID)
//{
//	return GetDocument()->DeleteByID(nID);
//};
//
//BOOL CCitiesView::SelectCityByID(int nID, CITIES& recCity)
//{
//	return GetDocument()->SelectByID(nID, recCity);
//};

//Методи отварящи диалог или меню
// ----------------
void CPersonsView::OnContextMenu(CWnd* pWnd, CPoint point)
{
	//Sample 01: Declarations
	CRect client_rect;
	CMenu MainMenu;

	//Get Mouse Click position and convert it to the Screen Co-ordinate
	GetClientRect(&client_rect);
	ClientToScreen(&client_rect);

	//Check the mouse pointer position is inside the client area
	if (client_rect.PtInRect(point))
	{
		//Create the Main Menu
		MainMenu.CreatePopupMenu();
		MainMenu.AppendMenu(MF_STRING, INSERT_PERSON_OPTION_ID, _T("Insert"));
		MainMenu.AppendMenu(MF_STRING, UPDATE_PERSON_OPTION_ID, _T("Update"));
		MainMenu.AppendMenu(MF_STRING, DELETE_PERSON_OPTION_ID, _T("Delete"));
		MainMenu.AppendMenu(MF_STRING, VIEW_PERSON_OPTION_ID, _T("View"));

		//Display the Popup Menu
		MainMenu.TrackPopupMenu(TPM_LEFTALIGN, point.x, point.y, this);
	}
	else
	{
		CWnd::OnContextMenu(pWnd, point);
	}

};

void CPersonsView::OnPersonsInsert()
{
	PERSONS recPerson;
	CNumbersPerson oNumbersPerson(recPerson);

	DialogModes eDialogMode = DialogModeInsert;

	CCitiesArray* oCitiesArray = new CCitiesArray();
	if (FAILED(GetDocument()->SelectAllCities(*oCitiesArray)))
		return;

	CPhoneTypesArray* oPhoneTypesArray = new CPhoneTypesArray();
	if (FAILED(GetDocument()->SelectAllPhoneTypes(*oPhoneTypesArray)))
		return;

	CPersonsDialog oPersonsDialog(oNumbersPerson, oCitiesArray, eDialogMode, oPhoneTypesArray);

	if (oPersonsDialog.DoModal() != IDOK)
		return;

	//todo: take the city
	InsertPerson(oNumbersPerson);
};


void CPersonsView::OnPersonsDelete()
{
	//Взимаме документа
	CPersonsDocument* pPersonsDocument = GetDocument();

	//Взимаме select-натия град
	int nIndex = m_ListCtrl.GetSelectionMark();
	long lID = m_ListCtrl.GetItemData(nIndex);

	//взимаме актуалния абонат и номерите му от базата и го запазваме в oNumbersPerson
	CNumbersPerson oNumbersPerson;
	if (FAILED(pPersonsDocument->SelectByID(lID, oNumbersPerson)))
		return;

	//Инициализираме диалога със съответните заглавие и полета
	DialogModes eDialogMode = DialogModeDelete;
	CPersonsDialog oPersonsDialog(oNumbersPerson, eDialogMode);

	if (oPersonsDialog.DoModal() != IDOK)
		return;

	GetDocument()->DeleteByID(lID);
};

//void CCitiesView::OnView()
//{
//	//Взимаме документа
//	CCitiesDocument* pPersonsDocument = GetDocument();
//
//	//Взимаме select-натия град
//	int nIndex = m_ListCtrl.GetSelectionMark();
//	long lID = m_ListCtrl.GetItemData(nIndex);
//
//	//взимаме актуалния град от базата и го запазваме в recCity
//	CITIES recCity;
//	if (FAILED(pPersonsDocument->SelectByID(lID, recCity)))
//		return;
//
//	//Инициализираме диалога със съответните заглавие и полета
//	DialogModes eDialogMode = DialogModeView;
//	CCitiesDialog oDialog(recCity, eDialogMode);
//
//	oDialog.DoModal();
//};
//
//void CCitiesView::OnCityUpdate()
//{
//	//Взимаме документа
//	CCitiesDocument* pPersonsDocument = GetDocument();
//
//	//Взимаме ID на select-натия град
//	int nIndex = m_ListCtrl.GetSelectionMark();
//	long lID = m_ListCtrl.GetItemData(nIndex);
//
//	//Взимаме актуалния град по ID и го запазваме в recCity
//	CITIES recCity;
//	if (FAILED(pPersonsDocument->SelectByID(lID, recCity)))
//		return;
//
//	//Инициализираме диалога със съответните заглавие и полета
//	DialogModes eDialogMode = DialogModeUpdate;
//	CCitiesDialog oDialog(recCity, eDialogMode);
//
//	if (oDialog.DoModal() != IDOK)
//		return;
//
//	UpdateCity(recCity);
//};

// CPersonsView message handlers
