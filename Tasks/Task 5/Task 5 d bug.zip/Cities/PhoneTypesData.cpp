#include "stdafx.h"

#include "PhoneTypesData.h"

#include "DBConnectionCreator.h"

CPhoneTypesData::CPhoneTypesData()
{
};

BOOL CPhoneTypesData::SelectAll(CPhoneTypesArray& oPhoneTypesArray)
{
	CSession oSession;
	CString strTableName;
	strTableName.Format(_T("PHONE_TYPES"));

	if (FAILED(oSession.Open(CDBConnectionCreator::GetInstance().GetDataSource())))
		return FALSE;

	CPhoneTypesTable oPhoneTypesTable(strTableName, oSession);

	BOOL hResult = oPhoneTypesTable.SelectAll(oPhoneTypesArray);

	oSession.Close();
	return hResult;
};

BOOL CPhoneTypesData::Insert(PHONE_TYPES& recPhoneTypes)
{
	CSession oSession;
	CString strTableName;
	strTableName.Format(_T("PHONE_TYPES"));

	if (FAILED(oSession.Open(CDBConnectionCreator::GetInstance().GetDataSource())))
		return FALSE;

	CPhoneTypesTable oPhoneTypesTable(strTableName, oSession);

	BOOL hResult = oPhoneTypesTable.Insert(recPhoneTypes);

	oSession.Close();
	return hResult;
};

BOOL CPhoneTypesData::DeleteWhereID(int nID)
{
	CSession oSession;
	CString strTableName;
	strTableName.Format(_T("PHONE_TYPES"));

	if (FAILED(oSession.Open(CDBConnectionCreator::GetInstance().GetDataSource())))
		return FALSE;

	CPhoneTypesTable oPhoneTypesTable(strTableName, oSession);

	BOOL hResult = oPhoneTypesTable.DeleteWhereID(nID);

	oSession.Close();
	return hResult;
};

BOOL CPhoneTypesData::Update(const PHONE_TYPES & recPhoneType)
{
	CSession oSession;
	CString strTableName;
	strTableName.Format(_T("PHONE_TYPES"));

	if (FAILED(oSession.Open(CDBConnectionCreator::GetInstance().GetDataSource())))
		return FALSE;

	CPhoneTypesTable oPhoneTypesTable(strTableName, oSession);

	BOOL hResult = oPhoneTypesTable.UpdateWhereID(recPhoneType.lID, recPhoneType);

	oSession.Close();
	return hResult;
};

BOOL CPhoneTypesData::SelectWhereID(int nID, PHONE_TYPES& recPhoneType)
{
	CSession oSession;
	CString strTableName;
	strTableName.Format(_T("PHONE_TYPES"));

	if (FAILED(oSession.Open(CDBConnectionCreator::GetInstance().GetDataSource())))
		return FALSE;

	CPhoneTypesTable oPhoneTypesTable(strTableName, oSession);

	BOOL hResult = oPhoneTypesTable.SelectWhereID(nID, recPhoneType);

	oSession.Close();
	return hResult;
};