﻿#pragma once
#include <afxstr.h>

#define DEFAULT_FILED_SIZE 256
#define NAMES_SIZE 128
#define UCN_SIZE 32

/// <summary>
/// Структура PERSONS - запис в таблицата PERSONS (абонат)
/// </summary>
struct PERSONS 
{
	/// <summary>ID</summary>
	long lID;
	/// <summary>Брояч на промените върху дадения PERSON</summary>
	long lUpdateCounter;
	/// <summary>Първото име на дадения PERSON</summary>
	TCHAR szFirstName[NAMES_SIZE];
	/// <summary>Презимето на дадения PERSON</summary>
	TCHAR szMiddleName[NAMES_SIZE];
	/// <summary>Фамилията на дадения PERSON</summary>
	TCHAR szLastName[NAMES_SIZE];
	/// <summary>ЕГН на дадения PERSON</summary>
	TCHAR szUCN[UCN_SIZE];
	/// <summary>ID на града от който е дадения PERSON</summary>
	long lCityID;
	/// <summary>Адресът на дадения PERSON</summary>
	TCHAR szAddress[DEFAULT_FILED_SIZE];
	/// <summary>Конструктор</summary>
	PERSONS() 
	{
		SecureZeroMemory(this, sizeof(*this));
	};
};

/// <summary>
/// Структура CITIES - запис в таблицата CITIES (град)
/// </summary>
struct CITIES
{
	/// <summary>ID</summary>
	long lID;
	/// <summary>Брояч на промените върху даденото CITY</summary>
	long lUpdateCounter;
	/// <summary>Името на даденото CITY</summary>
	TCHAR szCityName[DEFAULT_FILED_SIZE];
	/// <summary>Регионът на даденото CITY</summary>
	TCHAR szRegion[DEFAULT_FILED_SIZE];
	/// <summary>Конструктор</summary>
	CITIES() 
	{
		SecureZeroMemory(this, sizeof(*this));
	};
};

/// <summary>
/// Структура PHONE_NUMBERS - запис в таблицата PHONE_NUMBERS (номер на абонат)
/// </summary>
struct PHONE_NUMBERS 
{
	/// <summary>ID</summary>
	long lID;
	/// <summary>Брояч на промените върху дадения PHONE_NUMBER</summary>
	long lUpdateCounter;
	/// <summary>ID на PERSON(абонат) притежаващ номера</summary>
	long lPersonID;
	/// <summary>ID на PHONE_TYPE - типът на телефона</summary>
	long lPhoneTypeID;
	/// <summary>Номер на абонат</summary>
	TCHAR szNumber[DEFAULT_FILED_SIZE];
	/// <summary>Конструктор</summary>
	PHONE_NUMBERS()
	{
		SecureZeroMemory(this, sizeof(*this));
	};
};

/// <summary>
/// Структура PHONE_TYPES - запис в таблицата PHONE_TYPES (тип на телефон)
/// </summary>
struct PHONE_TYPES
{
	/// <summary>ID</summary>
	long lID;
	/// <summary>Брояч на промените върху дадения PHONE_TYPE</summary>
	long lUpdateCounter;
	/// <summary>Тип на телефон</summary>
	TCHAR szPhoneType[DEFAULT_FILED_SIZE];
	/// <summary>Конструктор</summary>
	PHONE_TYPES()
	{
		SecureZeroMemory(this, sizeof(*this));
	};
};
