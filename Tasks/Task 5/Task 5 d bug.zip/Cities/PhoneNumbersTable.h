#pragma once

#include "BaseTable.h"

class CPhoneNumbersAccessor
{
protected:
	PHONE_NUMBERS m_recPhoneNumber;

	BEGIN_ACCESSOR_MAP(CPhoneNumbersAccessor, ACCESSOR_COUNT)
		BEGIN_ACCESSOR(FIRST_ACCESSOR, true)
		COLUMN_ENTRY(FIRST_COLUMN, m_recPhoneNumber.lID)
		END_ACCESSOR()

		BEGIN_ACCESSOR(FIRST_COLUMN, true)
		COLUMN_ENTRY(SECOND_COLUMN, m_recPhoneNumber.lUpdateCounter)
		COLUMN_ENTRY(THIRD_COLUMN, m_recPhoneNumber.lPersonID)
		COLUMN_ENTRY(FOURTH_COLUMN, m_recPhoneNumber.lPhoneTypeID)
		COLUMN_ENTRY(FIFTH_COLUMN, m_recPhoneNumber.szNumber)
		END_ACCESSOR()
	END_ACCESSOR_MAP()
};

class CPhoneNumbersTable : public CBaseTable<CPhoneNumbersAccessor, PHONE_NUMBERS>
{
	//Constructors
public:
	CPhoneNumbersTable(CString strTableName, CSession oSession);

	//Methods
public:
	BOOL SelectAllByPersonID(long lPersonID, CPhoneNumbersArray& oPhoneNumbersArray);

private:
	virtual PHONE_NUMBERS& GetRowSet() override;
	virtual long GetUpdateCounter(PHONE_NUMBERS recPhoneNumber) override;
	virtual void SetRowSetValue(PHONE_NUMBERS recPhoneNumber) override;
	virtual void IncrementUpdateCounter(PHONE_NUMBERS& recCity) override;
};