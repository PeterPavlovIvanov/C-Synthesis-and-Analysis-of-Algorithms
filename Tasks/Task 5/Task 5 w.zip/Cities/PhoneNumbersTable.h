﻿#pragma once

#include "BaseTable.h"

class CPhoneNumbersAccessor
{
protected:
	PHONE_NUMBERS m_recPhoneNumber;

	BEGIN_ACCESSOR_MAP(CPhoneNumbersAccessor, ACCESSOR_COUNT)
		BEGIN_ACCESSOR(FIRST_ACCESSOR, true)
		COLUMN_ENTRY(FIRST_COLUMN, m_recPhoneNumber.lID)
		END_ACCESSOR()

		BEGIN_ACCESSOR(FIRST_COLUMN, true)
		COLUMN_ENTRY(SECOND_COLUMN, m_recPhoneNumber.lUpdateCounter)
		COLUMN_ENTRY(THIRD_COLUMN, m_recPhoneNumber.lPersonID)
		COLUMN_ENTRY(FOURTH_COLUMN, m_recPhoneNumber.lPhoneTypeID)
		COLUMN_ENTRY(FIFTH_COLUMN, m_recPhoneNumber.szNumber)
		END_ACCESSOR()
	END_ACCESSOR_MAP()
};

class CPhoneNumbersTable : public CBaseTable<CPhoneNumbersAccessor, PHONE_NUMBERS>
{
	//Constructors
public:
	///<summary>Конструктор по име на таблицата и сесия</summary>
	CPhoneNumbersTable(CString strTableName, CSession* pSession);

	//Methods
public:
	///<summary>Взима всички телефонни номера по ID на абонат</summary>
	///<param "lPersonID">ID на абоната</summary>
	///<param "oPhoneNumbersArray">Хранилище за резултата</summary>
	///<returns>Дали операцията е изпълнена успешно</returns>
	BOOL SelectAllByPersonID(long lPersonID, CPhoneNumbersArray& oPhoneNumbersArray);

private:
	///<summary>Взима rowset-а</summary>
	virtual PHONE_NUMBERS& GetRowSet() override;

	///<summary>Задава стойност на rowset-а</summary>
	///<param "recPhoneNumber">Стойност за задаване</summary>
	virtual long GetUpdateCounter(PHONE_NUMBERS recPhoneNumber) override;

	///<summary>Взима update_counter-а на телефонен номер</summary>
	///<param "recPhoneNumber">Номерът от който се взима uprade_counter-с</summary>
	virtual void SetRowSetValue(PHONE_NUMBERS recPhoneNumber) override;

	///<summary>Увеличава update_counter-а на телефонен номер с едно</summary>
	///<param "recPhoneNumber">Номерът на който се увеличава uprade_counter-с</summary>
	virtual void IncrementUpdateCounter(PHONE_NUMBERS& recPhoneNumber) override;
};