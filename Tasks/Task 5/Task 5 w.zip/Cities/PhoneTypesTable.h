﻿#pragma once

#include "BaseTable.h"

class CPhoneTypesAccessor
{
protected:
	PHONE_TYPES m_recPhoneType;

	BEGIN_ACCESSOR_MAP(CPhoneTypesAccessor, ACCESSOR_COUNT)
		BEGIN_ACCESSOR(FIRST_ACCESSOR, true)
		COLUMN_ENTRY(FIRST_COLUMN, m_recPhoneType.lID)
		END_ACCESSOR()

		BEGIN_ACCESSOR(FIRST_COLUMN, true)
		COLUMN_ENTRY(SECOND_COLUMN, m_recPhoneType.lUpdateCounter)
		COLUMN_ENTRY(THIRD_COLUMN, m_recPhoneType.szPhoneType)
		END_ACCESSOR()
	END_ACCESSOR_MAP()
};

///<summary>Клас за работа с таблица PHONE_TYPES</summary>
class CPhoneTypesTable : public CBaseTable<CPhoneTypesAccessor, PHONE_TYPES>
{
	//Constructors
public:
	CPhoneTypesTable(CString strTableName, CSession* pSession);

	//Methods
private:
	///<summary>Взима rowset-а</summary>
	virtual PHONE_TYPES& GetRowSet() override;

	///<summary>Задава стойност на rowset-а</summary>
	///<param "recPhoneType">Стойност за задаване</summary>
	virtual void SetRowSetValue(PHONE_TYPES recPhoneType) override;

	///<summary>Взима update_counter-а на телефонен тип</summary>
	///<param "recPhoneType">Телефонният тип от който се взима uprade_counter-с</summary>
	virtual long GetUpdateCounter(PHONE_TYPES recPhoneType) override;

	///<summary>Увеличава update_counter-а на телефонен тип с едно</summary>
	///<param "recPhoneType">Телефонният тип на който се увеличава uprade_counter-с</summary>
	virtual void IncrementUpdateCounter(PHONE_TYPES& recPhoneType) override;
};