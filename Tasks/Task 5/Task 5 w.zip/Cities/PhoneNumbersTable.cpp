#include "stdafx.h"

#include <atlbase.h>

#include <atldbcli.h>

#include <atldbsch.h>

#include "Typedefs.h"

#include "PhoneNumbersTable.h"

CPhoneNumbersTable::CPhoneNumbersTable(CString strTableName, CSession* pSession) 
	: CBaseTable(strTableName, pSession)
{
};

BOOL CPhoneNumbersTable::SelectAllByPersonID(long lPersonID, CPhoneNumbersArray& oPhoneNumbersArray)
{
	CString strQuery;
	strQuery.Format(_T("SELECT * FROM %s WHERE PERSON_ID = %d"), m_strTableName, lPersonID);
	
	if (FAILED(ExecuteQuery(strQuery)))
	{
		Close();
		return FALSE;
	}

	while (true)
	{
		BOOL hResult = MoveNext();
		if (hResult == S_OK)
		{
			PHONE_NUMBERS* pPhoneNumber = new PHONE_NUMBERS();
			*pPhoneNumber = GetRowSet();

			oPhoneNumbersArray.Add(pPhoneNumber);
		}
		else if (hResult == DB_S_ENDOFROWSET)
		{
			break;
		}
		else
		{
			Close();
			return FALSE;
		}
	}
	Close();
	return TRUE;
};

PHONE_NUMBERS& CPhoneNumbersTable::GetRowSet()
{
	return m_recPhoneNumber;
};

long CPhoneNumbersTable::GetUpdateCounter(PHONE_NUMBERS recPhoneNumber)
{
	return recPhoneNumber.lUpdateCounter;
};

void CPhoneNumbersTable::SetRowSetValue(PHONE_NUMBERS recPhoneNumber)
{
	m_recPhoneNumber = recPhoneNumber;
};

void CPhoneNumbersTable::IncrementUpdateCounter(PHONE_NUMBERS & recPhoneNumber)
{
	m_recPhoneNumber.lUpdateCounter += 1;
};
