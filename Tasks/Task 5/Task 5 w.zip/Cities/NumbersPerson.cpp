#include "stdafx.h"

#include "NumbersPerson.h"

CNumbersPerson::CNumbersPerson(PERSONS recPerson)
{
	this->recPerson = recPerson;
};


CNumbersPerson::CNumbersPerson()
{
};
