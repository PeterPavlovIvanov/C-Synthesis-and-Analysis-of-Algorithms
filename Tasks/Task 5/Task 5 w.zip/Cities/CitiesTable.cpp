﻿#include "stdafx.h"

#include <atlbase.h>

#include <atldbcli.h>

#include <atldbsch.h>

#include <typeinfo>

#include "Typedefs.h"

#include "CitiesTable.h"

#include "PropertiesConnectionDB.h"

#include "DBConnectionCreator.h"

CCitiesTable::CCitiesTable(CString strTableName, CSession* pSession) : CBaseTable(strTableName, pSession)
{
};

CITIES & CCitiesTable::GetRowSet()
{
	return m_recCity;
};

void CCitiesTable::SetRowSetValue(CITIES recCity)
{
	m_recCity = recCity;
};

long CCitiesTable::GetUpdateCounter(CITIES recCity)
{
	return m_recCity.lUpdateCounter;
};

void CCitiesTable::IncrementUpdateCounter(CITIES & recCity)
{
	m_recCity.lUpdateCounter += 1;
};
