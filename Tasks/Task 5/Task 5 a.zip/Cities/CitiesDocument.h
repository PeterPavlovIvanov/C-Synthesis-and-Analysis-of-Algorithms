﻿#pragma once

#include "Typedefs.h"

#include "CitiesData.h"

#include "UpdateCodes.h"

/////////////////////////////////////////////////////////////////////////////
// CCitiesDocument

///<summary>Клас хранилище</summary>
class CCitiesDocument : public CDocument
{
	// Macros
	// ----------------
protected: 
	DECLARE_DYNCREATE(CCitiesDocument)
	DECLARE_MESSAGE_MAP()

	// Constructor / Destructor
	// ----------------
protected:
	///<summary>Default-ен конструктор</summary>
	CCitiesDocument();

	//Methods
	// ----------------
public:
	///<summary>Взима всички градове</summary>
	///<returns>Връща BOOL дали е упешна операцията</returns>
	BOOL SelectAll();

	///<summary>Взима град по ID</summary>
	///<param = "nID">ID на града</param>
	///<returns>Връща BOOL дали е упешна операцията</returns>
	BOOL SelectByID(int nID);

	///<summary>Изтрива град по ID</summary>
	///<param = "nID">ID на града</param>
	///<returns>Връща BOOL дали е упешна операцията</returns>
	BOOL DeleteByID(int nID);

	///<summary>Променя град</summary>
	///<param = "recCity">Променения град</param>
	///<returns>Връща BOOL дали е упешна операцията</returns>
	BOOL UpdateCity(const CITIES& recCity);

	///<summary>Добавя град</summary>
	///<param = "recCity">Градът за добавяне</param>
	///<returns>Връща BOOL дали е упешна операцията</returns>
	BOOL InsertCity(CITIES& recCities);

	///<summary>Геттър на градовете</summary>
	///<returns>Връща градовете</returns>
	CCitiesArray& GetCitiesArray()
	{
		return m_oCitiesArray;
	}

	///<summary>Update-ва всички View-та</summary>
	///<param = "eUpdateCodes">Enum - информация какъв ще бъде update-а</param>
	///<param = "recCity">Град за update-ване</param>
	void OnUpdateAllViews(UpdateCodes eUpdateCode, CITIES recCity);

	//Members
	// ----------------
public:
	///<summary>Инстанция на класа за бизнес логика</summary>
	CCitiesData m_oCitiesData;	

	///<summary>Хранилище за град в което се запазва градът от SelectWhereID</summary>
	CITIES m_recCity;

private:
	///<summary>Хранилище за градове - градовете във view-то</summary>
	CCitiesArray m_oCitiesArray;

	// Overrides
	// ----------------
public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
#ifdef SHARED_HANDLERS
	virtual void InitializeSearchContent();
	virtual void OnDrawThumbnail(CDC& dc, LPRECT lprcBounds);
#endif // SHARED_HANDLERS

	// Implementation
	// ----------------
public:
	virtual ~CCitiesDocument();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

#ifdef SHARED_HANDLERS
	// Helper function that sets search content for a Search Handler
	void SetSearchContent(const CString& value);
#endif // SHARED_HANDLERS
};
