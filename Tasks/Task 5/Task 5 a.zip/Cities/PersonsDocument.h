﻿#pragma once

#include "Typedefs.h"

#include "PersonsData.h"

#include "UpdateCodes.h"

/////////////////////////////////////////////////////////////////////////////
// CPersonsDocument

///<summary>Клас хранилище</summary>
class CPersonsDocument : public CDocument
{
	// Macros
	// ----------------
protected:
	DECLARE_DYNCREATE(CPersonsDocument)
	DECLARE_MESSAGE_MAP()

	// Constructor / Destructor
	// ----------------
protected:
	///<summary>Default-ен конструктор</summary>
	CPersonsDocument();
	virtual ~CPersonsDocument();

	//Methods
	// ----------------
public:
	///<summary>Взима всички абонати</summary>
	///<returns>Връща BOOL дали е упешна операцията</returns>
	BOOL SelectAll();

	///<summary>Взима абонат по ID</summary>
	///<param = "nID">ID на абоната</param>
	///<returns>Връща BOOL дали е упешна операцията</returns>
	BOOL SelectByID(int nID);

	///<summary>Изтрива абонат по ID</summary>
	///<param = "nID">ID на абоната</param>
	///<returns>Връща BOOL дали е упешна операцията</returns>
	BOOL DeleteByID(int nID);

	///<summary>Променя абонат</summary>
	///<param = "recPerson">Променения абонат</param>
	///<returns>Връща BOOL дали е упешна операцията</returns>
	BOOL UpdatePerson(const PERSONS& recPerson);

	///<summary>Добавя абонат</summary>
	///<param = "recPersons">Абонатът за добавяне</param>
	///<returns>Връща BOOL дали е упешна операцията</returns>
	BOOL InsertPerson(PERSONS& recPersons);

	///<summary>Геттър на абонатите</summary>
	///<returns>Връща абонатите</returns>
	CPersonsArray& GetPersonsArray()
	{
		return m_oPersonsArray;
	}

	///<summary>Update-ва всички View-та</summary>
	///<param = "eUpdateCodes">Enum - информация какъв ще бъде update-а</param>
	///<param = "recPerson">Абонат за update-ване</param>
	void OnUpdateAllViews(UpdateCodes eUpdateCode, PERSONS recPerson);

	//Members
	// ----------------
public:
	///<summary>Инстанция на класа за бизнес логика</summary>
	CPersonsData m_oPersonsData;

	///<summary>Хранилище за абонат в което се запазва абонатът от SelectWhereID</summary>
	PERSONS m_recPerson;

private:
	///<summary>Хранилище за абонати - абонатите във view-то</summary>
	CPersonsArray m_oPersonsArray;

#ifndef _WIN32_WCE
	virtual void Serialize(CArchive& ar);   // overridden for document i/o
#endif
#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif

protected:
	virtual BOOL OnNewDocument();
};
