#include "stdafx.h"

#include <atlbase.h>

#include <atldbcli.h>

#include <atldbsch.h>

#include "Typedefs.h"

#include "PhoneTypesTable.h"

#include "PropertiesConnectionDB.h"

#include "DBConnectionCreator.h"

CPhoneTypesTable::CPhoneTypesTable()
{

}

BOOL CPhoneTypesTable::ExecuteQuery(CString strQuery)
{
	HRESULT hResult;
	CDBPropSet pPropSet(DBPROPSET_ROWSET);
	CPropertiesConnectionDB oPropConDB;
	oPropConDB.SetPropertiesRows(pPropSet);

	hResult = Open(m_oSession, strQuery, &pPropSet);

	if (FAILED(hResult))
	{
		return FALSE;
	}
	return TRUE;
}

BOOL CPhoneTypesTable::SelectByID(const long lID, PHONE_TYPES& recPhoneType)
{
	CString strQuery;
	strQuery.Format(_T("SELECT * FROM PHONE_TYPES WHERE ID = %d"), lID);

	ExecuteQuery(strQuery);

	if (MoveNext() == S_OK)
	{
		recPhoneType = m_recPhoneType;
	}
	else
	{
		return FALSE;
	}
	return TRUE;
}

BOOL CPhoneTypesTable::SelectAll(CPhoneTypesArray& oPhoneTypesArray)
{
	m_oSession.Open(CDBConnectionCreator::GetInstance().GetDataSource());
	HRESULT hResult;
	CString strQuery;

	strQuery = _T("SELECT * FROM PHONE_TYPES");

	if (FAILED(ExecuteQuery(strQuery)))
	{
		return FALSE;
	}

	while (true)
	{
		hResult = MoveNext();
		if (hResult == S_OK)
		{
			PHONE_TYPES* pPhoneType = new PHONE_TYPES();
			*pPhoneType = m_recPhoneType;

			oPhoneTypesArray.Add(pPhoneType);
		}
		else if (hResult == DB_S_ENDOFROWSET)
		{
			break;
		}
		else
		{
			return FALSE;
		}
	}

	CloseCommandSessionConnection();
	return TRUE;
};

BOOL CPhoneTypesTable::SelectWhereID(const long lID, PHONE_TYPES& recPhoneType)
{
	m_oSession.Open(CDBConnectionCreator::GetInstance().GetDataSource());
	if (FAILED(SelectByID(lID, recPhoneType)))
	{
		return FALSE;
	}

	CloseCommandSessionConnection();
	return TRUE;
};

BOOL CPhoneTypesTable::UpdateWhereID(const long lID, const PHONE_TYPES& recPhoneTypes)
{
	m_oSession.Open(CDBConnectionCreator::GetInstance().GetDataSource());

	PHONE_TYPES recPhoneType;

	if (FAILED(m_oSession.StartTransaction()))
	{
		return FALSE;
	}

	if (FAILED(SelectByID(lID, recPhoneType)))
	{
		m_oSession.Abort();
		return FALSE;
	}

	if (m_recPhoneType.lUpdateCounter != recPhoneTypes.lUpdateCounter)
	{
		m_oSession.Abort();
		AfxMessageBox(_T("Session invalid, please try again."));
		CloseCommandSessionConnection();
		return FALSE;
	}

	m_recPhoneType = recPhoneTypes;
	m_recPhoneType.lUpdateCounter += UPDATE_COUNTER_NUMBER;

	if (FAILED(SetData(SECOND_ACCESSOR)))
	{
		m_oSession.Abort();
		return FALSE;
	}

	m_oSession.Commit();

	CloseCommandSessionConnection();
	return TRUE;
};

BOOL CPhoneTypesTable::Insert(PHONE_TYPES& recPhoneTypes)
{
	m_oSession.Open(CDBConnectionCreator::GetInstance().GetDataSource());

	HRESULT hResult;
	CString strQuery;

	strQuery.Format(_T("SELECT TOP 0 * FROM PHONE_TYPES"));

	if (FAILED(m_oSession.StartTransaction()))
	{
		return FALSE;
	}

	if (FAILED(ExecuteQuery(strQuery)))
	{
		m_oSession.Abort();
		return FALSE;
	}

	hResult = MoveNext();

	if (FAILED(hResult))
	{
		m_oSession.Abort();
		return FALSE;
	}

	m_recPhoneType = recPhoneTypes;
	hResult = __super::Insert(SECOND_ACCESSOR);

	if (FAILED(hResult))
	{
		return FALSE;
	}

	MoveNext();
	recPhoneTypes = m_recPhoneType;

	m_oSession.Commit();

	CloseCommandSessionConnection();
	return TRUE;
};

BOOL CPhoneTypesTable::DeleteWhereID(const long lID)
{
	m_oSession.Open(CDBConnectionCreator::GetInstance().GetDataSource());

	HRESULT hResult;

	PHONE_TYPES oPhoneType;
	if (FAILED(m_oSession.StartTransaction()))
	{
		return FALSE;
	}

	if (FAILED(SelectByID(lID, oPhoneType)))
	{
		m_oSession.Abort();
		return FALSE;
	}

	hResult = Delete();

	if (FAILED(hResult))
	{
		return FALSE;
	}

	m_oSession.Commit();

	CloseCommandSessionConnection();
	return TRUE;
};

CSession & CPhoneTypesTable::GetSession()
{
	return m_oSession;
}

void CPhoneTypesTable::CloseCommandSessionConnection()
{
	Close();
	m_oSession.Close();
}