// CitiesDialog.cpp : implementation file
//

#include "stdafx.h"
#include "PhoneBook.h"
#include "CitiesDialog.h"
#include "afxdialogex.h"


// CCitiesDialog dialog

IMPLEMENT_DYNAMIC(CCitiesDialog, CDialog)

CCitiesDialog::CCitiesDialog(CWnd* pParent /*=NULL*/)
	: CDialog(IDD_CITIES_FORM, pParent)
{

}

CCitiesDialog::~CCitiesDialog()
{
}

void CCitiesDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CCitiesDialog, CDialog)
END_MESSAGE_MAP()


// CCitiesDialog message handlers
