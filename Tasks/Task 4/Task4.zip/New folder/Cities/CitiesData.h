#pragma once

class CCitiesData {

};