#pragma once

#include "afxwin.h"

#include "CitiesTable.h"

#include "Typedefs.h"

class CCitiesDocument : private CDocument {
	//Constructors
public:
	CCitiesDocument();

	//Methods
public:
	CCitiesArray* SelectAllCities();

	//Members
private:
	CCitiesTable m_oCitiesTable;
};