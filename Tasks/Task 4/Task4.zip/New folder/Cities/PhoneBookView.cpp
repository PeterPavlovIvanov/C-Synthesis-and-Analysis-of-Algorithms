﻿
// CitiesView.cpp : implementation of the CCitiesView class
//

#include "stdafx.h"
// SHARED_HANDLERS can be defined in an ATL project implementing preview, thumbnail
// and search filter handlers and allows sharing of document code with that project.
#ifndef SHARED_HANDLERS
#include "PhoneBook.h"
#endif

#include "PhoneBookSet.h"
#include "PhoneBookDoc.h"
#include "PhoneBookView.h"
#include "CitiesDocument.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CCitiesView

IMPLEMENT_DYNCREATE(CPhoneBookView, COleDBRecordView)

BEGIN_MESSAGE_MAP(CPhoneBookView, COleDBRecordView)
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, &COleDBRecordView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &COleDBRecordView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CPhoneBookView::OnFilePrintPreview)
	ON_WM_CONTEXTMENU()
	ON_WM_RBUTTONUP()
END_MESSAGE_MAP()

// CCitiesView construction/destruction

CPhoneBookView::CPhoneBookView()
	: COleDBRecordView(IDD_CITIES_FORM)
{
	m_pSet = NULL;
	// TODO: add construction code here

}

CPhoneBookView::~CPhoneBookView()
{
}

void CPhoneBookView::DoDataExchange(CDataExchange* pDX)
{
	COleDBRecordView::DoDataExchange(pDX);
	// you can insert DDX_* functions, as well as SetDlgItem*/GetDlgItem* API calls to link your database to the view
	// ex. ::SetDlgItemText(m_hWnd, IDC_MYCONTROL, m_pSet->m_MyColumn);
	// See MSDN and OLEDB samples for more information
	DDX_Control(pDX, IDC_LIST7, m_oCities);
}

BOOL CPhoneBookView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return COleDBRecordView::PreCreateWindow(cs);
}

void CPhoneBookView::OnInitialUpdate()
{
	m_pSet = &GetDocument()->m_CitiesSet;
	{
		CWaitCursor wait;
		HRESULT hr = m_pSet->OpenAll();
		if (FAILED(hr))
		{
			// Failed to open recordset.  If the recordset is a 
			// stored procedure, make sure that you have properly
			// initialized any input parameters before calling
			// the OpenAll() method.

			AfxMessageBox(_T("Record set failed to open."), MB_OK);
			// Disable the Next and Previous record commands,
			// since attempting to change the current record without an
			// open RowSet will cause a crash
			m_bOnFirstRecord = TRUE;
			m_bOnLastRecord = TRUE;
		}
		if( hr == DB_S_ENDOFROWSET )
		{
			// the rowset is empty (does not contain any rows)
			AfxMessageBox(_T("Record set opened but there were no rows to return."), MB_OK);
			// Disable the Next and Previous record commands
			m_bOnFirstRecord = TRUE;
			m_bOnLastRecord = TRUE;
		}
	}
	COleDBRecordView::OnInitialUpdate();

	// Insert a column. This override is the most convenient.
	m_oCities.InsertColumn(0, _T("CITY_NAME"), LVCFMT_CENTER);
	m_oCities.InsertColumn(1, _T("REGION"), LVCFMT_CENTER);
	m_oCities.InsertColumn(2, _T("ID"), LVCFMT_CENTER);

	// Set reasonable widths for our columns
	m_oCities.SetColumnWidth(0, 110);
	m_oCities.SetColumnWidth(1, 160);
	m_oCities.SetColumnWidth(2, 50);

	CCitiesDocument oCitiesDocument;
	CCitiesArray* oCitiesArray = oCitiesDocument.SelectAllCities();
	for (int i = 0; i < oCitiesArray->GetCount(); i++) {
		CITIES oCity = *(oCitiesArray->GetAt(i));
		CString strID;
		strID.Format(_T("%d"), oCity.lID);

		int nIndex = m_oCities.InsertItem(0, oCity.szCityName);
		m_oCities.SetItemText(nIndex, 1, oCity.szRegion);
		m_oCities.SetItemText(nIndex, 2, strID);
	}
	
}


// CCitiesView printing

void CPhoneBookView::OnFilePrintPreview()
{
#ifndef SHARED_HANDLERS
	AFXPrintPreview(this);
#endif
}

BOOL CPhoneBookView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CPhoneBookView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CPhoneBookView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

void CPhoneBookView::OnRButtonUp(UINT /* nFlags */, CPoint point)
{
	ClientToScreen(&point);
	OnContextMenu(this, point);
}

void CPhoneBookView::OnContextMenu(CWnd* /* pWnd */, CPoint point)
{
#ifndef SHARED_HANDLERS
	theApp.GetContextMenuManager()->ShowPopupMenu(IDR_POPUP_EDIT, point.x, point.y, this, TRUE);
#endif
}


// CCitiesView diagnostics

#ifdef _DEBUG
void CPhoneBookView::AssertValid() const
{
	COleDBRecordView::AssertValid();
}

void CPhoneBookView::Dump(CDumpContext& dc) const
{
	COleDBRecordView::Dump(dc);
}

CPhoneBookDoc* CPhoneBookView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CPhoneBookDoc)));
	return (CPhoneBookDoc*)m_pDocument;
}
#endif //_DEBUG


// CCitiesView database support
CRowset<>* CPhoneBookView::OnGetRowset()
{
	return m_pSet->GetRowsetBase();
}




// CCitiesView message handlers
