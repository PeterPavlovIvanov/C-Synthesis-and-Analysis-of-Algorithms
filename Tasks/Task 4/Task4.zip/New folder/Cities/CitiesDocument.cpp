#include "stdafx.h"

#include "CitiesDocument.h"

CCitiesDocument::CCitiesDocument()
{
}

CCitiesArray* CCitiesDocument::SelectAllCities()
{
	CCitiesArray* oAllCities = new CCitiesArray();
	m_oCitiesTable.SelectAll(*oAllCities);
	return oAllCities;
}