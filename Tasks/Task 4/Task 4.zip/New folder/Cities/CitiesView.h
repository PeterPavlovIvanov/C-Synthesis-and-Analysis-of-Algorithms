#pragma once


// CCitiesView view

class CCitiesView : public CListView
{
	DECLARE_DYNCREATE(CCitiesView)

protected:
	CCitiesView();           // protected constructor used by dynamic creation
	virtual ~CCitiesView();

public:
#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif
	void OnInitialUpdate();
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnCitiesSelectbyid();
	afx_msg void OnCitiesInsert();
	afx_msg void OnCitiesUpdate();
};


