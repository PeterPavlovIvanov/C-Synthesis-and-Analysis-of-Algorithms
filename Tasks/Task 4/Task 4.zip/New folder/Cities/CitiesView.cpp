// CitiesView.cpp : implementation file
//

#include "stdafx.h"

#include "PhoneBook.h"

#include "CitiesView.h"

#include "CitiesDocument.h"

#include "Typedefs.h"

#include "CitiesDialog.h"

// CCitiesView

IMPLEMENT_DYNCREATE(CCitiesView, CListView)

CCitiesView::CCitiesView()
{

}

CCitiesView::~CCitiesView()
{
}

BEGIN_MESSAGE_MAP(CCitiesView, CListView)
	ON_COMMAND(ID_CITIES_INSERT, &CCitiesView::OnCitiesInsert)
	ON_COMMAND(ID_CITIES_UPDATE, &CCitiesView::OnCitiesUpdate)
END_MESSAGE_MAP()


// CCitiesView diagnostics

#ifdef _DEBUG
void CCitiesView::AssertValid() const
{
	CListView::AssertValid();
}

#ifndef _WIN32_WCE
void CCitiesView::Dump(CDumpContext& dc) const
{
	CListView::Dump(dc);
}
void CCitiesView::OnInitialUpdate()
{
	CListView::OnInitialUpdate();

	CListCtrl& listCtrl = GetListCtrl();
	listCtrl.SetView(LVS_REPORT);

	listCtrl.InsertColumn(1, _T("REGION"), LVCFMT_CENTER, COLUMN_WIDTH);
	listCtrl.InsertColumn(1, _T("CITY_NAME"), LVCFMT_CENTER, COLUMN_WIDTH);
	listCtrl.InsertColumn(2, _T("REGION"), LVCFMT_CENTER, COLUMN_WIDTH);

	CCitiesDocument oCitiesDocument;
	CCitiesArray* oCitiesArray = new CCitiesArray();
	oCitiesArray = oCitiesDocument.SelectAllCities();

	for (int i = 0; i < oCitiesArray->GetCount(); i++)
	{
		CITIES* oCity = oCitiesArray->GetAt(i);
		CString strID;
		strID.Format(_T("%d"), oCity->lID);

		int nIndex = listCtrl.InsertItem(0, oCity->szCityName);
		listCtrl.SetItemText(nIndex, 1, oCity->szRegion);
		listCtrl.SetItemText(nIndex, 2, strID);
	}
}
#endif
#endif //_DEBUG

// CCitiesView message handlers

void CCitiesView::OnCitiesInsert()
{
	CCitiesDialog oDialog;
	oDialog.m_strDlgCaption.Format(_T("Insert city"));
	oDialog.DoModal();
}

void CCitiesView::OnCitiesUpdate()
{
	CCitiesDialog oDialog;
	oDialog.m_strDlgCaption.Format(_T("Update city"));
	oDialog.DoModal();
}
