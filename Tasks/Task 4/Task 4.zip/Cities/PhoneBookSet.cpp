
// CitiesSet.cpp : implementation of the CCitiesSet class
//

#include "stdafx.h"
#include "PhoneBook.h"
#include "PhoneBookSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CCitiesSet implementation

