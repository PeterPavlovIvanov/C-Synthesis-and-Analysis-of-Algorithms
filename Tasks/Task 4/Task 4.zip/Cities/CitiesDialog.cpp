// CitiesDialog.cpp : implementation file
//

#include "stdafx.h"

#include "PhoneBook.h"

#include "CitiesDialog.h"

#include "afxdialogex.h"

#include "Typedefs.h"

#include "CitiesView.h"

// CCitiesDialog dialog

IMPLEMENT_DYNAMIC(CCitiesDialog, CDialog)

CCitiesDialog::CCitiesDialog(CWnd* pParent /*=NULL*/)
	: CDialog(IDD_DIALOG1, pParent)
{

}

CCitiesDialog::~CCitiesDialog()
{
}

void CCitiesDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_CITYNAME, m_CityName);
	DDX_Control(pDX, IDC_REGION, m_Region);
}

BOOL CCitiesDialog::OnInitDialog()
{
	__super::OnInitDialog();
	SetWindowText(m_strDlgCaption);
	return TRUE;
}


BEGIN_MESSAGE_MAP(CCitiesDialog, CDialog)
END_MESSAGE_MAP()


// CCitiesDialog message handlers
