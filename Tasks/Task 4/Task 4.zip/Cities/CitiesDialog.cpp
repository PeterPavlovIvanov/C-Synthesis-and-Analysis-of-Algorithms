// CitiesDialog.cpp : implementation file
//

#include "stdafx.h"

#include "PhoneBook.h"

#include "CitiesDialog.h"

#include "afxdialogex.h"

#include "Typedefs.h"

#include "CitiesView.h"

// CCitiesDialog dialog

IMPLEMENT_DYNAMIC(CCitiesDialog, CDialog)

CCitiesDialog::CCitiesDialog(CWnd* pParent /*=NULL*/)
	: CDialog(IDD_DIALOG1, pParent)
{

}

CCitiesDialog::~CCitiesDialog()
{
}

void CCitiesDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_CITYNAME, m_CityName);
	DDX_Control(pDX, IDC_REGION, m_Region);
}

BOOL CCitiesDialog::OnInitDialog()
{
	__super::OnInitDialog();
	SetWindowText(m_strDlgCaption);
	if(strName != _T("") && strRegion != _T(""))
	{
		SetDlgItemText(IDC_CITYNAME, strName);
		SetDlgItemText(IDC_REGION, strRegion);
	}
	return TRUE;
}

BEGIN_MESSAGE_MAP(CCitiesDialog, CDialog)
	ON_BN_CLICKED(IDOK, &CCitiesDialog::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &CCitiesDialog::OnBnClickedCancel)
END_MESSAGE_MAP()


// CCitiesDialog message handlers

void CCitiesDialog::OnBnClickedOk()
{
	CString strWindowText;

	m_CityName.GetWindowText(strWindowText);
	wcscpy_s(recCity.szCityName, strWindowText);

	m_Region.GetWindowText(strWindowText);
	wcscpy_s(recCity.szRegion, strWindowText);

	// TODO: Add your control notification handler code here
	strName = _T("");
	strRegion = _T("");
	CDialog::OnOK();
}


void CCitiesDialog::OnBnClickedCancel()
{
	// TODO: Add your control notification handler code here
	strName = _T("");
	strRegion = _T("");
	CDialog::OnCancel();
}
