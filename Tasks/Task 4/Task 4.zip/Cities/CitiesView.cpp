﻿// CitiesView.cpp : implementation file
//

#include "stdafx.h"

#include "PhoneBook.h"

#include "CitiesView.h"

#include "CitiesDocument.h"

#include "Typedefs.h"

#include "CitiesDialog.h"

// CCitiesView

#define FIRST_COLUMN 0
#define SECOND_COLUMN 1
#define THIRD_COLUMN 2

IMPLEMENT_DYNCREATE(CCitiesView, CListView)

#define INSERT_OPTION_ID 4001
#define UPDATE_OPTION_ID 4002
#define DELETE_OPTION_ID 4003
#define VIEW_OPTION_ID 4004

CCitiesView::CCitiesView()
{

}

CCitiesView::~CCitiesView()
{
}

BEGIN_MESSAGE_MAP(CCitiesView, CListView)
	ON_COMMAND(ID_CITIES_INSERT, &CCitiesView::OnCitiesInsert)
	ON_COMMAND(ID_CITIES_UPDATE, &CCitiesView::OnCitiesUpdate)
	ON_COMMAND(INSERT_OPTION_ID, &CCitiesView::OnCitiesInsert)
	ON_COMMAND(VIEW_OPTION_ID, &CCitiesView::OnView)
	ON_WM_PAINT()
	ON_WM_CONTEXTMENU()
END_MESSAGE_MAP()


// CCitiesView diagnostics

#ifdef _DEBUG
void CCitiesView::AssertValid() const
{
	CListView::AssertValid();
}

#ifndef _WIN32_WCE
void CCitiesView::Dump(CDumpContext& dc) const
{
	CListView::Dump(dc);
}
void CCitiesView::OnInitialUpdate()
{
	CListView::OnInitialUpdate();

	m_ListCtrl.SetView(LVS_REPORT);

	m_ListCtrl.InsertColumn(0, _T("CITY_NAME"), LVCFMT_CENTER, COLUMN_WIDTH);
	m_ListCtrl.InsertColumn(1, _T("REGION"), LVCFMT_CENTER, COLUMN_WIDTH);
	m_ListCtrl.InsertColumn(2, _T("ID"), LVCFMT_CENTER, COLUMN_WIDTH);

	GetDocument()->SelectAll();
	;

	for (int i = 0; i <GetDocument()->m_oCitiesArray.GetCount(); i++)
	{
		CITIES* oCity = GetDocument()->m_oCitiesArray.GetAt(i);
		CString strID;
		strID.Format(_T("%d"), oCity->lID);

		int nIndex = m_ListCtrl.InsertItem(FIRST_COLUMN, oCity->szCityName);
		m_ListCtrl.SetItemText(nIndex, SECOND_COLUMN, oCity->szRegion);
		m_ListCtrl.SetItemText(nIndex, THIRD_COLUMN, strID);
	}
}
#endif
#endif //_DEBUG

BOOL CCitiesView::InsertCity(const CITIES & recCities)
{
	return GetDocument()->InsertCity(recCities);
}

BOOL CCitiesView::UpdateCity(const CITIES & recCity)
{
	return GetDocument()->UpdateCity(recCity);
}

BOOL CCitiesView::DeleteCity(int nID)
{
	return GetDocument()->DeleteByID(nID);
}

BOOL CCitiesView::SelectCityByID(int nID)
{
	return GetDocument()->SelectByID(nID);
}

CCitiesDocument * CCitiesView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CCitiesDocument)));
	return (CCitiesDocument*)m_pDocument;
}

// CCitiesView message handlers

void CCitiesView::OnCitiesInsert()
{
	CCitiesDialog oDialog;
	oDialog.m_strDlgCaption.Format(_T("Insert city"));
	if (oDialog.DoModal() == IDOK)
	{
		OnInsert(oDialog.recCity);
	}
	else if (oDialog.DoModal() == IDCANCEL) 
	{

	}
};

void CCitiesView::OnCitiesUpdate()
{
	CCitiesDialog oDialog;
	oDialog.m_strDlgCaption.Format(_T("Update city"));
	oDialog.DoModal();
};

void CCitiesView::OnContextMenu(CWnd* pWnd, CPoint point)
{
	//Sample 01: Declarations
	CRect client_rect;
	CMenu MainMenu;

	//Sample 02: Get Mouse Click position and convert it to the Screen Co-ordinate
	GetClientRect(&client_rect);
	ClientToScreen(&client_rect);

	//Sample 03: Check the mouse pointer position is inside the client area
	if (client_rect.PtInRect(point))
	{
		//Sample 05:Create the Main Menu
		MainMenu.CreatePopupMenu();
		MainMenu.AppendMenu(MF_STRING, INSERT_OPTION_ID, _T("Insert"));
		MainMenu.AppendMenu(MF_STRING, UPDATE_OPTION_ID, _T("Update"));
		MainMenu.AppendMenu(MF_STRING, DELETE_OPTION_ID, _T("Delete"));
		MainMenu.AppendMenu(MF_STRING, VIEW_OPTION_ID, _T("View"));

		//Sample 06: Display the Popup Menu
		MainMenu.TrackPopupMenu(TPM_LEFTALIGN, point.x, point.y, this);
	}
	else
	{
		CWnd::OnContextMenu(pWnd, point);
	}

}

BOOL CCitiesView::OnInsert(CITIES& recCity)
{	
	return InsertCity(recCity);
};

void CCitiesView::OnView() 
{
	CCitiesDialog oDialog;
	oDialog.m_strDlgCaption.Format(_T("View city"));

	CITIES* recCity = new CITIES();
	POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();

	if (pos == NULL)
	{
		TRACE(_T("No items were selected!\n"));
	}
	else
	{
		while (pos)
		{
			int nItem = m_ListCtrl.GetNextSelectedItem(pos);
			recCity = GetDocument()->m_oCitiesArray.GetAt(GetDocument()->m_oCitiesArray.GetCount() - nItem - 1);
			break;
		}
	}

	oDialog.OnViewCity(recCity->szCityName, recCity->szRegion);
	oDialog.DoModal();
};