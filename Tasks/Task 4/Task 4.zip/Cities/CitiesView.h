#pragma once

#include "CitiesDocument.h"
// CCitiesView view

class CCitiesView : public CListView
{
	DECLARE_DYNCREATE(CCitiesView)

public:
	CCitiesView();           // protected constructor used by dynamic creation
	virtual ~CCitiesView();

public:
#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif
	void OnInitialUpdate();
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnCitiesInsert();
	afx_msg void OnCitiesUpdate();
	BOOL InsertCity(const CITIES& recCities);
	BOOL UpdateCity(const CITIES& recCity);
	BOOL DeleteCity(int nID);
	BOOL SelectCityByID(int nID);
	CCitiesDocument* GetDocument() const;
	void OnContextMenu(CWnd* pWnd, CPoint point);
	BOOL OnInsert(CITIES& recCity);
	void OnView();

private:
	CListCtrl& m_ListCtrl = GetListCtrl();
};


