﻿#pragma once

#include "PhoneBookSet.h"

#include "Typedefs.h"

#include "CitiesData.h"

/////////////////////////////////////////////////////////////////////////////
// CCitiesDocument

///<summary>Клас хранилище</summary>
class CCitiesDocument : public CDocument
{
	// Macros
	// ----------------
protected: 
	DECLARE_DYNCREATE(CCitiesDocument)
	DECLARE_MESSAGE_MAP()

	// Constructor / Destructor
	// ----------------
protected:
	///<summary>Default-ен конструктор</summary>
	CCitiesDocument();

	//Methods
public:
	///
	BOOL SelectAll();
	BOOL SelectByID(int nID);
	BOOL DeleteByID(int nID);
	BOOL UpdateCity(const CITIES& recCity);
	BOOL InsertCity(const CITIES& recCities);
	void OnUpdateAllViews();

	//Members
public:
	CPhoneBookSet m_PhoneBookSet;
	CCitiesData m_oCitiesData;
	CCitiesArray m_oCitiesArray;
	CITIES m_recCity;

	// Overrides
public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
#ifdef SHARED_HANDLERS
	virtual void InitializeSearchContent();
	virtual void OnDrawThumbnail(CDC& dc, LPRECT lprcBounds);
#endif // SHARED_HANDLERS

	// Implementation
public:
	virtual ~CCitiesDocument();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

#ifdef SHARED_HANDLERS
	// Helper function that sets search content for a Search Handler
	void SetSearchContent(const CString& value);
#endif // SHARED_HANDLERS
};
