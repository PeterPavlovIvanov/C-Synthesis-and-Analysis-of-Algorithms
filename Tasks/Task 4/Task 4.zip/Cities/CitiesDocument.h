#pragma once

#include "PhoneBookSet.h"

#include "Typedefs.h"

#include "CitiesData.h"

class CCitiesDocument : public CDocument
{
protected: // create from serialization only
	CCitiesDocument();
	DECLARE_DYNCREATE(CCitiesDocument)

// Attributes
public:
	CPhoneBookSet m_PhoneBookSet;
	CCitiesArray* SelectAll();
	BOOL SelectByID(int nID);
	BOOL DeleteByID(int nID);
	BOOL UpdateCity(const CITIES& recCity);
	BOOL InsertCity(const CITIES& recCities);
	void OnUpdateAllViews();

	//Members
public:
	CCitiesData m_oCitiesData;
	//CCitiesArray m_oCitiesArray;
	CITIES m_recCity;

// Operations
public:

// Overrides
public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
#ifdef SHARED_HANDLERS
	virtual void InitializeSearchContent();
	virtual void OnDrawThumbnail(CDC& dc, LPRECT lprcBounds);
#endif // SHARED_HANDLERS

// Implementation
public:
	virtual ~CCitiesDocument();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()

#ifdef SHARED_HANDLERS
	// Helper function that sets search content for a Search Handler
	void SetSearchContent(const CString& value);
#endif // SHARED_HANDLERS
};
