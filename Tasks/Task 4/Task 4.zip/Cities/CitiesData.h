#pragma once

#include "CitiesTable.h"

#include "Typedefs.h"

class CCitiesData {
	//Constructors
public:
	CCitiesData();

	//Methods
public:
	CCitiesArray* SelectAllCities();
	BOOL InsertCity(const CITIES& recCities);
	BOOL DeleteByID(int nID);
	BOOL Update(const CITIES& recCity);
	BOOL SelectByID(int nID, CITIES& recCities);

	//Members
private:
	CCitiesTable m_oCitiesTable;
};