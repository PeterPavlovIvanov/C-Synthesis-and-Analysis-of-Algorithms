﻿#pragma once

#include "CitiesTable.h"

#include "Typedefs.h"

/////////////////////////////////////////////////////////////////////////////
// CCitiesData

///<summary>Клас с бизнес логика</summary>
class CCitiesData {

	// Constructor / Destructor
	// ----------------
public:
	///<summary>Default-ен конструктор</summary>
	CCitiesData();

	//Methods
public:
	///<summary>Функция която взима всички градове</summary>
	CCitiesArray* SelectAllCities();

	///<summary>Функция която добавя град</summary>
	///<returns>Успешно ли е добавен градътс</returns>
	BOOL InsertCity(const CITIES& recCities);

	///<summary>Функция която изтрива град</summary>
	///<returns>Успешно ли е изтрит градът</returns>
	BOOL DeleteByID(int nID);

	///<summary>Функция която променя град</summary>
	///<returns>Успешно ли е променен градът</returns>
	BOOL Update(const CITIES& recCity);

	///<summary>Функция която взима град</summary>
	///<returns>Успешно ли е взет градът</returns>
	BOOL SelectByID(int nID, CITIES& recCities);

	//Members
private:
	///<summary>Инстанция на CCitiesTable върху която се извикват методи</summary>
	CCitiesTable m_oCitiesTable;
};