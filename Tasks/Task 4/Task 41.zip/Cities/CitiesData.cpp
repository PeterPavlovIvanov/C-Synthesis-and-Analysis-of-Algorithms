#include "stdafx.h"

#include "CitiesData.h"

CCitiesData::CCitiesData()
{
}

CCitiesArray* CCitiesData::SelectAllCities()
{
	CCitiesArray* oAllCities = new CCitiesArray();
	m_oCitiesTable.SelectAll(*oAllCities);
	return oAllCities;
}

BOOL CCitiesData::InsertCity(const CITIES& recCities) {
	return m_oCitiesTable.Insert(recCities);
}