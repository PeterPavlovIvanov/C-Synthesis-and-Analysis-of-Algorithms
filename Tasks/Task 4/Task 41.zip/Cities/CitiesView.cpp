﻿// CitiesView.cpp : implementation file
//

#include "stdafx.h"

#include "PhoneBook.h"

#include "CitiesView.h"

#include "CitiesDocument.h"

#include "Typedefs.h"

#include "CitiesDialog.h"

// CCitiesView

IMPLEMENT_DYNCREATE(CCitiesView, CListView)

CCitiesView::CCitiesView()
{

}

CCitiesView::~CCitiesView()
{
}

BEGIN_MESSAGE_MAP(CCitiesView, CListView)
	ON_COMMAND(ID_CITIES_INSERT, &CCitiesView::OnCitiesInsert)
	ON_COMMAND(ID_CITIES_UPDATE, &CCitiesView::OnCitiesUpdate)
END_MESSAGE_MAP()


// CCitiesView diagnostics

#ifdef _DEBUG
void CCitiesView::AssertValid() const
{
	CListView::AssertValid();
}

#ifndef _WIN32_WCE
void CCitiesView::Dump(CDumpContext& dc) const
{
	CListView::Dump(dc);
}
void CCitiesView::OnInitialUpdate()
{
	CListView::OnInitialUpdate();

	m_listCtrl.SetView(LVS_REPORT);

	m_listCtrl.InsertColumn(0, _T("CITY_NAME"), LVCFMT_CENTER, COLUMN_WIDTH);
	m_listCtrl.InsertColumn(1, _T("REGION"), LVCFMT_CENTER, COLUMN_WIDTH);
	m_listCtrl.InsertColumn(2, _T("ID"), LVCFMT_CENTER, COLUMN_WIDTH);

	CCitiesArray* oCitiesArray = GetDocument()->SelectAll();

	for (int i = 0; i < oCitiesArray->GetCount(); i++)
	{
		CITIES* oCity = oCitiesArray->GetAt(i);
		CString strID;
		strID.Format(_T("%d"), oCity->lID);

		int nIndex = m_listCtrl.InsertItem(0, oCity->szCityName);
		m_listCtrl.SetItemText(nIndex, 1, oCity->szRegion);
		m_listCtrl.SetItemText(nIndex, 2, strID);
	}
}
#endif
#endif //_DEBUG

void CCitiesView::InsertCity(const CITIES & recCities)
{
	GetDocument()->InsertCity(recCities);
}

CCitiesDocument * CCitiesView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CCitiesDocument)));
	return (CCitiesDocument*)m_pDocument;
}

// CCitiesView message handlers

void CCitiesView::OnCitiesInsert()
{
	CCitiesDialog oDialog;
	oDialog.m_strDlgCaption.Format(_T("Insert city"));
	oDialog.DoModal();
};

void CCitiesView::OnCitiesUpdate()
{
	CCitiesDialog oDialog;
	oDialog.m_strDlgCaption.Format(_T("Update city"));
	oDialog.DoModal();
};
