#pragma once


// CCitiesDialog dialog

class CCitiesDialog : public CDialog
{
	DECLARE_DYNAMIC(CCitiesDialog)

public:
	CCitiesDialog(CWnd* pParent = NULL);   // standard constructor
	virtual ~CCitiesDialog();
	CString m_strDlgCaption;

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG1 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	BOOL OnInitDialog() override;

	DECLARE_MESSAGE_MAP()
};
