// CitiesDialog.cpp : implementation file
//

#include "stdafx.h"
#include "PhoneBook.h"
#include "CitiesDialog.h"
#include "afxdialogex.h"


// CCitiesDialog dialog

IMPLEMENT_DYNAMIC(CCitiesDialog, CDialog)

CCitiesDialog::CCitiesDialog(CWnd* pParent /*=NULL*/)
	: CDialog(IDD_DIALOG1, pParent)
{

}

CCitiesDialog::~CCitiesDialog()
{
}

void CCitiesDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BOOL CCitiesDialog::OnInitDialog()
{
	SetWindowText(m_strDlgCaption);
	return TRUE;
}


BEGIN_MESSAGE_MAP(CCitiesDialog, CDialog)
END_MESSAGE_MAP()


// CCitiesDialog message handlers
