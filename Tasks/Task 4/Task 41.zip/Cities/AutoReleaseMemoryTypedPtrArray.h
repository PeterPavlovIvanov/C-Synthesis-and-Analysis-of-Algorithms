#pragma once

template<typename T>
class CAutoReleaseMemoryTypedPtrArray : public CTypedPtrArray<CPtrArray, T*>
{
	//Constructors
public:
	CAutoReleaseMemoryTypedPtrArray() {

	}
	~CAutoReleaseMemoryTypedPtrArray() {
		for (int i = 0; i < GetCount(); i++) {
			delete GetAt(i);
		}
		RemoveAll();
	}

};