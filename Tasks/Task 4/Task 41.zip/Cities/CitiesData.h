#pragma once

#include "CitiesTable.h"

#include "Typedefs.h"

class CCitiesData {
	//Constructors
public:
	CCitiesData();

	//Methods
public:
	CCitiesArray* SelectAllCities();
	BOOL InsertCity(const CITIES& recCities);

	//Members
private:
	CCitiesTable m_oCitiesTable;
};