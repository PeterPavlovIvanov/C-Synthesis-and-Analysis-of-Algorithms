﻿#pragma once
#include "afxwin.h"
#include "DialogModes.h"
#include "Typedefs.h"
#include "NumbersPerson.h"

// CPhoneNumbersDialog dialog

class CPhoneNumbersDialog : public CDialog
{
	DECLARE_DYNAMIC(CPhoneNumbersDialog)

public:
	CPhoneNumbersDialog(DialogModes eDialogMode, PHONE_NUMBERS& recPHONE_NUMBERS,
		CPhoneTypesArray& oPhoneTypesArray, CWnd* pParent = NULL);   // standard constructor
	virtual ~CPhoneNumbersDialog();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_PHONE_NUMBERS_DIALOG };
#endif

	//Methods
public:
	///<summary>Записва input-а от диалога в полетата</summary>
	///<returns>Дали input-а е валиден</returns>
	BOOL DialogToBuf();

	///<summary>Задава заглавие и полетата на диалога</summary>
	///<returns>Дали операцията е упсешна</returns>
	BOOL OnInitDialog() override;

private:
	///<summary>Валидира дали номерът е от цифри</summary>:
	///<param "nStartIndex">Index от който да започне проверката</param>
	///<param "strNumber">Номерът за валидиране</param>
	///<param "bResult">Променлива за валидност</param>
	///<param "message">Променлива за съхранение на грешката</param>
	void ValidateNumberSymbols(int nStartIndex, CString strNumber, BOOL& bResult, CString& message);

	///<summary>Валидира дали номер спрямо дължина и символи</summary>:
	///<param "strNumber">Номерът за валидиране</param>
	///<param "bResult">Променлива за валидност</param>
	///<param "message">Променлива за съхранение на грешката</param>
	void ValidateNumber(CString strNumber, BOOL& bResult, CString& message);

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()

	//Members
public:
	///<summary>Edit control- поле за показване/въвеждане на номерът</summary>
	CEdit editNumber;

	///<summary>Drop-down лист за показване/въвеждане на телефонните типове</summary>
	CComboBox comboPhoneType;

	///<summary>ID на телефонния тип</summary>
	long lPhoneTypeID;

private:
	///<summary>Enum за режимите на диалога</summary>
	DialogModes m_eDialogMode;

	///<summary>Телефонен номер</summary>
	PHONE_NUMBERS& m_recPhoneNumber;

	///<summary>Име на диалогът</summary>
	CString m_strDlgCaption;

	///<summary>Масив с телефонните типове</summary>
	CPhoneTypesArray& m_oPhoneTypesArray;

public:
	///<summary>Метод извикващ се при натискане на OK на диалога, пълни или взима от полетата в него</summary>
	afx_msg void OnBnClickedOk();

	///<summary>Метод извикващ се при натискане на Cancel на диалога, прекратява действието.</summary>
	afx_msg void OnBnClickedCancel();
	afx_msg void OnEnChangeEdbPhoneNumbersNumber();
};
