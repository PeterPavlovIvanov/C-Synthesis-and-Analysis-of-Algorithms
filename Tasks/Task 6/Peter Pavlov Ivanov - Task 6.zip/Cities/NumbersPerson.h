﻿#pragma once

#include "Typedefs.h"

///<summary>Транспортен клас, съдържащ абонат и телефонните му номери</summary>
class CNumbersPerson
{
	//Constructors
public:
	///<summary>default-ен Конструктор</summary>
	CNumbersPerson();

	//Members
public:
	///<summary>Абонат</summary>
	PERSONS recPerson;

	///<summary>Телефонни номери</summary>
	CPhoneNumbersArray oPhoneNumbersArray;
};