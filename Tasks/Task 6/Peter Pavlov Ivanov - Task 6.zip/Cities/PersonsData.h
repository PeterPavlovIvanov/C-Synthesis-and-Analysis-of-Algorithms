﻿#pragma once

#include "PersonsTable.h"

#include "Typedefs.h"

#include "NumbersPerson.h"

/////////////////////////////////////////////////////////////////////////////
// CPersonsData

///<summary>Клас с бизнес логика</summary>
class CPersonsData
{

	// Constructor / Destructor
	// ----------------
public:
	///<summary>Default-ен конструктор</summary>
	CPersonsData();

	//Methods
	// ----------------
public:
	///<summary>Функция която взима всички абонати</summary>
	///<param = "oPersonsArray">Масив от абонати в който се запазва резултата от SelectAll</param>
	BOOL SelectAll(CPersonsArray& oPersonsArray);

	///<summary>Функция която добавя абонат и телефоните му</summary>
	///<param = "oNumbersPerson">Абонат за добавяне</param>
	///<returns>Успешно ли е добавен абонатът</returns>
	BOOL Insert(CNumbersPerson& oNumbersPerson);

	///<summary>Функция която изтрива абонат</summary>
	///<param = "nID">ID на абоната за изтриване</param>
	///<returns>Успешно ли е изтрит абоната</returns>
	BOOL DeleteWhereID(int nID);

	///<summary>Функция която променя абонат</summary>
	///<param = "oNumbersPerson">Променения абонат и номерите му</param>
	///<returns>Успешно ли е променен абонатът</returns>
	BOOL UpdatePerson(CNumbersPerson& oNumbersPerson);

	///<summary>Функция която взима абонат</summary>
	///<param = "oNumbersPerson">Хранилище в което се запазва резултата от SelectWhereID</param>
	///<returns>Успешно ли е взет абонатът</returns>
	BOOL SelectWhereID(int nID, CNumbersPerson& oNumbersPerson);
};