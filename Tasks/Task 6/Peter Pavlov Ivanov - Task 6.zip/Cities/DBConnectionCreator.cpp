﻿#pragma once

#include "stdafx.h"

#include "DBConnectionCreator.h"

CDBConnectionCreator CDBConnectionCreator::m_instance;

CDBConnectionCreator& CDBConnectionCreator::GetInstance()
{
	return m_instance;
};

HRESULT CDBConnectionCreator::CreateConnection()
{
	CDBPropSet oDBPropSet(DBPROPSET_DBINIT);
	CPropertiesConnectionDB oPropConDB;
	oPropConDB.SetPropertiesDB(oDBPropSet);

	// Свързваме се към базата данни
	if (FAILED(m_oDataSource.Open(_T("SQLOLEDB.1"), &oDBPropSet)))
	{
		return FALSE;
	}
	return TRUE;
};

void  CDBConnectionCreator::CloseConnection()
{
	m_oDataSource.Close();
};

CDataSource& CDBConnectionCreator::GetDataSource() 
{
	return m_oDataSource;
};