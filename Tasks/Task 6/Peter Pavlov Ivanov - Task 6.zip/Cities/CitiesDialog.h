﻿#pragma once

#include "afxwin.h"

#include "DialogModes.h"

#include "CitiesView.h"

/////////////////////////////////////////////////////////////////////////////
// CCitiesDialog

///<summary>Клас Диалог за Upate/Insert/View/Delete</summary>
class CCitiesDialog : public CDialog
{
	DECLARE_DYNAMIC(CCitiesDialog)

	// Constructor / Destructor
	// ----------------
public:
	///<summary>Standard-ен конструктор</summary>
	CCitiesDialog(CITIES& recCity, DialogModes eDialogMode, CWnd* pParent = NULL);

	///<summary>Виртуален Деструктор<summary>
	virtual ~CCitiesDialog();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG1 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()

	//Methods
	// ----------------
public:
	///<summary>При OK взима стойностите от диалога и Set-ва името и региона в recCity.</summary>
	afx_msg void OnBnClickedOk();

	///<summary>При Cancel чисти полетата.</summary>
	afx_msg void OnBnClickedCancel();

	///<summary>Чисти полетата</summary>
	void CleanFields();

	///<summary>Записва input-а от диалога в полетата</summary>
	///<returns>Дали input-а е валиден</returns>
	BOOL DialogToBuf();

	///<summary>Задава заглавие и полетата на диалога</summary>
	///<returns>Дали операцията е упсешна</returns>
	BOOL OnInitDialog() override;

private:
	///<summary>Валидира въведеният string в поле</summary>
	///<param "strWindowText">input-а на потребителя</param>
	///<param "message">Съобщение в което се добавят грешките</param>
	///<param "bResult">Запазва дали е валиден input-а</param>
	///<param "strFieldName">Името на полето за валидиране</param>
	void ValidateStringOnlyLetters(CString strWindowText, CString& message, BOOL& bResult, CString strFieldName);

	//Members
	// ----------------
private:
	///<summary>Режим на диалога</summary>
	DialogModes m_eDialogMode;

	///<summary>Град с който се оперира в различните методи</summary>
	CITIES& m_recCity;
public:
	///<summary>CEdit - input-а за името на града</summary>
	CEdit editCityName;
	
	///<summary>CEdit - input-а за региона на града</summary>
	CEdit editRegion;

	///<summary>Името на диалога</summary>
	CString m_strDlgCaption;

};