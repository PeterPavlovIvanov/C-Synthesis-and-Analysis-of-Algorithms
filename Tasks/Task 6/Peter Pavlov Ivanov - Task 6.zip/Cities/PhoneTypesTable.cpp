﻿#include "stdafx.h"

#include <atlbase.h>

#include <atldbcli.h>

#include <atldbsch.h>

#include "Typedefs.h"

#include "PhoneTypesTable.h"

CPhoneTypesTable::CPhoneTypesTable(CString strTableName, CSession* oSession) 
	: CBaseTable(strTableName, oSession)
{
};

CPhoneTypesTable::CPhoneTypesTable(CString strTableName) : CBaseTable(strTableName)
{
};

PHONE_TYPES & CPhoneTypesTable::GetRowSet()
{
	return m_recPhoneType;
};

long* CPhoneTypesTable::GetUpdateCounter(PHONE_TYPES& recPhoneType)
{
	return &(recPhoneType.lUpdateCounter);
};

void CPhoneTypesTable::Trim()
{
	wchar_t cSpace = ' ';
	CString strPhoneType = m_recPhoneType.szPhoneType;
	int nIndex = strPhoneType.GetLength() - FIX_TO_LAST_INDEX;

	//премахваме space-овете от телефонния тип
	while (m_recPhoneType.szPhoneType[nIndex] == cSpace) {
		m_recPhoneType.szPhoneType[nIndex] = NULL;
		nIndex--;
	}
};
