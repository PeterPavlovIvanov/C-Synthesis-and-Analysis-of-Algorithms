﻿#include "stdafx.h"

#include <atlbase.h>

#include <atldbcli.h>

#include <atldbsch.h>

#include "Typedefs.h"

#include "PersonsTable.h"

CPersonsTable::CPersonsTable(CString strTableName, CSession* oSession) : CBaseTable(strTableName, oSession)
{

}
CPersonsTable::CPersonsTable(CString strTableName) : CBaseTable(strTableName)
{
};

PERSONS& CPersonsTable::GetRowSet()
{
	return m_recPerson;
};

long* CPersonsTable::GetUpdateCounter(PERSONS& recPerson)
{
	return &(recPerson.lUpdateCounter);
};

void CPersonsTable::Trim()
{
	wchar_t cSpace = ' ';
	CString strFirstName(m_recPerson.szFirstName), strMiddleName(m_recPerson.szMiddleName),
		strLastName(m_recPerson.szLastName), strUCN(m_recPerson.szUCN), strAddress(m_recPerson.szAddress);
	
	int nIndex = strFirstName.GetLength() - FIX_TO_LAST_INDEX;
	//премахваме space-овете от собственото име
	while (m_recPerson.szFirstName[nIndex] == cSpace) {
		m_recPerson.szFirstName[nIndex] = NULL;
		nIndex--;
	}

	nIndex = strMiddleName.GetLength() - FIX_TO_LAST_INDEX;

	//премахваме space-овете от презимето
	while (m_recPerson.szMiddleName[nIndex] == cSpace) {
		m_recPerson.szMiddleName[nIndex] = NULL;
		nIndex--;
	}

	nIndex = strLastName.GetLength() - FIX_TO_LAST_INDEX;

	//премахваме space-овете от фамилията
	while (m_recPerson.szLastName[nIndex] == cSpace) {
		m_recPerson.szLastName[nIndex] = NULL;
		nIndex--;
	}

	nIndex = strUCN.GetLength() - FIX_TO_LAST_INDEX;

	//премахваме space-овете от ЕГН-то
	while (m_recPerson.szUCN[nIndex] == cSpace) {
		m_recPerson.szUCN[nIndex] = NULL;
		nIndex--;
	}

	nIndex = strAddress.GetLength() - FIX_TO_LAST_INDEX;

	//премахваме space-овете от адреса
	while (m_recPerson.szAddress[nIndex] == cSpace) {
		m_recPerson.szAddress[nIndex] = NULL;
		nIndex--;
	}
};