//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Cities.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDP_FAILED_OPEN_DATABASE        103
#define IDR_POPUP_EDIT                  119
#define ID_STATUSBAR_PANE1              120
#define ID_STATUSBAR_PANE2              121
#define IDS_STATUS_PANE1                122
#define IDS_STATUS_PANE2                123
#define IDS_TOOLBAR_STANDARD            124
#define IDS_TOOLBAR_CUSTOMIZE           125
#define ID_VIEW_CUSTOMIZE               126
#define IDR_MAINFRAME                   128
#define IDR_MAINFRAME_256               129
#define IDR_CitiesTYPE                  130
#define ID_WINDOW_MANAGER               131
#define IDR_PhoneTypesTYPE              132
#define IDR_PersonsTYPE                 133
#define IDS_EDIT_MENU                   306
#define IDD_DIALOG1                     311
#define IDD_CITIES_DIALOG               311
#define IDD_DIALOG2                     315
#define IDD_PHONE_TYPES_DIALOG          315
#define IDD_DIALOG3                     317
#define IDD_PERSONS_DIALOG              317
#define IDD_DIALOG4                     319
#define IDD_PHONE_NUMBERS_DIALOG        319
#define IDR_MENU1                       323
#define IDC_EDB_CITIES_NAME             1014
#define IDC_EDB_CITIES_REGION           1018
#define IDC_EDIT1                       1019
#define IDC_EDIT_PERSONS_FIRST_NAME     1019
#define IDC_EDB_PHONE_NUMBERS_NUMBER    1019
#define IDC_EDB_PHONE_TYPES_NAME        1020
#define IDC_EDIT_PERSONS_MIDDLE_NAME    1020
#define IDC_EDIT_PERSONS_UCN            1021
#define IDC_EDIT_PERSONS_LAST_NAME      1022
#define IDC_COMBO_PERSONS_CITY          1024
#define IDC_LIST_PERSONS_NUMBERS        1025
#define IDC_COMBO1                      1026
#define IDC_CMB_PHONE_NUMBERS_PHONE_TYPE 1026
#define IDC_LIST1                       1027
#define IDC_EDIT_PERSONS_ADDRESS        1028
#define INSERT_OPTION_ID                4001
#define UPDATE_OPTION_ID                4002
#define DELETE_OPTION_ID                4003
#define VIEW_OPTION_ID                  4004
#define INSERT_PHONE_TYPE_OPTION_ID     4005
#define UPDATE_PHONE_TYPE_OPTION_ID     4006
#define DELETE_PHONE_TYPE_OPTION_ID     4007
#define VIEW_PHONE_TYPE_OPTION_ID       4008
#define INSERT_PERSON_OPTION_ID         4009
#define UPDATE_PERSON_OPTION_ID         4010
#define DELETE_PERSON_OPTION_ID         4011
#define VIEW_PERSON_OPTION_ID           4012
#define INSERT_PHONE_NUMBERS_OPTION_ID  4013
#define UPDATE_PHONE_NUMBERS_OPTION_ID  4014
#define VIEW_PHONE_NUMBERS_OPTION_ID    4015
#define DELETE_PHONE_NUMBERS_OPTION_ID  4016
#define ID_CITIES_SELECTBYID            32771
#define ID_CITIES_UPDATE                32773
#define ID_TABLES_CITIES                32774
#define ID_TABLES_PHONE                 32775
#define ID_RECORDS_CITIES               32776
#define ID_RECORDS_PHONE                32777
#define ID_UPDATE_INSERT                32778
#define ID_EDIT_INSERT                  32781
#define ID_EDIT_UPDATE                  32782
#define ID_EDIT_DELETE                  32783

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        324
#define _APS_NEXT_COMMAND_VALUE         32784
#define _APS_NEXT_CONTROL_VALUE         1028
#define _APS_NEXT_SYMED_VALUE           310
#endif
#endif
