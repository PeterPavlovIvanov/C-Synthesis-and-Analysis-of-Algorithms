﻿// PersonsView.cpp : implementation file
//

#include "stdafx.h"

#include "PhoneBook.h"

#include "PersonsView.h"

#include "DialogModes.h"

#include "PersonsDialog.h"

// CPersonsView

#define FIRST__COLUMN 0
#define SECOND__COLUMN 1
#define THIRD__COLUMN 2
#define FOURTH__COLUMN 3
#define FIFTH__COLUMN 4
#define SIXTH__COLUMN 5
#define SEVENTH__COLUMN 6
#define EIGHT__COLUMN 7

IMPLEMENT_DYNCREATE(CPersonsView, CListView)

CPersonsView::CPersonsView()
{

}

CPersonsView::~CPersonsView()
{
}

BEGIN_MESSAGE_MAP(CPersonsView, CListView)
	ON_COMMAND(INSERT_PERSON_OPTION_ID, &CPersonsView::OnPersonsInsert)
	ON_COMMAND(DELETE_PERSON_OPTION_ID, &CPersonsView::OnPersonsDelete)
	ON_COMMAND(VIEW_PERSON_OPTION_ID, &CPersonsView::OnPersonsView)
	ON_COMMAND(UPDATE_PERSON_OPTION_ID, &CPersonsView::OnPersonsUpdate)
	ON_WM_PAINT()
	ON_WM_CONTEXTMENU()
END_MESSAGE_MAP()


// CPersonsView diagnostics

#ifdef _DEBUG
void CPersonsView::AssertValid() const
{
	CListView::AssertValid();
}

#ifndef _WIN32_WCE
void CPersonsView::Dump(CDumpContext& dc) const
{
	CListView::Dump(dc);
}

void CPersonsView::OnInitialUpdate()
{
	m_ListCtrl.SetView(LVS_REPORT);

	m_ListCtrl.SetExtendedStyle(m_ListCtrl.GetExtendedStyle() | LVS_EX_FULLROWSELECT);

	m_ListCtrl.InsertColumn(FIRST__COLUMN, _T("FIRST_NAME"), LVCFMT_CENTER, COLUMN_WIDTH);
	m_ListCtrl.InsertColumn(SECOND__COLUMN, _T("MIDDLE_NAME"), LVCFMT_CENTER, COLUMN_WIDTH);
	m_ListCtrl.InsertColumn(THIRD__COLUMN, _T("LAST_NAME"), LVCFMT_CENTER, COLUMN_WIDTH);
	m_ListCtrl.InsertColumn(FOURTH__COLUMN, _T("UCN"), LVCFMT_CENTER, COLUMN_WIDTH);
	m_ListCtrl.InsertColumn(FIFTH__COLUMN, _T("ADDRESS"), LVCFMT_CENTER, COLUMN_WIDTH);
	m_ListCtrl.InsertColumn(SIXTH__COLUMN, _T("ID"), LVCFMT_CENTER, COLUMN_WIDTH);

	CListView::OnInitialUpdate();

	if (GetDocument()->SelectAll() == FALSE)
	{
		return;
	}

	for (int i = 0; i < GetDocument()->GetPersonsArray().GetCount(); i++)
	{
		PERSONS* pPerson = GetDocument()->GetPersonsArray().GetAt(i);
		CString strID;
		strID.Format(_T("%d"), pPerson->lID);

		int nIndex = m_ListCtrl.InsertItem(FIRST__COLUMN, pPerson->szFirstName);
		m_ListCtrl.SetItemText(nIndex, SECOND__COLUMN, pPerson->szMiddleName);
		m_ListCtrl.SetItemText(nIndex, THIRD__COLUMN, pPerson->szLastName);
		m_ListCtrl.SetItemText(nIndex, FOURTH__COLUMN, pPerson->szUCN);
		m_ListCtrl.SetItemText(nIndex, FIFTH__COLUMN, pPerson->szAddress);
		m_ListCtrl.SetItemText(nIndex, SIXTH__COLUMN, strID);
		m_ListCtrl.SetItemData(nIndex, pPerson->lID);
	}
}
#endif
#endif //_DEBUG

void CPersonsView::UpdatePersonInListCtrl(CObject * pHint)
{
	for (int i = 0; i < m_ListCtrl.GetItemCount(); i++)
	{
		PERSONS* pPerson = (PERSONS*)pHint;
		if (m_ListCtrl.GetItemData(i) == pPerson->lID)
		{
			CString strID;
			strID.Format(_T("%d"), pPerson->lID);

			m_ListCtrl.SetItemText(i, FIRST__COLUMN, pPerson->szFirstName);
			m_ListCtrl.SetItemText(i, SECOND__COLUMN, pPerson->szMiddleName);
			m_ListCtrl.SetItemText(i, THIRD__COLUMN, pPerson->szLastName);
			m_ListCtrl.SetItemText(i, FOURTH__COLUMN, pPerson->szUCN);
			m_ListCtrl.SetItemText(i, FIFTH__COLUMN, pPerson->szAddress);
			m_ListCtrl.SetItemText(i, SIXTH__COLUMN, strID);

			break;
		}
	}
};

void CPersonsView::InsertPersonInListCtrl(CObject * pHint)
{
	PERSONS* pPerson = (PERSONS*)pHint;
	CString strID;
	strID.Format(_T("%d"), pPerson->lID);

	int nIndex = m_ListCtrl.InsertItem(FIRST__COLUMN, pPerson->szFirstName);
	m_ListCtrl.SetItemText(nIndex, SECOND__COLUMN, pPerson->szMiddleName);
	m_ListCtrl.SetItemText(nIndex, THIRD__COLUMN, pPerson->szLastName);
	m_ListCtrl.SetItemText(nIndex, FOURTH__COLUMN, pPerson->szUCN);
	m_ListCtrl.SetItemText(nIndex, FIFTH__COLUMN, pPerson->szAddress);
	m_ListCtrl.SetItemText(nIndex, SIXTH__COLUMN, strID);
	m_ListCtrl.SetItemData(nIndex, pPerson->lID);
};

void CPersonsView::DeletePersonInListCtrl(CObject * pHint)
{
	for (int i = 0; i < m_ListCtrl.GetItemCount(); i++)
	{
		PERSONS* pPerson = (PERSONS*)pHint;
		if (m_ListCtrl.GetItemData(i) == pPerson->lID)
		{
			m_ListCtrl.DeleteItem(i);
			break;
		}
	}
};

void CPersonsView::OnUpdate(CView * pSender, LPARAM lHint, CObject * pHint)
{
	switch (lHint)
	{
	case (UpdateCodes::UpdateCodeUpdate) :
	{
		UpdatePersonInListCtrl(pHint);
		break;
	}
	case (UpdateCodes::UpdateCodeInsert) :
	{
		InsertPersonInListCtrl(pHint);
		break;
	}
	case (UpdateCodes::UpdateCodeDelete) :
	{
		DeletePersonInListCtrl(pHint);
		break;
	}
	default:
		break;
	}
	__super::OnUpdate(pSender, lHint, pHint);
};

CPersonsDocument * CPersonsView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CPersonsDocument)));
	return (CPersonsDocument*)m_pDocument;
};

//Методи отварящи диалог или меню
// ----------------
void CPersonsView::OnContextMenu(CWnd* pWnd, CPoint point)
{
	//Sample 01: Declarations
	CRect client_rect;
	CMenu MainMenu;

	//Get Mouse Click position and convert it to the Screen Co-ordinate
	GetClientRect(&client_rect);
	ClientToScreen(&client_rect);

	//Check the mouse pointer position is inside the client area
	if (client_rect.PtInRect(point))
	{
		//Create the Main Menu
		MainMenu.CreatePopupMenu();
		MainMenu.AppendMenu(MF_STRING, INSERT_PERSON_OPTION_ID, _T("Insert"));
		MainMenu.AppendMenu(MF_STRING, UPDATE_PERSON_OPTION_ID, _T("Update"));
		MainMenu.AppendMenu(MF_STRING, DELETE_PERSON_OPTION_ID, _T("Delete"));
		MainMenu.AppendMenu(MF_STRING, VIEW_PERSON_OPTION_ID, _T("View"));

		//Display the Popup Menu
		MainMenu.TrackPopupMenu(TPM_LEFTALIGN, point.x, point.y, this);
	}
	else
	{
		CWnd::OnContextMenu(pWnd, point);
	}

};

void CPersonsView::OnPersonsInsert()
{
	//Взимаме документа
	CPersonsDocument* pPersonsDocument = GetDocument();

	//взимаме актуалните градове
	if (pPersonsDocument->SelectAllCities() == FALSE)
		return;

	//взимаме актуалните телефонни типове
	if (pPersonsDocument->SelectAllPhoneTypes() == FALSE)
		return;

	//Инициализираме диалога със съответните заглавие и полета
	CNumbersPerson oNumbersPerson;
	CPersonsDialog oPersonsDialog(oNumbersPerson, &(pPersonsDocument->m_oCitiesArray), DialogModeInsert, &(pPersonsDocument->m_oPhoneTypesArray));

	if (oPersonsDialog.DoModal() != IDOK)
		return;

	pPersonsDocument->InsertPerson(oNumbersPerson);
};


void CPersonsView::OnPersonsDelete()
{
	//Взимаме документа
	CPersonsDocument* pPersonsDocument = GetDocument();

	//Взимаме select-натия град
	int nIndex = m_ListCtrl.GetSelectionMark();
	long lID = m_ListCtrl.GetItemData(nIndex);

	//взимаме актуалния абонат и номерите му от базата и го запазваме в oNumbersPerson
	CNumbersPerson oNumbersPerson;
	if (pPersonsDocument->SelectByID(lID, oNumbersPerson) == FALSE)
		return;

	//взимаме актуалните градове
	if (GetDocument()->SelectAllCities() == FALSE)
		return;

	//взимаме актуалните телефонни типове
	if (GetDocument()->SelectAllPhoneTypes() == FALSE)
		return;

	//Инициализираме диалога със съответните заглавие и полета
	CPersonsDialog oPersonsDialog(oNumbersPerson, &(pPersonsDocument->m_oCitiesArray), DialogModeDelete, &(pPersonsDocument->m_oPhoneTypesArray));

	if (oPersonsDialog.DoModal() != IDOK)
		return;

	GetDocument()->DeleteByID(lID);
};

void CPersonsView::OnPersonsView()
{
	//Взимаме документа
	CPersonsDocument* pPersonsDocument = GetDocument();

	//Взимаме select-натия person
	int nIndex = m_ListCtrl.GetSelectionMark();
	long lID = m_ListCtrl.GetItemData(nIndex);

	//взимаме актуалния абонат и номерите му от базата и го запазваме в oNumbersPerson
	CNumbersPerson oNumbersPerson;
	if (pPersonsDocument->SelectByID(lID, oNumbersPerson) == FALSE)
		return;

	//взимаме актуалните градове
	if (GetDocument()->SelectAllCities() == FALSE)
		return;

	//взимаме актуалните телефонни типове
	if (GetDocument()->SelectAllPhoneTypes() == FALSE)
		return;

	//Инициализираме диалога със съответните заглавие и полета
	CPersonsDialog oPersonsDialog(oNumbersPerson, &(pPersonsDocument->m_oCitiesArray), DialogModeView, &(pPersonsDocument->m_oPhoneTypesArray));

	oPersonsDialog.DoModal();
};

void CPersonsView::OnPersonsUpdate()
{
	//Взимаме документа
	CPersonsDocument* pPersonsDocument = GetDocument();

	//Взимаме ID на select-натия person
	int nIndex = m_ListCtrl.GetSelectionMark();
	long lID = m_ListCtrl.GetItemData(nIndex);

	//взимаме актуалния абонат и номерите му от базата и го запазваме в oNumbersPerson
	CNumbersPerson oNumbersPerson;
	if (pPersonsDocument->SelectByID(lID, oNumbersPerson) == FALSE)
		return;

	//взимаме актуалните градове
	if (GetDocument()->SelectAllCities() == FALSE)
		return;

	//взимаме актуалните телефонни типове
	if (GetDocument()->SelectAllPhoneTypes() == FALSE)
		return;

	//Инициализираме диалога със съответните заглавие и полета
	CPersonsDialog oPersonsDialog(oNumbersPerson, &(pPersonsDocument->m_oCitiesArray), DialogModeUpdate, &(pPersonsDocument->m_oPhoneTypesArray));

	if (oPersonsDialog.DoModal() != IDOK)
		return;

	GetDocument()->UpdatePerson(oNumbersPerson);
};