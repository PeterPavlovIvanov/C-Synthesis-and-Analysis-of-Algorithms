﻿// PersonsView.cpp : implementation file
//

#include "stdafx.h"

#include "PhoneBook.h"

#include "PersonsView.h"

#include "DialogModes.h"

#include "PersonsDialog.h"

// CPersonsView

IMPLEMENT_DYNCREATE(CPersonsView, CListView)

CPersonsView::CPersonsView()
{

}

CPersonsView::~CPersonsView()
{
}

BEGIN_MESSAGE_MAP(CPersonsView, CListView)
	ON_COMMAND(INSERT_PERSON_OPTION_ID, &CPersonsView::OnPersonsInsert)
	ON_COMMAND(DELETE_PERSON_OPTION_ID, &CPersonsView::OnPersonsDelete)
	ON_COMMAND(VIEW_PERSON_OPTION_ID, &CPersonsView::OnPersonsView)
	ON_COMMAND(UPDATE_PERSON_OPTION_ID, &CPersonsView::OnPersonsUpdate)
	ON_WM_PAINT()
	ON_WM_CONTEXTMENU()
END_MESSAGE_MAP()


// CPersonsView diagnostics

#ifdef _DEBUG
void CPersonsView::AssertValid() const
{
	CListView::AssertValid();
}

#ifndef _WIN32_WCE
void CPersonsView::Dump(CDumpContext& dc) const
{
	CListView::Dump(dc);
};

void CPersonsView::SetTextOnRow(int nIndex, PERSONS* pPerson, CString strID)
{
	m_ListCtrl.SetItemText(nIndex, ZERO_COLUMN, pPerson->szFirstName);
	m_ListCtrl.SetItemText(nIndex, FIRST_COLUMN, pPerson->szMiddleName);
	m_ListCtrl.SetItemText(nIndex, SECOND_COLUMN, pPerson->szLastName);
	m_ListCtrl.SetItemText(nIndex, THIRD_COLUMN, pPerson->szUCN);
	m_ListCtrl.SetItemText(nIndex, FOURTH_COLUMN, pPerson->szAddress);
	m_ListCtrl.SetItemText(nIndex, FIFTH_COLUMN, strID);
	m_ListCtrl.SetItemData(nIndex, pPerson->lID);
};

void CPersonsView::SetColumnsPersonsListCtrl()
{
	m_ListCtrl.SetView(LVS_REPORT);

	m_ListCtrl.SetExtendedStyle(m_ListCtrl.GetExtendedStyle() | LVS_EX_FULLROWSELECT);

	m_ListCtrl.InsertColumn(ZERO_COLUMN, _T("FIRST_NAME"), LVCFMT_CENTER, COLUMN_WIDTH);
	m_ListCtrl.InsertColumn(FIRST_COLUMN, _T("MIDDLE_NAME"), LVCFMT_CENTER, COLUMN_WIDTH);
	m_ListCtrl.InsertColumn(SECOND_COLUMN, _T("LAST_NAME"), LVCFMT_CENTER, COLUMN_WIDTH);
	m_ListCtrl.InsertColumn(THIRD_COLUMN, _T("UCN"), LVCFMT_CENTER, COLUMN_WIDTH);
	m_ListCtrl.InsertColumn(FOURTH_COLUMN, _T("ADDRESS"), LVCFMT_CENTER, COLUMN_WIDTH);
	m_ListCtrl.InsertColumn(FIFTH_COLUMN, _T("ID"), LVCFMT_CENTER, COLUMN_WIDTH);
};

void CPersonsView::OnInitialUpdate()
{
	SetColumnsPersonsListCtrl();

	CListView::OnInitialUpdate();

	for (int i = 0; i < GetDocument()->GetPersonsArray().GetCount(); i++)
	{
		PERSONS* pPerson = GetDocument()->GetPersonsArray().GetAt(i);
		CString strID;
		strID.Format(_T("%d"), pPerson->lID);

		int nIndex = m_ListCtrl.InsertItem(ZERO_COLUMN, pPerson->szFirstName);
		SetTextOnRow(nIndex, pPerson, strID);
	}
}
#endif
#endif //_DEBUG

void CPersonsView::UpdatePersonInListCtrl(CObject * pHint)
{
	for (int i = 0; i < m_ListCtrl.GetItemCount(); i++)
	{
		PERSONS* pPerson = (PERSONS*)pHint;
		if (m_ListCtrl.GetItemData(i) == pPerson->lID)
		{
			CString strID;
			strID.Format(_T("%d"), pPerson->lID);

			SetTextOnRow(i, pPerson, strID);
			break;
		}
	}
};

void CPersonsView::InsertPersonInListCtrl(CObject * pHint)
{
	PERSONS* pPerson = (PERSONS*)pHint;
	CString strID;
	strID.Format(_T("%d"), pPerson->lID);

	int nIndex = m_ListCtrl.InsertItem(ZERO_COLUMN, pPerson->szFirstName);
	SetTextOnRow(nIndex, pPerson, strID);
};

void CPersonsView::DeletePersonInListCtrl(CObject * pHint)
{
	for (int i = 0; i < m_ListCtrl.GetItemCount(); i++)
	{
		PERSONS* pPerson = (PERSONS*)pHint;
		if (m_ListCtrl.GetItemData(i) == pPerson->lID)
		{
			m_ListCtrl.DeleteItem(i);
			break;
		}
	}
};

void CPersonsView::OnUpdate(CView * pSender, LPARAM lHint, CObject * pHint)
{
	switch (lHint)
	{
	case (UpdateCodes::UpdateCodeUpdate) :
	{
		UpdatePersonInListCtrl(pHint);
		break;
	}
	case (UpdateCodes::UpdateCodeInsert) :
	{
		InsertPersonInListCtrl(pHint);
		break;
	}
	case (UpdateCodes::UpdateCodeDelete) :
	{
		DeletePersonInListCtrl(pHint);
		break;
	}
	default:
		break;
	}
	__super::OnUpdate(pSender, lHint, pHint);
};

CPersonsDocument * CPersonsView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CPersonsDocument)));
	return (CPersonsDocument*)m_pDocument;
};

//Методи отварящи диалог или меню
// ----------------
void CPersonsView::OnContextMenu(CWnd* pWnd, CPoint point)
{
	//Sample 01: Declarations
	CRect client_rect;
	CMenu MainMenu;

	//Get Mouse Click position and convert it to the Screen Co-ordinate
	GetClientRect(&client_rect);
	ClientToScreen(&client_rect);

	//Check the mouse pointer position is inside the client area
	if (client_rect.PtInRect(point))
	{
		//Create the Main Menu
		MainMenu.CreatePopupMenu();
		MainMenu.AppendMenu(MF_STRING, INSERT_PERSON_OPTION_ID, _T("Insert"));
		if (m_ListCtrl.GetNextItem(START_INDEX, LVNI_SELECTED) > START_INDEX)
		{
			MainMenu.AppendMenu(MF_STRING, UPDATE_PERSON_OPTION_ID, _T("Update"));
			MainMenu.AppendMenu(MF_STRING, DELETE_PERSON_OPTION_ID, _T("Delete"));
			MainMenu.AppendMenu(MF_STRING, VIEW_PERSON_OPTION_ID, _T("View"));
		}

		//Display the Popup Menu
		MainMenu.TrackPopupMenu(TPM_LEFTALIGN, point.x, point.y, this);
	}
	else
	{
		CWnd::OnContextMenu(pWnd, point);
	}

};

void CPersonsView::OnPersonsInsert()
{
	//Взимаме документа
	CPersonsDocument* pPersonsDocument = GetDocument();

	//Инициализираме диалога със съответните заглавие и полета
	CNumbersPerson oNumbersPerson;
	CPersonsDialog oPersonsDialog(oNumbersPerson, pPersonsDocument->m_oCitiesArray, DialogModeInsert, 
		pPersonsDocument->m_oPhoneTypesArray);

	if (oPersonsDialog.DoModal() != IDOK)
		return;

	pPersonsDocument->InsertPerson(oNumbersPerson);
};


void CPersonsView::OnPersonsDelete()
{
	//Взимаме документа
	CPersonsDocument* pPersonsDocument = GetDocument();

	//Взимаме select-натия град
	int nIndex = m_ListCtrl.GetSelectionMark();
	long lID = m_ListCtrl.GetItemData(nIndex);

	//взимаме актуалния абонат и номерите му от базата и го запазваме в oNumbersPerson
	CNumbersPerson oNumbersPerson;
	if (pPersonsDocument->SelectByID(lID, oNumbersPerson) == FALSE)
		return;

	//Инициализираме диалога със съответните заглавие и полета
	CPersonsDialog oPersonsDialog(oNumbersPerson, pPersonsDocument->m_oCitiesArray, DialogModeDelete,
		pPersonsDocument->m_oPhoneTypesArray);

	if (oPersonsDialog.DoModal() != IDOK)
		return;

	GetDocument()->DeleteByID(lID);
};

void CPersonsView::OnPersonsView()
{
	//Взимаме документа
	CPersonsDocument* pPersonsDocument = GetDocument();

	//Взимаме select-натия person
	int nIndex = m_ListCtrl.GetSelectionMark();
	long lID = m_ListCtrl.GetItemData(nIndex);

	//взимаме актуалния абонат и номерите му от базата и го запазваме в oNumbersPerson
	CNumbersPerson oNumbersPerson;
	if (pPersonsDocument->SelectByID(lID, oNumbersPerson) == FALSE)
		return;

	//Инициализираме диалога със съответните заглавие и полета
	CPersonsDialog oPersonsDialog(oNumbersPerson, pPersonsDocument->m_oCitiesArray, DialogModeView, 
		pPersonsDocument->m_oPhoneTypesArray);

	oPersonsDialog.DoModal();
};

void CPersonsView::OnPersonsUpdate()
{
	//Взимаме документа
	CPersonsDocument* pPersonsDocument = GetDocument();

	//Взимаме ID на select-натия person
	int nIndex = m_ListCtrl.GetSelectionMark();
	long lID = m_ListCtrl.GetItemData(nIndex);

	//взимаме актуалния абонат и номерите му от базата и го запазваме в oNumbersPerson
	CNumbersPerson oNumbersPerson;
	if (pPersonsDocument->SelectByID(lID, oNumbersPerson) == FALSE)
		return;

	//Инициализираме диалога със съответните заглавие и полета
	CPersonsDialog oPersonsDialog(oNumbersPerson, pPersonsDocument->m_oCitiesArray, DialogModeUpdate, 
		pPersonsDocument->m_oPhoneTypesArray);

	if (oPersonsDialog.DoModal() != IDOK)
		return;

	GetDocument()->UpdatePerson(oNumbersPerson);
};