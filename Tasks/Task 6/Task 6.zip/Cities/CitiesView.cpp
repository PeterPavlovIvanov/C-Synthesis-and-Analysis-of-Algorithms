﻿// CitiesView.cpp : implementation file
//

#include "stdafx.h"

#include "PhoneBook.h"

#include "CitiesView.h"

#include "CitiesDocument.h"

#include "Typedefs.h"

#include "CitiesDialog.h"

#include "UpdateCodes.h"

#include "CommCtrl.h"

// CCitiesView

IMPLEMENT_DYNCREATE(CCitiesView, CListView)

CCitiesView::CCitiesView()
{

}

CCitiesView::~CCitiesView()
{
}

BEGIN_MESSAGE_MAP(CCitiesView, CListView)
	ON_COMMAND(INSERT_OPTION_ID, &CCitiesView::OnCitiesInsert)
	ON_COMMAND(VIEW_OPTION_ID, &CCitiesView::OnView)
	ON_COMMAND(DELETE_OPTION_ID, &CCitiesView::OnDelete)
	ON_COMMAND(UPDATE_OPTION_ID, &CCitiesView::OnCityUpdate)
	ON_WM_PAINT()
	ON_WM_CONTEXTMENU()
END_MESSAGE_MAP()


// CCitiesView diagnostics

#ifdef _DEBUG
void CCitiesView::AssertValid() const
{
	CListView::AssertValid();
}

#ifndef _WIN32_WCE
void CCitiesView::Dump(CDumpContext& dc) const
{
	CListView::Dump(dc);
};

void CCitiesView::SetColumnsCitiesListCtrl()
{
	m_ListCtrl.SetView(LVS_REPORT);
	//todo: LVS_SINGLESEL
	m_ListCtrl.SetExtendedStyle(m_ListCtrl.GetExtendedStyle() | LVS_EX_FULLROWSELECT);

	m_ListCtrl.InsertColumn(ZERO_COLUMN, _T("CITY_NAME"), LVCFMT_CENTER, COLUMN_WIDTH);
	m_ListCtrl.InsertColumn(FIRST_COLUMN, _T("REGION"), LVCFMT_CENTER, COLUMN_WIDTH);
	m_ListCtrl.InsertColumn(SECOND_COLUMN, _T("ID"), LVCFMT_CENTER, COLUMN_WIDTH);
};

void CCitiesView::OnInitialUpdate()
{
	SetColumnsCitiesListCtrl();

	CListView::OnInitialUpdate();

	if (GetDocument()->SelectAll() == FALSE)
	{
		return;
	}

	for (int i = 0; i < GetDocument()->GetCitiesArray().GetCount(); i++)
	{
		CITIES* recCity = GetDocument()->GetCitiesArray().GetAt(i);
		CString strID;
		strID.Format(_T("%d"), recCity->lID);

		int nIndex = m_ListCtrl.InsertItem(ZERO_COLUMN, recCity->szCityName);
		m_ListCtrl.SetItemText(nIndex, FIRST_COLUMN, recCity->szRegion);
		m_ListCtrl.SetItemText(nIndex, SECOND_COLUMN, strID);
		m_ListCtrl.SetItemData(nIndex, recCity->lID);
	}
}
#endif
#endif //_DEBUG

void CCitiesView::UpdateCityInListCtrl(CObject * pHint)
{
	for (int i = 0; i < m_ListCtrl.GetItemCount(); i++)
	{
		CITIES* pCity = (CITIES*)pHint;
		if (m_ListCtrl.GetItemData(i) == pCity->lID)
		{
			CString strID;
			strID.Format(_T("%d"), pCity->lID);

			m_ListCtrl.SetItemText(i, ZERO_COLUMN, pCity->szCityName);
			m_ListCtrl.SetItemText(i, FIRST_COLUMN, pCity->szRegion);
			m_ListCtrl.SetItemText(i, SECOND_COLUMN, strID);

			break;
		}
	}
};

void CCitiesView::InsertCityInListCtrl(CObject * pHint)
{
	CITIES* pCity = (CITIES*)pHint;
	CString strID;
	strID.Format(_T("%d"), pCity->lID);

	int nIndex = m_ListCtrl.InsertItem(ZERO_COLUMN, pCity->szCityName);
	m_ListCtrl.SetItemText(nIndex, FIRST_COLUMN, pCity->szRegion);
	m_ListCtrl.SetItemText(nIndex, SECOND_COLUMN, strID);
	m_ListCtrl.SetItemData(nIndex, pCity->lID);
};

void CCitiesView::DeleteCityInListCtrl(CObject * pHint)
{
	for (int i = 0; i < m_ListCtrl.GetItemCount(); i++)
	{
		CITIES* pCity = (CITIES*)pHint;
		if (m_ListCtrl.GetItemData(i) == pCity->lID)
		{
			m_ListCtrl.DeleteItem(i);
			break;
		}
	}
};

void CCitiesView::OnUpdate(CView * pSender, LPARAM lHint, CObject * pHint)
{
	switch (lHint)
	{
	case (UpdateCodes::UpdateCodeUpdate) :
	{
		UpdateCityInListCtrl(pHint);
		break;
	}
	case (UpdateCodes::UpdateCodeInsert):
	{
		InsertCityInListCtrl(pHint);
		break;
	}
	case (UpdateCodes::UpdateCodeDelete):
	{
		DeleteCityInListCtrl(pHint);
		break;
	}
	default:
		break;
	}
	__super::OnUpdate(pSender, lHint, pHint);
};

CCitiesDocument * CCitiesView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CCitiesDocument)));
	return (CCitiesDocument*)m_pDocument;
};

//Методи които само викат документа
// ----------------
BOOL CCitiesView::InsertCity(CITIES& recCities)
{
	return GetDocument()->InsertCity(recCities);
};

BOOL CCitiesView::UpdateCity( CITIES& recCity)
{
	return GetDocument()->UpdateCity(recCity);
};

BOOL CCitiesView::DeleteCity(int nID)
{
	return GetDocument()->DeleteByID(nID);
};

BOOL CCitiesView::SelectCityByID(int nID, CITIES& recCity)
{
	return GetDocument()->SelectByID(nID, recCity);
};

//Методи отварящи диалог или меню
// ----------------
void CCitiesView::OnContextMenu(CWnd* pWnd, CPoint point)
{
	//Sample 01: Declarations
	CRect client_rect;
	CMenu MainMenu;

	//Get Mouse Click position and convert it to the Screen Co-ordinate
	GetClientRect(&client_rect);
	ClientToScreen(&client_rect);

	//Check the mouse pointer position is inside the client area
	if (client_rect.PtInRect(point))
	{
		//Create the Main Menu
		MainMenu.CreatePopupMenu();
		MainMenu.AppendMenu(MF_STRING, INSERT_OPTION_ID, _T("Insert"));
		if (m_ListCtrl.GetNextItem(-1, LVNI_SELECTED) > -1)
		{
			MainMenu.AppendMenu(MF_STRING, UPDATE_OPTION_ID, _T("Update"));
			MainMenu.AppendMenu(MF_STRING, DELETE_OPTION_ID, _T("Delete"));
			MainMenu.AppendMenu(MF_STRING, VIEW_OPTION_ID, _T("View"));
		}
		
		//Display the Popup Menu
		MainMenu.TrackPopupMenu(TPM_LEFTALIGN, point.x, point.y, this);
	}
	else
	{
		CWnd::OnContextMenu(pWnd, point);
	}

};

void CCitiesView::OnCitiesInsert()
{
	CITIES recCity;
	CCitiesDialog oDialog(recCity, DialogModeInsert);

	if (oDialog.DoModal() != IDOK)
		return;

	InsertCity(recCity);
};

void CCitiesView::OnView() 
{
	//Взимаме документа
	CCitiesDocument* pCitiesDocument = GetDocument();

	//Взимаме select-натия град
	int nIndex = m_ListCtrl.GetSelectionMark();
	long lID = m_ListCtrl.GetItemData(nIndex);

	//взимаме актуалния град от базата и го запазваме в recCity
	CITIES recCity;
	if (pCitiesDocument->SelectByID(lID, recCity) == FALSE)
		return;

	//Инициализираме диалога със съответните заглавие и полета
	CCitiesDialog oDialog(recCity, DialogModeView);

	oDialog.DoModal();
};

void CCitiesView::OnDelete()
{
	//Взимаме документа
	CCitiesDocument* pCitiesDocument = GetDocument();

	//Взимаме select-натия град
	int nIndex = m_ListCtrl.GetSelectionMark();
	long lID = m_ListCtrl.GetItemData(nIndex);

	//взимаме актуалния град от базата и го запазваме в recCity
	CITIES recCity;
	if (pCitiesDocument->SelectByID(lID, recCity) == FALSE)
		return;

	//Инициализираме диалога със съответните заглавие и полета
	CCitiesDialog oDialog(recCity, DialogModeDelete);

	if (oDialog.DoModal() != IDOK)
		return;
		
	GetDocument()->DeleteByID(lID);
};

void CCitiesView::OnCityUpdate() 
{
	//Взимаме документа
	CCitiesDocument* pCitiesDocument = GetDocument();

	//Взимаме ID на select-натия град
	int nIndex = m_ListCtrl.GetSelectionMark();
	long lID = m_ListCtrl.GetItemData(nIndex);

	//Взимаме актуалния град по ID и го запазваме в recCity
	CITIES recCity;
	if (pCitiesDocument->SelectByID(lID, recCity) == FALSE)
		return;

	//Инициализираме диалога със съответните заглавие и полета
	CCitiesDialog oDialog(recCity, DialogModeUpdate);
	
	if (oDialog.DoModal() != IDOK)
		return;

	UpdateCity(recCity);
};