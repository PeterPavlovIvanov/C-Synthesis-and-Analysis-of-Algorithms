﻿// PhoneNumbersDialog.cpp : implementation file
//

#include "stdafx.h"
#include "PhoneBook.h"
#include "PhoneNumbersDialog.h"
#include "afxdialogex.h"


// CPhoneNumbersDialog dialog

IMPLEMENT_DYNAMIC(CPhoneNumbersDialog, CDialog)

CPhoneNumbersDialog::CPhoneNumbersDialog(DialogModes eDialogMode, PHONE_NUMBERS& recPhoneNumber
	, CPhoneTypesArray* pPhoneTypesArray, CWnd* pParent /*=NULL*/)
	: CDialog(IDD_PHONE_NUMBERS_DIALOG, pParent),
	m_recPhoneNumber(recPhoneNumber), m_oPhoneTypesArray(*pPhoneTypesArray)
{
	m_eDialogMode = eDialogMode;

	switch (eDialogMode)
	{
	case DialogModeUpdate:
		m_strDlgCaption = _T("Update phone number");
		break;
	case DialogModeDelete:
		m_strDlgCaption = _T("Are you sure you want to delete this phone number?");
		break;
	case DialogModeView:
		m_strDlgCaption = _T("View phone number");
		break;
	case DialogModeInsert:
		m_strDlgCaption = _T("Insert phone number");
		break;
	};
};

CPhoneNumbersDialog::~CPhoneNumbersDialog()
{
}

void CPhoneNumbersDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDB_PHONE_NUMBERS_NUMBER, editNumber);
	DDX_Control(pDX, IDC_CMB_PHONE_NUMBERS_PHONE_TYPE, comboPhoneType);
}; 

BOOL CPhoneNumbersDialog::OnInitDialog()
{
	__super::OnInitDialog();
	SetWindowText(m_strDlgCaption);
	SetDlgItemText(IDC_EDIT1, m_recPhoneNumber.szNumber);

	//ComboBox
	for (int i = 0; i < m_oPhoneTypesArray.GetCount(); i++)
	{
		int nIndex = comboPhoneType.AddString(m_oPhoneTypesArray.GetAt(i)->szPhoneType);
		comboPhoneType.SetItemData(nIndex, m_oPhoneTypesArray.GetAt(i)->lID);
	}

	//Задаваме телефонния тип ако е необходимо
	if (m_eDialogMode != DialogModes::DialogModeInsert)
	{
		CString strPhoneType;
		for (int i = 0; i < m_oPhoneTypesArray.GetCount(); i++)
		{
			if (m_recPhoneNumber.lPhoneTypeID == m_oPhoneTypesArray.GetAt(i)->lID)
			{
				strPhoneType.Format(_T("%s"), m_oPhoneTypesArray.GetAt(i)->szPhoneType);
				int lIndex = comboPhoneType.SelectString(-1, strPhoneType);
				comboPhoneType.SetCurSel(lIndex);
				break;
			}
		}
	}

	if (m_eDialogMode == DialogModes::DialogModeView || m_eDialogMode == DialogModes::DialogModeDelete)
	{
		editNumber.SetReadOnly();
		comboPhoneType.EnableWindow(FALSE);
	}
	
	return TRUE;
};

BEGIN_MESSAGE_MAP(CPhoneNumbersDialog, CDialog)
	ON_BN_CLICKED(IDOK, &CPhoneNumbersDialog::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &CPhoneNumbersDialog::OnBnClickedCancel)
END_MESSAGE_MAP()


// CPhoneNumbersDialog message handlers

void CPhoneNumbersDialog::OnBnClickedOk()
{
	DialogToBuf();
	CDialog::OnOK();
};

void CPhoneNumbersDialog::OnBnClickedCancel()
{
	CDialog::OnCancel();
};

void CPhoneNumbersDialog::DialogToBuf()
{
	CString strWindowText;

	editNumber.GetWindowText(strWindowText);
	wcscpy_s(m_recPhoneNumber.szNumber, strWindowText);

	long lIndex = comboPhoneType.GetCurSel();
	m_recPhoneNumber.lPhoneTypeID = comboPhoneType.GetItemData(lIndex);
};