// PhoneTypeDialog.cpp : implementation file
//

#include "stdafx.h"
#include "PhoneBook.h"
#include "PhoneTypesDialog.h"
#include "afxdialogex.h"


// CPhoneTypesDialog dialog

IMPLEMENT_DYNAMIC(CPhoneTypesDialog, CDialog)

CPhoneTypesDialog::CPhoneTypesDialog(DialogModes eDialogMode, PHONE_TYPES& recPhoneType, CWnd* pParent /*=NULL*/)
	: CDialog(IDD_PHONE_TYPES_DIALOG, pParent), m_recPhoneType(recPhoneType)
{
	m_eDialogMode = eDialogMode;
	switch (eDialogMode)
	{
	case DialogModeUpdate:
		m_strDlgCaption = _T("Update phone type");
		break;
	case DialogModeDelete:
		m_strDlgCaption = _T("Are you sure you want to delete this phone type?");
		break;
	case DialogModeView:
		m_strDlgCaption = _T("View phone type");
		break;
	case DialogModeInsert:
		m_strDlgCaption = _T("Insert phone type");
		break;
	};
	this->m_strDlgCaption = m_strDlgCaption;
}

CPhoneTypesDialog::~CPhoneTypesDialog()
{
};

void CPhoneTypesDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDB_PHONE_TYPES_NAME, editPhoneType);
}

BOOL CPhoneTypesDialog::OnInitDialog()
{
	__super::OnInitDialog();
	SetWindowText(m_strDlgCaption);
	if (m_eDialogMode == DialogModes::DialogModeView || m_eDialogMode == DialogModes::DialogModeDelete)
	{
		editPhoneType.SetReadOnly();
	}
	SetDlgItemText(IDC_EDB_PHONE_TYPES_NAME, m_recPhoneType.szPhoneType);
	return TRUE;
};

BEGIN_MESSAGE_MAP(CPhoneTypesDialog, CDialog)
	ON_BN_CLICKED(IDOK, &CPhoneTypesDialog::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &CPhoneTypesDialog::OnBnClickedCancel)
END_MESSAGE_MAP()


// CPhoneTypesDialog message handlers

void CPhoneTypesDialog::OnBnClickedOk()
{
	if (DialogToBuf() != TRUE)
		return;
	CDialog::OnOK();
};

void CPhoneTypesDialog::OnBnClickedCancel()
{
	CDialog::OnCancel();
};

void CPhoneTypesDialog::CleanFields()
{
	m_recPhoneType.lID = NEW_LONG;
	m_recPhoneType.lUpdateCounter = NEW_LONG;
	wcscpy_s(m_recPhoneType.szPhoneType, _T(""));
};

BOOL CPhoneTypesDialog::DialogToBuf()
{
	CString strWindowText;

	editPhoneType.GetWindowText(strWindowText);

	if (strWindowText.GetLength() < BASE_STRING_LENGHT)
	{
		AfxMessageBox(_T("Phone Type must be atleast %d symbols long."), BASE_STRING_LENGHT);
		return FALSE;
	}

	wcscpy_s(m_recPhoneType.szPhoneType, strWindowText);

	return TRUE;
};