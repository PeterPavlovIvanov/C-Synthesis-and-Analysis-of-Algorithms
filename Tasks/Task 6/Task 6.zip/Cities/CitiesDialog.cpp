// CitiesDialog.cpp : implementation file
//

#include "stdafx.h"

#include "PhoneBook.h"

#include "CitiesDialog.h"

#include "afxdialogex.h"

#include "Typedefs.h"

#include "CitiesView.h"

// CCitiesDialog dialog

IMPLEMENT_DYNAMIC(CCitiesDialog, CDialog)

CCitiesDialog::CCitiesDialog(CITIES& recCity, DialogModes eDialogMode, CWnd* pParent /*=NULL*/) 
	: CDialog(IDD_CITIES_DIALOG, pParent), m_recCity(recCity)
{
	m_eDialogMode = eDialogMode;
	switch (eDialogMode)
	{
	case DialogModeUpdate:
		m_strDlgCaption = _T("Update city");
		break;
	case DialogModeDelete:
		m_strDlgCaption = _T("Are you sure you want to delete this city?");
		break;
	case DialogModeView:
		m_strDlgCaption = _T("View city");
		break;
	case DialogModeInsert:
		m_strDlgCaption = _T("Insert city");
		break;
	};
	this->m_strDlgCaption = m_strDlgCaption;
}

CCitiesDialog::~CCitiesDialog()
{
};

void CCitiesDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDB_CITIES_NAME, editCityName);
	DDX_Control(pDX, IDC_EDB_CITIES_REGION, editRegion);
};

BOOL CCitiesDialog::OnInitDialog()
{
	__super::OnInitDialog();
	SetWindowText(m_strDlgCaption);
	if (m_eDialogMode == DialogModes::DialogModeView || m_eDialogMode == DialogModes::DialogModeDelete)
	{
		editCityName.SetReadOnly();
		editRegion.SetReadOnly();
	}
	SetDlgItemText(IDC_EDB_CITIES_NAME, m_recCity.szCityName);
	SetDlgItemText(IDC_EDB_CITIES_REGION, m_recCity.szRegion);
	return TRUE;
}

BEGIN_MESSAGE_MAP(CCitiesDialog, CDialog)
	ON_BN_CLICKED(IDOK, &CCitiesDialog::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &CCitiesDialog::OnBnClickedCancel)
END_MESSAGE_MAP()



void CCitiesDialog::OnBnClickedOk()
{
	DialogToBuf();
	CDialog::OnOK();
};

void CCitiesDialog::OnBnClickedCancel()
{
	CDialog::OnCancel();
};

void CCitiesDialog::CleanFields()
{
	m_recCity.lID = -1;
	m_recCity.lUpdateCounter = -1;
	wcscpy_s(m_recCity.szCityName, _T(""));
	wcscpy_s(m_recCity.szRegion, _T(""));
};

void CCitiesDialog::DialogToBuf()
{
	CString strWindowText;

	editCityName.GetWindowText(strWindowText);
	wcscpy_s(m_recCity.szCityName, strWindowText);

	editRegion.GetWindowText(strWindowText);
	wcscpy_s(m_recCity.szRegion, strWindowText);
};