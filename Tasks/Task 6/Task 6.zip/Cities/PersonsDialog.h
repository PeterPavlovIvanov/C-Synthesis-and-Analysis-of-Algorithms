﻿#pragma once
#include "afxwin.h"

#include "afxcmn.h"

#include "Typedefs.h"

#include "DialogModes.h"

#include "NumbersPerson.h"


// CPersonsDialog dialog

class CPersonsDialog : public CDialog
{
	DECLARE_DYNAMIC(CPersonsDialog)

	//Constructors
public:
	CPersonsDialog(CNumbersPerson& oNumbersPerson, CCitiesArray& oCitiesArray, DialogModes eDialogMode,
		CPhoneTypesArray& oPhoneTypesArray, CWnd* pParent = NULL);   

	virtual ~CPersonsDialog();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG3 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()

	//Methods
private:
	///<summary>Взима име на телефонен тип по ID</summary>
	///<param "lID">ID на телефонния тип</param>
	///<param "strPhoneType">Хранилище на резултата</param>
	///<param "m_oPhoneTypesArray">Масив с телефонните типове</param>
	void TakePhoneType(long lID, CString& strPhoneType, CPhoneTypesArray* oPhoneTypesArray);

	///<summary>Задава стойности на полетата в диалога</summary>
	void SetEditControlsCredentials();

	///<summary>Задава опции в drop-down менюто за градове в диалога</summary>
	void FillComboBoxCities();

	///<summary>Задава колонки за лист контролата на телефонните номера</summary>
	void SetColumnsPhoneNumbersListCtrl();

	///<summary>Попълва телефонните номера в контролата ако</summary>
	void FillPhoneNumbersInListCtrl();

public:
	void OnPhoneNumbersInsert();
	void OnPhoneNumbersUpdate();
	void OnPhoneNumbersDelete();
	afx_msg void OnRclickList(NMHDR* pNMHDR, LRESULT* pResult);

	///<summary>Пълни полетата</summary>
	void DialogToBuf();

	///<summary>Задава заглавие и полетата на диалога</summary>
	///<returns>Дали операцията е упсешна</returns>
	BOOL OnInitDialog() override;

	//Members
public:
	///<summary>Edit control- поле за показване/въвеждане на първото име</summary>
	CEdit editFirstName;

	///<summary>Edit control- поле за показване/въвеждане на второто име</summary>
	CEdit editMiddleName;

	///<summary>Edit control- поле за показване/въвеждане на фамилията</summary>
	CEdit editLastName;

	///<summary>Edit control- поле за показване/въвеждане на ЕГН-то</summary>
	CEdit editUCN;

	///<summary>Drop-down лист за показване/въвеждане на градовете</summary>
	CComboBox comboCity;

	///<summary>Edit control- поле за показване/въвеждане на адресът</summary>
	CEdit editAddress;

	///<summary>List Control-а за показване/въвеждане на телефонните номери</summary>
	CListCtrl listCtrlPhoneNumbers;

private:
	///<summary>Режим на диалога</summary>
	DialogModes m_eDialogMode;

	///<summary>Номера на абонат и абонат с които се оперира в различните методи</summary>
	CNumbersPerson& m_oNumbersPerson;

	///<summary>Градове с които се оперира в различните методи</summary>
	CCitiesArray& m_oCitiesArray;

	///<summary>Името на диалога</summary>
	CString m_strDlgCaption;

	///<summary>Масив с телефонните типове</summary>
	CPhoneTypesArray& m_oPhoneTypesArray;
public:
	afx_msg void OnBnClickedOk();
};
