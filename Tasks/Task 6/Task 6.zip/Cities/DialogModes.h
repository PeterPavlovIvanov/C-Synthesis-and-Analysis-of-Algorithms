﻿#pragma once
///<summary>Enum за режимите на един диалог</summary>
enum DialogModes
{
	DialogModeInsert = 1,
	DialogModeUpdate = 2,
	DialogModeView = 3,
	DialogModeDelete = 4
};