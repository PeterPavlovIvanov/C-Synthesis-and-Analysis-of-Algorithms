﻿#include "stdafx.h"

#include <atlbase.h>

#include <atldbcli.h>

#include <atldbsch.h>

#include "Typedefs.h"

#include "PhoneNumbersTable.h"

CPhoneNumbersTable::CPhoneNumbersTable(CString strTableName, CSession* oSession) 
	: CBaseTable(strTableName, oSession)
{
};

CPhoneNumbersTable::CPhoneNumbersTable(CString strTableName) : CBaseTable(strTableName)
{
};

BOOL CPhoneNumbersTable::SelectAllByPersonID(long lPersonID, CPhoneNumbersArray& oPhoneNumbersArray)
{
	CString strQuery;
	strQuery.Format(_T("SELECT * FROM %s WHERE PERSON_ID = %d"), m_strTableName, lPersonID);
	
	if (FAILED(ExecuteQuery(strQuery)))
	{
		Close();
		return FALSE;
	}

	while (true)
	{
		BOOL hResult = MoveNext();
		if (hResult == S_OK)
		{
			PHONE_NUMBERS* pPhoneNumber = new PHONE_NUMBERS();
			*pPhoneNumber = GetRowSet();

			oPhoneNumbersArray.Add(pPhoneNumber);
		}
		else if (hResult == DB_S_ENDOFROWSET)
		{
			break;
		}
		else
		{
			Close();
			return FALSE;
		}
	}
	Close();
	return TRUE;
};

PHONE_NUMBERS& CPhoneNumbersTable::GetRowSet()
{
	return m_recPhoneNumber;
};

long* CPhoneNumbersTable::GetUpdateCounter(PHONE_NUMBERS& recPhoneNumber)
{
	return  &(recPhoneNumber.lUpdateCounter);
};

void CPhoneNumbersTable::Trim()
{
	wchar_t cSpace = ' ';
	CString strPhoneNumber = m_recPhoneNumber.szNumber;
	int nIndex = strPhoneNumber.GetLength() - FIX_TO_LAST_INDEX;

	//премахваме space-овете от телефонния номер
	while (m_recPhoneNumber.szNumber[nIndex] == cSpace) {
		m_recPhoneNumber.szNumber[nIndex] = NULL;
		nIndex--;
	}
};