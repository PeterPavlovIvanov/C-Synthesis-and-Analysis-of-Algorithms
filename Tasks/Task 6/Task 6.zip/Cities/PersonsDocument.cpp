﻿// PersonsDocument.cpp : implementation file
//

#include "stdafx.h"

#include "PhoneBook.h"

#include "PersonsDocument.h"

// CPersonsDocument

IMPLEMENT_DYNCREATE(CPersonsDocument, CDocument)

CPersonsDocument::CPersonsDocument()
{
};

BOOL CPersonsDocument::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	//взимаме абонатите
	if (SelectAll() == FALSE)
		return FALSE;

	//взимаме актуалните градове
	if (SelectAllCities() == FALSE)
		return FALSE;

	//взимаме актуалните телефонни типове
	if (SelectAllPhoneTypes() == FALSE)
		return FALSE;

	return TRUE;
};

CPersonsDocument::~CPersonsDocument()
{
};

void CPersonsDocument::OnUpdateAllViews(UpdateCodes eUpdateCode, PERSONS recPerson)
{
	UpdateAllViews(NULL, eUpdateCode, (CObject*)&recPerson);
};

BOOL CPersonsDocument::SelectAllPhoneTypes()
{
	m_oPhoneTypesArray.DeleteAllItems();
	return m_oPhoneTypesData.SelectAll(m_oPhoneTypesArray);
};

BOOL CPersonsDocument::SelectAllCities()
{
	m_oCitiesArray.DeleteAllItems();
	return m_oCitiesData.SelectAll(m_oCitiesArray);
};

BOOL CPersonsDocument::SelectAll()
{
    return m_oPersonsData.SelectAll(m_oPersonsArray);
};

BOOL CPersonsDocument::InsertPerson(CNumbersPerson & oNumbersPerson)
{
	BOOL bResult = m_oPersonsData.Insert(oNumbersPerson);

	if (bResult != TRUE)
	{
		return FALSE;
	}

	PERSONS* pPerson = new PERSONS();
	*pPerson = oNumbersPerson.recPerson;
	m_oPersonsArray.Add(pPerson);

	UpdateCodes eUpdateCode = UpdateCodeInsert;
	OnUpdateAllViews(eUpdateCode, oNumbersPerson.recPerson);
	return bResult;
};

BOOL CPersonsDocument::DeleteByID(int nID)
{
	BOOL bResult = m_oPersonsData.DeleteWhereID(nID);

	if (bResult != TRUE)
	{
		return FALSE;
	}

	for (int i = 0; i < m_oPersonsArray.GetCount(); i++)
	{
		if (m_oPersonsArray.GetAt(i)->lID == nID)
		{
			m_oPersonsArray.DeleteByIndex(i);
		}
	}

	PERSONS recPerson;
	recPerson.lID = nID;

	UpdateCodes eUpdateCode = UpdateCodeDelete;
	OnUpdateAllViews(eUpdateCode, recPerson);
	return bResult;
};

BOOL CPersonsDocument::UpdatePerson(CNumbersPerson& oNumbersPerson)
{
	BOOL bResult = m_oPersonsData.UpdatePerson(oNumbersPerson);

	if (bResult != TRUE)
	{
		return FALSE;
	}

	for (int i = 0; i < m_oPersonsArray.GetCount(); i++)
	{
		if (m_oPersonsArray.GetAt(i)->lID == oNumbersPerson.recPerson.lID)
		{
			*(m_oPersonsArray.GetAt(i)) = oNumbersPerson.recPerson;
			break;
		}
	}

	UpdateCodes eUpdateCode = UpdateCodeUpdate;
	OnUpdateAllViews(eUpdateCode, oNumbersPerson.recPerson);
	return bResult;
};

BOOL CPersonsDocument::SelectByID(int nID, CNumbersPerson& oNumbersPerson)
{
	return m_oPersonsData.SelectWhereID(nID, oNumbersPerson);
};



BEGIN_MESSAGE_MAP(CPersonsDocument, CDocument)
END_MESSAGE_MAP()


// CPersonsDocument diagnostics

#ifdef _DEBUG
void CPersonsDocument::AssertValid() const
{
	CDocument::AssertValid();
}

#ifndef _WIN32_WCE
void CPersonsDocument::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif
#endif //_DEBUG

#ifndef _WIN32_WCE
// CPersonsDocument serialization

void CPersonsDocument::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}
#endif


// CPersonsDocument commands
