﻿#include "stdafx.h"

#include <atlbase.h>

#include <atldbcli.h>

#include <atldbsch.h>

#include <typeinfo>

#include "Typedefs.h"

#include "CitiesTable.h"

#include "PropertiesConnectionDB.h"

#include "DBConnectionCreator.h"

CCitiesTable::CCitiesTable(CString strTableName, CSession* oSession) : CBaseTable(strTableName, oSession)
{
};

CCitiesTable::CCitiesTable(CString strTableName) : CBaseTable(strTableName)
{
};

CITIES & CCitiesTable::GetRowSet()
{
	return m_recCity;
};

long* CCitiesTable::GetUpdateCounter(CITIES& recCity)
{
	return &(m_recCity.lUpdateCounter);
};

void CCitiesTable::Trim()
{
	wchar_t cSpace =  ' ';
	CString strCityName = m_recCity.szCityName, strRegion = m_recCity.szRegion;
	int nIndex = strCityName.GetLength() - FIX_TO_LAST_INDEX;

	//премахваме space-овете от името на града
	while (m_recCity.szCityName[nIndex] == cSpace) {
		m_recCity.szCityName[nIndex] = NULL;
		nIndex--;
	}

	nIndex = strRegion.GetLength() - FIX_TO_LAST_INDEX;

	//премахваме space-овете от региона на града
	while (m_recCity.szRegion[nIndex] == cSpace) {
		m_recCity.szRegion[nIndex] = NULL;
		nIndex--;
	}
};
