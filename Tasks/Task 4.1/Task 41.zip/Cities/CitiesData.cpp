#include "stdafx.h"

#include "CitiesData.h"

CCitiesData::CCitiesData()
{
};

BOOL CCitiesData::SelectAll(CCitiesArray& oCitiesArray)
{
	return m_oCitiesTable.SelectAll(oCitiesArray);
};

BOOL CCitiesData::Insert(const CITIES& recCities) {
	return m_oCitiesTable.Insert(recCities);
};

BOOL CCitiesData::DeleteWhereID(int nID)
{
	return m_oCitiesTable.DeleteWhereID(nID);
};

BOOL CCitiesData::Update(const CITIES & recCity)
{
	return m_oCitiesTable.UpdateWhereID(recCity.lID, recCity);
};

BOOL CCitiesData::SelectWhereID(int nID, CITIES& recCity)
{
	return m_oCitiesTable.SelectWhereID(nID, recCity);
};