// CitiesDialog.cpp : implementation file
//

#include "stdafx.h"

#include "PhoneBook.h"

#include "CitiesDialog.h"

#include "afxdialogex.h"

#include "Typedefs.h"

#include "CitiesView.h"

// CCitiesDialog dialog

IMPLEMENT_DYNAMIC(CCitiesDialog, CDialog)

CCitiesDialog::CCitiesDialog(CWnd* pParent /*=NULL*/)
	: CDialog(IDD_DIALOG1, pParent)
{

}

CCitiesDialog::~CCitiesDialog()
{
}

void CCitiesDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDB_CITIES_NAME, editCityName);
	DDX_Control(pDX, IDC_EDB_CITIES_REGION, editRegion);
}

BOOL CCitiesDialog::OnInitDialog()
{
	__super::OnInitDialog();
	SetWindowText(m_strDlgCaption);
	SetDlgItemText(IDC_EDB_CITIES_NAME, strName);
	SetDlgItemText(IDC_EDB_CITIES_REGION, strRegion);
	return TRUE;
}

BEGIN_MESSAGE_MAP(CCitiesDialog, CDialog)
	ON_BN_CLICKED(IDOK, &CCitiesDialog::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &CCitiesDialog::OnBnClickedCancel)
END_MESSAGE_MAP()

void CCitiesDialog::OnBnClickedOk()
{
	AddToFields();
	CDialog::OnOK();
};

void CCitiesDialog::OnBnClickedCancel()
{
	CleanFields();
	CDialog::OnCancel();
};

void CCitiesDialog::CleanFields()
{
	strName = _T("");
	strRegion = _T("");
	recCity.lID = -1;
	recCity.lUpdateCounter = -1;
	wcscpy_s(recCity.szCityName, _T(""));
	wcscpy_s(recCity.szRegion, _T(""));
};

void CCitiesDialog::AddToFields()
{
	CString strWindowText;

	editCityName.GetWindowText(strWindowText);
	wcscpy_s(recCity.szCityName, strWindowText);

	editRegion.GetWindowText(strWindowText);
	wcscpy_s(recCity.szRegion, strWindowText);
}

void CCitiesDialog::SetRecCity(CITIES recCity)
{
	this->recCity = recCity;
	this->strName = recCity.szCityName;
	this->strRegion = recCity.szRegion;
}