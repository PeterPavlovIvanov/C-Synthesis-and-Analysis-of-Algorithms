#pragma once
enum UpdateCodes 
{
	INSERT_CITY = 1,
	UPDATE_CITY = 2,
	DELETE_CITY = 3 
};