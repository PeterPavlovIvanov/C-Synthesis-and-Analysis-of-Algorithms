﻿#pragma once

#include "CitiesDocument.h"

/////////////////////////////////////////////////////////////////////////////
// CCitiesView

///<summary>Клас View за Cities лист control-ата</summary>
class CCitiesView : public CListView
{
	DECLARE_DYNCREATE(CCitiesView)

	// Constructor / Destructor
	// ----------------
public:
	///<summary>Default-ен конструктор</summary>
	CCitiesView();     

	///<summary>Деструктор<summary>
	virtual ~CCitiesView();

public:
#ifdef _DEBUG
	virtual void AssertValid() const;
#ifndef _WIN32_WCE
	virtual void Dump(CDumpContext& dc) const;
#endif
#endif
	void OnInitialUpdate();

	// Macros
	// ----------------
protected:
	DECLARE_MESSAGE_MAP()

	//Methods
	// ----------------
private:
	///<summary>Взима град по индек</summary>
	///<param = "recCity">градът</param>
	///<param = "nIndex">Индексът</param>
	void GetCityByIndex(CITIES& recCity, int nIndex, CCitiesDocument* oDocument);

public:
	///<summary>Отваря диалога за Insert на град</summary>
	afx_msg void OnCitiesInsert();

	///<summary>Добавя град</summary>
	///<param = "recCities">Град за добавяне</param>
	///<returns>Дали е упсешно изпълнена операцията</returns>
	BOOL InsertCity(const CITIES& recCities);

	///<summary>Променя град</summary>
	///<param = "recCity">Променения град</param>
	///<returns>Дали е упсешно изпълнена операцията</returns>
	BOOL UpdateCity(const CITIES& recCity);

	///<summary>Изтрива град</summary>
	///<param = "nID">ID на града за изтриване</param>
	///<returns>Дали е упсешно изпълнена операцията</returns>
	BOOL DeleteCity(int nID);

	///<summary>Извиква метода на документа който записва в хранилището си град</summary>
	///<param = "nID">ID на града</param>
	///<returns>Дали е упсешно изпълнена операцията</returns>
	BOOL SelectCityByID(int nID);
	
	///<summary>Взима документа</summary>
	///<returns>Pointer към документа</returns>
	CCitiesDocument* GetDocument() const;

	///<summary>Отваря контекстното меню при десен клавиш</summary>
	///<param = "pWnd"></param>
	///<param = "point"></param>
	void OnContextMenu(CWnd* pWnd, CPoint point);
	
	///<summary>Отваря диалог за преглед на данни</summary>
	void OnView();

	///<summary>Отваря диалог за потвърждаване за изтриване на град</summary>
	void OnDelete();

	///<summary>Отваря диалог за Update на град и при изпълнения на диалога извършва съответното действие</summary>
	void OnCityUpdate();

	///<summary></summary>
	void OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) override;

	//Members
	// ----------------
private:
	///<summary>Инстанция на List Control-ата</summary>
	CListCtrl& m_ListCtrl = GetListCtrl();
};


