﻿#pragma once

#include "afxwin.h"

#include "CitiesView.h"

/////////////////////////////////////////////////////////////////////////////
// CCitiesDialog

///<summary>Клас Диалог за Upate/Insert/View/Delete</summary>
class CCitiesDialog : public CDialog
{
	DECLARE_DYNAMIC(CCitiesDialog)

	// Constructor / Destructor
	// ----------------
public:
	///<summary>Standard-ен конструктор</summary>
	CCitiesDialog(CString m_strDlgCaption, CITIES recCity, CWnd* pParent = NULL);   // standard constructor

	///<summary>Виртуален Деструктор<summary>
	virtual ~CCitiesDialog();

// Dialog Data
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG1 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()

	//Methods
	// ----------------
public:
	///<summary>При OK взима стойностите от диалога и Set-ва името и региона в recCity.</summary>
	afx_msg void OnBnClickedOk();

	///<summary>При Cancel чисти полетата.</summary>
	afx_msg void OnBnClickedCancel();

	///<summary>Чисти полетата</summary>
	void CleanFields();

	///<summary>Пълни полетата</summary>
	void AddToFields();

	///<summary>Задава заглавие и полетата на диалога</summary>
	///<returns>Дали операцията е упсешна</returns>
	BOOL OnInitDialog() override;

	///<summary>Сетва текущия град</summary>
	void SetRecCity(CITIES recCity);

	//Members
	// ----------------
public:
	///<summary>Град с който се оперира в различните методи</summary>
	CITIES recCity;

	///<summary>CEdit - input-а за името на града</summary>
	CEdit editCityName;
	
	///<summary>CEdit - input-а за региона на града</summary>
	CEdit editRegion;

	///<summary>Името на диалога</summary>
	CString m_strDlgCaption;

};