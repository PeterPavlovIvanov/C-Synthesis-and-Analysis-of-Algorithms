﻿// CitiesView.cpp : implementation file
//

#include "stdafx.h"

#include "PhoneBook.h"

#include "CitiesView.h"

#include "CitiesDocument.h"

#include "Typedefs.h"

#include "CitiesDialog.h"

// CCitiesView

#define FIRST__COLUMN 0
#define SECOND__COLUMN 1
#define THIRD__COLUMN 2

IMPLEMENT_DYNCREATE(CCitiesView, CListView)

CCitiesView::CCitiesView()
{

}

CCitiesView::~CCitiesView()
{
}

BEGIN_MESSAGE_MAP(CCitiesView, CListView)
	ON_COMMAND(ID_CITIES_INSERT, &CCitiesView::OnCitiesInsert)
	ON_COMMAND(INSERT_OPTION_ID, &CCitiesView::OnCitiesInsert)
	ON_COMMAND(VIEW_OPTION_ID, &CCitiesView::OnView)
	ON_COMMAND(DELETE_OPTION_ID, &CCitiesView::OnDelete)
	ON_COMMAND(UPDATE_OPTION_ID, &CCitiesView::OnCityUpdate)
	ON_WM_PAINT()
	ON_WM_CONTEXTMENU()
END_MESSAGE_MAP()


// CCitiesView diagnostics

#ifdef _DEBUG
void CCitiesView::AssertValid() const
{
	CListView::AssertValid();
}

#ifndef _WIN32_WCE
void CCitiesView::Dump(CDumpContext& dc) const
{
	CListView::Dump(dc);
}
void CCitiesView::OnInitialUpdate()
{
	m_ListCtrl.SetView(LVS_REPORT);

	m_ListCtrl.SetExtendedStyle(m_ListCtrl.GetExtendedStyle() | LVS_EX_FULLROWSELECT);

	m_ListCtrl.InsertColumn(FIRST__COLUMN, _T("CITY_NAME"), LVCFMT_CENTER, COLUMN_WIDTH);
	m_ListCtrl.InsertColumn(SECOND__COLUMN, _T("REGION"), LVCFMT_CENTER, COLUMN_WIDTH);
	m_ListCtrl.InsertColumn(THIRD__COLUMN, _T("ID"), LVCFMT_CENTER, COLUMN_WIDTH);

	CListView::OnInitialUpdate();
}
#endif
#endif //_DEBUG

void CCitiesView::OnUpdate(CView * pSender, LPARAM lHint, CObject * pHint)
{
	m_ListCtrl.DeleteAllItems();

	GetDocument()->GetCitiesArray().DeleteAllItems();

	GetDocument()->SelectAll();

	for (int i = 0; i < GetDocument()->GetCitiesArray().GetCount(); i++)
	{
		CITIES* oCity = GetDocument()->GetCitiesArray().GetAt(i);
		CString strID;
		strID.Format(_T("%d"), oCity->lID);

		int nIndex = m_ListCtrl.InsertItem(FIRST__COLUMN, oCity->szCityName);
		m_ListCtrl.SetItemText(nIndex, SECOND__COLUMN, oCity->szRegion);
		m_ListCtrl.SetItemText(nIndex, THIRD__COLUMN, strID);
	}

	__super::OnUpdate(pSender, lHint, pHint);
};

CCitiesDocument * CCitiesView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CCitiesDocument)));
	return (CCitiesDocument*)m_pDocument;
};

//Методи които само викат документа
// ----------------
BOOL CCitiesView::InsertCity(const CITIES & recCities)
{
	return GetDocument()->InsertCity(recCities);
};

BOOL CCitiesView::UpdateCity(const CITIES & recCity)
{
	return GetDocument()->UpdateCity(recCity);
};

BOOL CCitiesView::DeleteCity(int nID)
{
	return GetDocument()->DeleteByID(nID);
};

BOOL CCitiesView::SelectCityByID(int nID)
{
	return GetDocument()->SelectByID(nID);
};

//Методи отварящи диалог или меню
// ----------------
void CCitiesView::OnContextMenu(CWnd* pWnd, CPoint point)
{
	//Sample 01: Declarations
	CRect client_rect;
	CMenu MainMenu;

	//Get Mouse Click position and convert it to the Screen Co-ordinate
	GetClientRect(&client_rect);
	ClientToScreen(&client_rect);

	//Check the mouse pointer position is inside the client area
	if (client_rect.PtInRect(point))
	{
		//Create the Main Menu
		MainMenu.CreatePopupMenu();
		MainMenu.AppendMenu(MF_STRING, INSERT_OPTION_ID, _T("Insert"));
		MainMenu.AppendMenu(MF_STRING, UPDATE_OPTION_ID, _T("Update"));
		MainMenu.AppendMenu(MF_STRING, DELETE_OPTION_ID, _T("Delete"));
		MainMenu.AppendMenu(MF_STRING, VIEW_OPTION_ID, _T("View"));

		//Display the Popup Menu
		MainMenu.TrackPopupMenu(TPM_LEFTALIGN, point.x, point.y, this);
	}
	else
	{
		CWnd::OnContextMenu(pWnd, point);
	}

};

void CCitiesView::OnCitiesInsert()
{
	CCitiesDialog oDialog;
	oDialog.m_strDlgCaption.Format(_T("Insert city"));
	INT_PTR nResult = oDialog.DoModal();
	if (nResult == 1)
	{
		InsertCity(oDialog.recCity);
	}
};

void CCitiesView::OnView() 
{
	CCitiesDialog oDialog;
	oDialog.m_strDlgCaption.Format(_T("View city"));

	CITIES* recCity = new CITIES();
	POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();

	if (pos == NULL)
	{
		TRACE(_T("No items were selected!\n"));
	}
	else
	{
		while (pos)
		{
			int nItem = m_ListCtrl.GetNextSelectedItem(pos);
			recCity = GetDocument()->GetCitiesArray().GetAt(GetDocument()->GetCitiesArray().GetCount() - nItem - 1);
			break;
		}
	}

	oDialog.SetRecCity(*recCity);
	oDialog.DoModal();
};

void CCitiesView::OnDelete()
{
	CCitiesDialog oDialog;
	oDialog.m_strDlgCaption.Format(_T("Are you sure you want to delete this city?"));

	CITIES* recCity = new CITIES();
	POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();

	if (pos == NULL)
	{
		TRACE(_T("No items were selected!\n"));
	}
	else
	{
		while (pos)
		{
			int nItem = m_ListCtrl.GetNextSelectedItem(pos);
			recCity = GetDocument()->GetCitiesArray().GetAt(GetDocument()->GetCitiesArray().GetCount() - nItem - 1);
			break;
		}
	}

	oDialog.SetRecCity(*recCity);
	if(oDialog.DoModal() == IDOK)
	{
		GetDocument()->DeleteByID(recCity->lID);
	}
};

void CCitiesView::OnCityUpdate() 
{
	CCitiesDocument* oCitiesDocument = GetDocument();

	CCitiesDialog oDialog;
	oDialog.m_strDlgCaption.Format(_T("Update city"));

	CITIES* recCity = new CITIES();
	POSITION pos = m_ListCtrl.GetFirstSelectedItemPosition();

	if (pos == NULL)
	{
		TRACE(_T("No items were selected!\n"));
	}
	else
	{
		while (pos)
		{
			//взимаме index-а на града във View-то
			int nItem = m_ListCtrl.GetNextSelectedItem(pos);

			//взимаме града от View-то чрез index-а 
			recCity = oCitiesDocument->GetCitiesArray().GetAt(oCitiesDocument->GetCitiesArray().GetCount() - nItem - 1);
			
			//взимаме актуалния град от базата и го запазваме в документа
			oCitiesDocument->SelectByID(recCity->lID);

			//задаваме стойностите на актуалния град в recCity
			recCity->lID = oCitiesDocument->m_recCity.lID;
			recCity->lUpdateCounter = oCitiesDocument->m_recCity.lUpdateCounter;
			wcscpy_s(recCity->szCityName, oCitiesDocument->m_recCity.szCityName);
			wcscpy_s(recCity->szRegion, oCitiesDocument->m_recCity.szRegion);
			break;
		}
	}

	//задаваме стойностите на полетата в Update диалога
	oDialog.SetRecCity(*recCity);
	
	if (oDialog.DoModal() == IDOK)
	{
		oDialog.recCity.lUpdateCounter = recCity->lUpdateCounter;
		oDialog.recCity.lID = recCity->lID;
		UpdateCity(oDialog.recCity);
	}
};
