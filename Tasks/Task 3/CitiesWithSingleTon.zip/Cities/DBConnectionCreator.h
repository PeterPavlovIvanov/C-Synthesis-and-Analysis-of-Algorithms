﻿#pragma once

#include "PropertiesConnectionDB.h"

#include "CitiesTable.h"

///<summary>Клас (с възможност за една инстанция) за отваряне и затваряне на връзката с DB</summary>
class CDBConnectionCreator
{
public:
	///<summary>Метод връщат инстанцията на класа</summary>
	static CDBConnectionCreator& GetInstance() {
		return m_instance;
	}

	///<summary>Оператор за присвояване - не присвоява</summary>
	void operator=(CDBConnectionCreator const&) = delete;

	///<summary>Отваряне на връзката с DB</summary>
	HRESULT CreateConnection() {
		CDBPropSet oDBPropSet(DBPROPSET_DBINIT);
		CPropertiesConnectionDB oPropConDB;
		oPropConDB.SetPropertiesDB(oDBPropSet);

		// Свързваме се към базата данни
		if (FAILED(m_oDataSource.Open(_T("SQLOLEDB.1"), &oDBPropSet)))
		{
			return FALSE;
		}

		// Отваряме сесия
		if (FAILED(m_oSession.Open(m_oDataSource)))
		{
			return FALSE;
		}
		return TRUE;
	}

	///<summary>Затваряне на връзката с DB</summary>
	void CloseConnection() {
		//oCitiesTable.Close();
		m_oSession.Close();
		m_oDataSource.Close();
	}

	///<summary>Getter на сесията</summary>
	static CSession& GetSession() {
		return GetInstance().m_oSession;
	}

private:
	///<summary>Конструктор</summary>
	CDBConnectionCreator(void){}

	///<summary>инстанцията</summary>
	static CDBConnectionCreator m_instance;

	CSession m_oSession;
	CDataSource m_oDataSource;
};

CDBConnectionCreator CDBConnectionCreator::m_instance;