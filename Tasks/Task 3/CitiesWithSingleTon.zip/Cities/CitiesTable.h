﻿#pragma once

#include <atldbcli.h>

#include "Typedefs.h"

#include "DBConnectionCreator.h"

class CCitiesAccessor
{
protected:
	CITIES m_recCity;

	BEGIN_ACCESSOR_MAP(CCitiesAccessor, ACCESSOR_COUNT)
		BEGIN_ACCESSOR(FIRST_ACCESSOR, true)
			COLUMN_ENTRY(FIRST_COLUMN, m_recCity.lID)
		END_ACCESSOR()

		BEGIN_ACCESSOR(FIRST_COLUMN, true)
			COLUMN_ENTRY(SECOND_COLUMN, m_recCity.lUpdateCounter)
			COLUMN_ENTRY(THIRD_COLUMN, m_recCity.szCityName)
			COLUMN_ENTRY(FOURTH_COLUMN, m_recCity.szRegion)
		END_ACCESSOR()
	END_ACCESSOR_MAP()
};

///<summary>Клас за работа с таблица CITIES</summary>
class CCitiesTable : private CCommand<CAccessor<CCitiesAccessor>>
{
	///Constructors...
public:
	///<summary>Конструктор създаващ настройките за връзката с DB</summary>
	CCitiesTable();

	///Methods...
public:
	/// <summary>Взима всички градове от таблицата CITIES</summary>
	/// <param name="oCitiesArray">Контейнер за резултата</param>
	/// <returns>Булева стойност отговаряща дали методът е приключил успешно</returns>
	BOOL SelectAll(CCitiesArray& oCitiesArray);

	/// <summary>Взима град по посочено ID</summary>
	/// <param name="lID">ID на търсения град</param>
	/// <param name="recCities">Град за пазене на резултата</param>
	/// <returns>Булева стойност отговаряща дали методът е приключил успешно</returns>
	BOOL SelectWhereID(const long lID, CITIES& recCities);

	/// <summary>Update-ва град по посочено ID</summary>
	/// <param name="lID">ID на дадения град</param>
	/// <param name="recCities">Град съдържащ новите данни</param>
	/// <returns>Булева стойност отговаряща дали методът е приключил успешно</returns>
	BOOL UpdateWhereID(const long lID, const CITIES& recCities);

	/// <summary>Вмъква град в таблицата CITIES</summary>
	/// <param name="recCities">Град съдържащ новите данни</param>
	/// <returns>Булева стойност отговаряща дали методът е приключил успешно</returns>
	BOOL Insert(const CITIES& recCities);

	/// <summary>Изтрива град по посочено ID</summary>
	/// <param name="lID">ID на дадения град</param>
	/// <returns>Булева стойност отговаряща дали методът е приключил успешно</returns>
	BOOL DeleteWhereID(const long lID);

	/// <summary>Прави връзката с DB</summary>
	/// <param name="strQuery">Заявката за изпълнение</param>
	/// <returns>Булева стойност отговаряща дали методът е приключил успешно</returns>
	BOOL ExecuteQuery(CString strQuery);

	/// <summary>Прекратява връзката с DB</summary>
	/// <param name="oDataSource">Текущ DataSource</param>
	/// <param name="oSession">Текуща сесия</param>
	//void CloseCommandSessionConnection(CDataSource& oDataSource, CSession& oSession);

	/// <summary>Update-ва град по посочено ID без да затваря сесията</summary>
	/// <param name="lID">ID на дадения град</param>
	/// <param name="recCities">Град за пазене на резултата</param>
	/// <returns>Булева стойност отговаряща дали методът е приключил успешно</returns>
	BOOL SelectByID(const long lID, CITIES& recCities);

	/// <summary>Пренаписва Close() методът така че да е public</summary>
	void Close();

	/// <summary>Създава връзката с DB</summary>
	/// <returns>Булева стойност отговаряща дали методът е приключил успешно</returns>
	//BOOL CreateCommandSessionConnection();

	//Members...
private:
	/// <summary>Текуща сесия</summary>
	//CSession m_oSession;
	/// <summary>Текущ DataSource</summary>
	//CDataSource m_oDataSource;
};