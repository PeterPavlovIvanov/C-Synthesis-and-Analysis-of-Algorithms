﻿#pragma once

///<summary>CTypedPtrArray template със опция за зачистване на данните</summary>
template<typename T>
class CAutoReleaseMemoryTypedPtrArray : public CTypedPtrArray<CPtrArray, T*>
{
	//Constructors
public:
	///<summary>Default конструктор</summary>
	CAutoReleaseMemoryTypedPtrArray() {

	}

	///<summary>Деструктор изтриващ елементите в масива</summary>
	~CAutoReleaseMemoryTypedPtrArray() {
		for (int i = 0; i < GetCount(); i++) {
			delete GetAt(i);
		}
		RemoveAll();
	}
};