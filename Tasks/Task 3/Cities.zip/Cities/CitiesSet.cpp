
// CitiesSet.cpp : implementation of the CCitiesSet class
//

#include "stdafx.h"
#include "Cities.h"
#include "CitiesSet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CCitiesSet implementation

