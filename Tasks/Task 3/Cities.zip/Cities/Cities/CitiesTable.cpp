﻿#include "stdafx.h"

#include <atlbase.h>

#include <atldbcli.h>

#include <atldbsch.h>

#include "Typedefs.h"

#include "CitiesTable.h"

#include "PropertiesConnectionDB.h"

#define QUOTE "/'"
#define BEGIN_TRAN "BEGIN TRANSACTION"
#define COMMIT_TRAN "COMMIT TRANSACTION"
#define ROLLBACK_TRAN "ROLLBACK TRANSACTION"
#define ACCESSOR_NUMBER 1
#define UPDATE_COUNTER_NUMBER 1

CCitiesTable::CCitiesTable()
{
}

BOOL CCitiesTable::ExecuteQuery()
{
	CDBPropSet pPropSet(DBPROPSET_ROWSET);
	CPropertiesConnectionDB oPropConDB;
	oPropConDB.SetPropertiesRows(pPropSet);

	m_hResult = Open(m_oSession, m_strQuery, &pPropSet);

	if (FAILED(m_hResult))
	{
		return FALSE;
	}
	return TRUE;
}

BOOL CCitiesTable::CreateCommandSessionConnection()
{
	CDBPropSet oDBPropSet(DBPROPSET_DBINIT);
	CPropertiesConnectionDB oPropConDB;
	oPropConDB.SetPropertiesDB(oDBPropSet);

	// Свързваме се към базата данни
	m_hResult = m_oDataSource.Open(_T("SQLOLEDB.1"), &oDBPropSet);

	if (FAILED(m_hResult))
	{
		return FALSE;
	}

	// Отваряме сесия
	m_hResult = m_oSession.Open(m_oDataSource);

	if (FAILED(m_hResult))
	{
		return FALSE;
	}
	return TRUE;
}

void CCitiesTable::CloseCommandSessionConnection(CDataSource& oDataSource, CSession& oSession)
{
	Close();
	oSession.Close();
	oDataSource.Close();
}

BOOL CCitiesTable::SelectByID(const long lID, CITIES& recCities)
{
	m_strQuery.Format(_T("SELECT * FROM CITIES WHERE ID = %d"), lID);

	ExecuteQuery();

	if (MoveNext() == S_OK)
	{
		recCities = m_recCity;
	}
	else
	{
		return FALSE;
	}
	return TRUE;
}

BOOL CCitiesTable::SelectAll(CCitiesArray& oCitiesArray)
{
	if (FAILED(CreateCommandSessionConnection()))
	{
		return FALSE;
	}

	m_strQuery = _T("SELECT * FROM CITIES");

	if (FAILED(ExecuteQuery()))
	{
		CloseCommandSessionConnection(m_oDataSource, m_oSession);

		return FALSE;
	}

	while (true)
	{
		m_hResult = MoveNext();
		if (m_hResult == S_OK)
		{
			CITIES* pCity = new CITIES();
			*pCity = m_recCity;

			oCitiesArray.Add(pCity);
		}
		else if (m_hResult == DB_S_ENDOFROWSET)
		{
			break;
		}
		else
		{
			CloseCommandSessionConnection(m_oDataSource, m_oSession);
			return FALSE;
		}
	}

	CloseCommandSessionConnection(m_oDataSource, m_oSession);

	return TRUE;
};

BOOL CCitiesTable::SelectWhereID(const long lID, CITIES& recCities)
{
	if (FAILED(CreateCommandSessionConnection()))
	{
		return FALSE;
	}

	if (FAILED(SelectByID(lID, recCities))) 
	{
		CloseCommandSessionConnection(m_oDataSource, m_oSession);

		return FALSE;
	}

	CloseCommandSessionConnection(m_oDataSource, m_oSession);

	return TRUE;
};

BOOL CCitiesTable::UpdateWhereID(const long lID, const CITIES& recCities)
{
	if (FAILED(CreateCommandSessionConnection()))
	{
		return FALSE;
	}

	CITIES recCity;
	m_oSession.StartTransaction();

	if (FAILED(SelectByID(lID, recCity))) 
	{
		m_oSession.Abort();
		CloseCommandSessionConnection(m_oDataSource, m_oSession);

		return FALSE;
	}

	m_recCity = recCities;
	m_recCity.lUpdateCounter += UPDATE_COUNTER_NUMBER;

	if (m_recCity.lUpdateCounter - 1 != recCities.lUpdateCounter)
	{
		m_oSession.Abort();
		CloseCommandSessionConnection(m_oDataSource, m_oSession);

		return FALSE;
	}

	if (FAILED(SetData(ACCESSOR_NUMBER)))
	{
		m_oSession.Abort();
		CloseCommandSessionConnection(m_oDataSource, m_oSession);

		return FALSE;
	}

	UpdateAll();
	m_oSession.Commit();
	CloseCommandSessionConnection(m_oDataSource, m_oSession);

	return TRUE;
};

BOOL CCitiesTable::Insert(const CITIES& recCities)
{
	if (FAILED(CreateCommandSessionConnection()))
	{
		return FALSE;
	}

	m_strQuery.Format(_T("SELECT TOP 0 * FROM CITIES"));
	m_oSession.StartTransaction();

	if (FAILED(ExecuteQuery()))
	{
		m_oSession.Abort();
		CloseCommandSessionConnection(m_oDataSource, m_oSession);

		return FALSE;
	}

	m_hResult = MoveNext();

	if (FAILED(m_hResult))
	{
		m_oSession.Abort();
		CloseCommandSessionConnection(m_oDataSource, m_oSession);

		return FALSE;
	}
	
	m_recCity = recCities;
	m_hResult = __super::Insert(ACCESSOR_NUMBER);

	if (FAILED(m_hResult)) 
	{
		return FALSE;
	}

	UpdateAll();
	m_oSession.Commit();
	CloseCommandSessionConnection(m_oDataSource, m_oSession);

	return TRUE;
};

BOOL CCitiesTable::DeleteWhereID(const long lID)
{
	if (FAILED(CreateCommandSessionConnection()))
	{
		return FALSE;
	}

	CITIES oCity;
	m_oSession.StartTransaction();

	if (FAILED(SelectByID(lID, oCity)))
	{
		m_oSession.Abort();
		CloseCommandSessionConnection(m_oDataSource, m_oSession);

		return FALSE;
	}

	m_hResult = Delete();

	if (FAILED(m_hResult))
	{
		return FALSE;
	}

	UpdateAll();
	m_oSession.Commit();
	CloseCommandSessionConnection(m_oDataSource, m_oSession);

	return TRUE;
};