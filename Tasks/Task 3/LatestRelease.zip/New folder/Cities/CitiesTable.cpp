﻿#include "stdafx.h"

#include <atlbase.h>

#include <atldbcli.h>

#include <atldbsch.h>

#include "Typedefs.h"

#include "CitiesTable.h"

#include "PropertiesConnectionDB.h"

CCitiesTable::CCitiesTable()
{
}

BOOL CCitiesTable::ExecuteQuery(CString strQuery)
{
	HRESULT hResult;
	CDBPropSet pPropSet(DBPROPSET_ROWSET);
	CPropertiesConnectionDB oPropConDB;
	oPropConDB.SetPropertiesRows(pPropSet);

	hResult = Open(m_oSession, strQuery, &pPropSet);

	if (FAILED(hResult))
	{
		return FALSE;
	}
	return TRUE;
}

BOOL CCitiesTable::CreateCommandSessionConnection()
{
	HRESULT hResult;
	CDBPropSet oDBPropSet(DBPROPSET_DBINIT);
	CPropertiesConnectionDB oPropConDB;
	oPropConDB.SetPropertiesDB(oDBPropSet);

	// Свързваме се към базата данни
	hResult = m_oDataSource.Open(_T("SQLOLEDB.1"), &oDBPropSet);

	if (FAILED(hResult))
	{
		return FALSE;
	}

	// Отваряме сесия
	hResult = m_oSession.Open(m_oDataSource);

	if (FAILED(hResult))
	{
		return FALSE;
	}
	return TRUE;
}

void CCitiesTable::CloseCommandSessionConnection(CDataSource& oDataSource, CSession& oSession)
{
	Close();
	oSession.Close();
	oDataSource.Close();
}

BOOL CCitiesTable::SelectByID(const long lID, CITIES& recCities)
{
	CString strQuery;
	strQuery.Format(_T("SELECT * FROM CITIES WHERE ID = %d"), lID);

	ExecuteQuery(strQuery);

	if (MoveNext() == S_OK)
	{
		recCities = m_recCity;
	}
	else
	{
		return FALSE;
	}
	return TRUE;
}

BOOL CCitiesTable::SelectAll(CCitiesArray& oCitiesArray)
{
	HRESULT hResult;
	CString strQuery;

	if (FAILED(CreateCommandSessionConnection()))
	{
		return FALSE;
	}

	strQuery = _T("SELECT * FROM CITIES");

	if (FAILED(ExecuteQuery(strQuery)))
	{
		CloseCommandSessionConnection(m_oDataSource, m_oSession);

		return FALSE;
	}

	while (true)
	{
		hResult = MoveNext();
		if (hResult == S_OK)
		{
			CITIES* pCity = new CITIES();
			*pCity = m_recCity;

			oCitiesArray.Add(pCity);
		}
		else if (hResult == DB_S_ENDOFROWSET)
		{
			break;
		}
		else
		{
			CloseCommandSessionConnection(m_oDataSource, m_oSession);
			return FALSE;
		}
	}

	CloseCommandSessionConnection(m_oDataSource, m_oSession);

	return TRUE;
};

BOOL CCitiesTable::SelectWhereID(const long lID, CITIES& recCities)
{
	if (FAILED(CreateCommandSessionConnection()))
	{
		return FALSE;
	}

	if (FAILED(SelectByID(lID, recCities))) 
	{
		CloseCommandSessionConnection(m_oDataSource, m_oSession);

		return FALSE;
	}

	CloseCommandSessionConnection(m_oDataSource, m_oSession);

	return TRUE;
};

BOOL CCitiesTable::UpdateWhereID(const long lID, const CITIES& recCities)
{
	CITIES recCity;

	if (FAILED(CreateCommandSessionConnection()))
	{
		return FALSE;
	}

	if (FAILED(m_oSession.StartTransaction())) {
		CloseCommandSessionConnection(m_oDataSource, m_oSession);

		return FALSE;
	}

	if (FAILED(SelectByID(lID, recCity))) 
	{
		m_oSession.Abort();
		CloseCommandSessionConnection(m_oDataSource, m_oSession);

		return FALSE;
	}

	if (m_recCity.lUpdateCounter != recCities.lUpdateCounter)
	{
		m_oSession.Abort();
		CloseCommandSessionConnection(m_oDataSource, m_oSession);

		return FALSE;
	}

	m_recCity = recCities;
	m_recCity.lUpdateCounter += UPDATE_COUNTER_NUMBER;

	if (FAILED(SetData(SECOND_ACCESSOR)))
	{
		m_oSession.Abort();
		CloseCommandSessionConnection(m_oDataSource, m_oSession);

		return FALSE;
	}

	UpdateAll();
	m_oSession.Commit();
	CloseCommandSessionConnection(m_oDataSource, m_oSession);

	return TRUE;
};

BOOL CCitiesTable::Insert(const CITIES& recCities)
{
	HRESULT hResult;
	CString strQuery;

	if (FAILED(CreateCommandSessionConnection()))
	{
		return FALSE;
	}

	strQuery.Format(_T("SELECT TOP 0 * FROM CITIES"));

	if (FAILED(m_oSession.StartTransaction())) {
		CloseCommandSessionConnection(m_oDataSource, m_oSession);

		return FALSE;
	}

	if (FAILED(ExecuteQuery(strQuery)))
	{
		m_oSession.Abort();
		CloseCommandSessionConnection(m_oDataSource, m_oSession);

		return FALSE;
	}

	hResult = MoveNext();

	if (FAILED(hResult))
	{
		m_oSession.Abort();
		CloseCommandSessionConnection(m_oDataSource, m_oSession);

		return FALSE;
	}
	
	m_recCity = recCities;
	hResult = __super::Insert(SECOND_ACCESSOR);

	if (FAILED(hResult))
	{
		return FALSE;
	}

	UpdateAll();
	m_oSession.Commit();
	CloseCommandSessionConnection(m_oDataSource, m_oSession);

	return TRUE;
};

BOOL CCitiesTable::DeleteWhereID(const long lID)
{
	HRESULT hResult;
	if (FAILED(CreateCommandSessionConnection()))
	{
		return FALSE;
	}

	CITIES oCity;
	if (FAILED(m_oSession.StartTransaction())) {
		CloseCommandSessionConnection(m_oDataSource, m_oSession);

		return FALSE;
	}

	if (FAILED(SelectByID(lID, oCity)))
	{
		m_oSession.Abort();
		CloseCommandSessionConnection(m_oDataSource, m_oSession);

		return FALSE;
	}

	hResult = Delete();

	if (FAILED(hResult))
	{
		return FALSE;
	}

	UpdateAll();
	m_oSession.Commit();
	CloseCommandSessionConnection(m_oDataSource, m_oSession);

	return TRUE;
};