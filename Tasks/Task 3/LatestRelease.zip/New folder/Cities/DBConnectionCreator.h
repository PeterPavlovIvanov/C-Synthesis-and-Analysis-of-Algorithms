﻿#pragma once

#include "PropertiesConnectionDB.h"

#include "CitiesTable.h"

///<summary>Клас (с възможност за една инстанция) за отваряне и затваряне на връзката с DB</summary>
class CDBConnectionCreator
{
public:
	///<summary>Метод връщат инстанцията на класа</summary>
	static CDBConnectionCreator& GetInstance();

	///<summary>Оператор за присвояване - не присвоява</summary>
	void operator=(CDBConnectionCreator const&) = delete;

	///<summary>Отваряне на връзката с DB</summary>
	HRESULT CreateConnection();

	///<summary>Затваряне на връзката с DB</summary>
	void CloseConnection();

	///<summary>Геттър на datasource</summary>
	CDataSource& getDataSource();

private:
	///<summary>Конструктор</summary>
	CDBConnectionCreator(void) {}

	///<summary>инстанцията</summary>
	static CDBConnectionCreator m_instance;

	///<summary>DataSource</summary>
	CDataSource m_oDataSource;
};