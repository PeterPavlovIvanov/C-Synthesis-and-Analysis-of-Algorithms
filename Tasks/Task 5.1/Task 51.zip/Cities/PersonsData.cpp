﻿#include "stdafx.h"

#include "PersonsData.h"

#include "DBConnectionCreator.h"

#include "PhoneNumbersTable.h"

CPersonsData::CPersonsData()
{
};

BOOL CPersonsData::SelectAll(CPersonsArray& oPersonsArray)
{
	CString strTableName;
	strTableName.Format(_T("PERSONS"));

	CPersonsTable oPersonsTable(strTableName);

	BOOL hResult = oPersonsTable.SelectAll(oPersonsArray);

	return hResult;
};

BOOL CPersonsData::Insert(CNumbersPerson& oNumbersPerson)
{
	CSession oSession;
	CString strTableName;

	//Отваряме сесия
	if (FAILED(oSession.Open(CDBConnectionCreator::GetInstance().GetDataSource())))
		return FALSE;

	//Започваме транзакция
	if (FAILED(oSession.StartTransaction()))
	{
		return FALSE;
	}

	strTableName.Format(_T("PERSONS"));
	CPersonsTable oPersonsTable(strTableName, &oSession);

	if (oPersonsTable.Insert(oNumbersPerson.recPerson) == FALSE)
		return FALSE;

	strTableName.Format(_T("PHONE_NUMBERS"));
	CPhoneNumbersTable oPhoneNumbersTable(strTableName, &oSession);

	for (int i = 0; i < oNumbersPerson.oPhoneNumbersArray.GetCount(); i++)
	{
		PHONE_NUMBERS* pPhoneNumber = oNumbersPerson.oPhoneNumbersArray.GetAt(i);
		pPhoneNumber->lPersonID = oNumbersPerson.recPerson.lID;

		if (oPhoneNumbersTable.Insert(*pPhoneNumber) == FALSE)
			return FALSE;
	}

	oSession.Close();
	return TRUE;
};

BOOL CPersonsData::DeleteWhereID(int nID)
{
	CSession oSession;
	CString strTableName;
	CPhoneNumbersArray oPhoneNumbersArray;

	//Отваряме сесия
	if (FAILED(oSession.Open(CDBConnectionCreator::GetInstance().GetDataSource())))
		return FALSE;

	//Започваме транзакция
	if (FAILED(oSession.StartTransaction()))
	{
		return FALSE;
	}

	strTableName.Format(_T("PHONE_NUMBERS"));
	CPhoneNumbersTable oPhoneNumbersTable(strTableName, &oSession);

	if (oPhoneNumbersTable.SelectAllByPersonID(nID, oPhoneNumbersArray) == FALSE)
		return FALSE;

	for (int i = 0; i < oPhoneNumbersArray.GetCount(); i++)
	{
		if (oPhoneNumbersTable.DeleteWhereID(oPhoneNumbersArray.GetAt(i)->lID) == FALSE)
			return FALSE;
	}

	strTableName.Format(_T("PERSONS"));
	CPersonsTable oPersonsTable(strTableName, &oSession);

	if (oPersonsTable.DeleteWhereID(nID) == FALSE)
		return FALSE;

	oSession.Close();
	return TRUE;
};

BOOL CPersonsData::UpdatePerson(CNumbersPerson& oNumbersPerson)
{
	CSession oSession;
	CString strTableName;

	//Отваряме сесия
	if (FAILED(oSession.Open(CDBConnectionCreator::GetInstance().GetDataSource())))
		return FALSE;

	//Започваме транзакция
	if (FAILED(oSession.StartTransaction()))
	{
		return FALSE;
	}

	//Update-ваме person
	strTableName.Format(_T("PERSONS"));
	CPersonsTable oPersonsTable(strTableName, &oSession);

	if (oPersonsTable.UpdateWhereID(oNumbersPerson.recPerson.lID, oNumbersPerson.recPerson) == FALSE)
		return FALSE;

	//взимаме всички номери на абоната
	strTableName.Format(_T("PHONE_NUMBERS"));
	CPhoneNumbersTable oPhoneNumbersTable(strTableName, &oSession);

	//Проверяваме за Update/Insert
	for (int i = 0; i < oNumbersPerson.oPhoneNumbersArray.GetCount(); i++)
	{
		PHONE_NUMBERS* pPhoneNumber = oNumbersPerson.oPhoneNumbersArray.GetAt(i);
		pPhoneNumber->lPersonID = oNumbersPerson.recPerson.lID;

		//Insert
		if (pPhoneNumber->lID == 0)
		{
			if (oPhoneNumbersTable.Insert(*pPhoneNumber) == FALSE)
				return FALSE;
		}
		else
		{
			if (oPhoneNumbersTable.UpdateWhereID(pPhoneNumber->lID, *pPhoneNumber) == FALSE)
				return FALSE;
		}
	}

	//Commit-ваме досегашната транзакция за да добавим новите номера
	if (FAILED(oSession.Commit()))
		return FALSE;

	//Започваме транзакция за да проверим за изтрити номера
	if (FAILED(oSession.StartTransaction()))
		return FALSE;

	//Взимаме номерите на абоната от базата
	CPhoneNumbersArray oPhoneNumbersArray;
	oPhoneNumbersTable.SelectAllByPersonID(oNumbersPerson.recPerson.lID, oPhoneNumbersArray);

	//Проверяваме за Delete
	for (int i = 0; i < oPhoneNumbersArray.GetCount(); i++)
	{
		bool isDeleted = true;

		for (int j = 0; j < oNumbersPerson.oPhoneNumbersArray.GetCount(); j++)
		{	
			if (oPhoneNumbersArray.GetAt(i)->lID == oNumbersPerson.oPhoneNumbersArray.GetAt(j)->lID)
			{
				isDeleted = false;
				break;
			}	
		}
		
		if (isDeleted)
			if (oPhoneNumbersTable.DeleteWhereID(oPhoneNumbersArray.GetAt(i)->lID) == FALSE)
				return FALSE;
	}

	if (FAILED(oSession.Commit()))
		return FALSE;

	oSession.Close();
	return TRUE;
};

BOOL CPersonsData::SelectWhereID(int nID, CNumbersPerson& oNumbersPerson)
{
	CSession oSession;
	CString strTableName;

	strTableName.Format(_T("PERSONS"));
	CPersonsTable oPersonsTable(strTableName, &oSession);

	strTableName.Format(_T("PHONE_NUMBERS"));
	CPhoneNumbersTable oPhoneNumbersTable(strTableName, &oSession);

	if (FAILED(oSession.Open(CDBConnectionCreator::GetInstance().GetDataSource())))
		return FALSE;

	if (FAILED(oPersonsTable.SelectWhereID(nID, oNumbersPerson.recPerson)))
		return FALSE;

	if (FAILED(oPhoneNumbersTable.SelectAllByPersonID(nID, oNumbersPerson.oPhoneNumbersArray)))
		return FALSE;

	oSession.Close();
	return TRUE;
}

BOOL CPersonsData::InsertPhoneNumber(PHONE_NUMBERS & recPhoneNumber)
{
	CSession oSession;
	CString strTableName;
	strTableName.Format(_T("PHONE_NUMBERS"));

	//Отваряме сесия
	if (FAILED(oSession.Open(CDBConnectionCreator::GetInstance().GetDataSource())))
		return FALSE;

	//Започваме транзакция
	if (FAILED(oSession.StartTransaction()))
	{
		return FALSE;
	}

	CPhoneNumbersTable oPhoneNumbersTable(strTableName, &oSession);

	BOOL hResult = oPhoneNumbersTable.Insert(recPhoneNumber);

	oSession.Close();
	return hResult;
};