#pragma once

template<typename T>
class CAutoReleaseMemoryTypedPtrArray : public CTypedPtrArray<CPtrArray, T*>
{
	//Constructors
public:
	CAutoReleaseMemoryTypedPtrArray() 
	{

	}
	~CAutoReleaseMemoryTypedPtrArray() 
	{
		DeleteAllItems();
	}

	//Methods
public:
	void DeleteAllItems()
	{
		for (int i = 0; i < GetCount(); i++) 
		{
			delete GetAt(i);
		}
		RemoveAll();
	}

	void DeleteByIndex(int nIndex)
	{
		delete GetAt(nIndex);
		RemoveAt(nIndex);
	}
};