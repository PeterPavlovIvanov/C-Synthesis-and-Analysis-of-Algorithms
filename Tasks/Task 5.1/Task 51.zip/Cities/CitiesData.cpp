﻿#include "stdafx.h"

#include "CitiesData.h"

#include "DBConnectionCreator.h"

CCitiesData::CCitiesData()
{
};

BOOL CCitiesData::SelectAll(CCitiesArray& oCitiesArray)
{
	CString strTableName;
	strTableName.Format(_T("CITIES"));

	CCitiesTable oCitiesTable(strTableName);

	BOOL hResult = oCitiesTable.SelectAll(oCitiesArray);

	return hResult;
};

BOOL CCitiesData::Insert(CITIES& recCities) 
{
	CString strTableName;
	strTableName.Format(_T("CITIES"));

	CCitiesTable oCitiesTable(strTableName);

	BOOL hResult = oCitiesTable.Insert(recCities);

	return hResult;
};

BOOL CCitiesData::DeleteWhereID(int nID)
{
	CString strTableName;
	strTableName.Format(_T("CITIES"));

	CCitiesTable oCitiesTable(strTableName);

	BOOL hResult = oCitiesTable.DeleteWhereID(nID);

	return hResult;
};

BOOL CCitiesData::Update(const CITIES & recCity)
{
	CString strTableName;
	strTableName.Format(_T("CITIES"));

	CCitiesTable oCitiesTable(strTableName);

	BOOL hResult = oCitiesTable.UpdateWhereID(recCity.lID, recCity);

	return hResult;
};

BOOL CCitiesData::SelectWhereID(int nID, CITIES& recCity)
{
	CString strTableName;
	strTableName.Format(_T("CITIES"));

	CCitiesTable oCitiesTable(strTableName);

	BOOL hResult = oCitiesTable.SelectWhereID(nID, recCity);

	return hResult;
};