#include "stdafx.h"

#include <atlbase.h>

#include <atldbcli.h>

#include <atldbsch.h>

#include "Typedefs.h"

#include "PersonsTable.h"

CPersonsTable::CPersonsTable(CString strTableName, CSession* oSession) : CBaseTable(strTableName, oSession)
{

}
CPersonsTable::CPersonsTable(CString strTableName) : CBaseTable(strTableName)
{
};

PERSONS& CPersonsTable::GetRowSet()
{
	return m_recPerson;
};

long* CPersonsTable::GetUpdateCounter(PERSONS recPerson)
{
	return &(recPerson.lUpdateCounter);
};
