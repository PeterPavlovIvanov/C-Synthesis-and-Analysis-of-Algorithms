﻿#pragma once

#include <atldbcli.h>

#include "Typedefs.h"

#include "BaseTable.h"

class CCitiesAccessor
{
protected:
	CITIES m_recCity;

	BEGIN_ACCESSOR_MAP(CCitiesAccessor, ACCESSOR_COUNT)
		BEGIN_ACCESSOR(FIRST_ACCESSOR, true)
			COLUMN_ENTRY(FIRST_COLUMN, m_recCity.lID)
		END_ACCESSOR()

		BEGIN_ACCESSOR(FIRST_COLUMN, true)
			COLUMN_ENTRY(SECOND_COLUMN, m_recCity.lUpdateCounter)
			COLUMN_ENTRY(THIRD_COLUMN, m_recCity.szCityName)
			COLUMN_ENTRY(FOURTH_COLUMN, m_recCity.szRegion)
		END_ACCESSOR()
	END_ACCESSOR_MAP()
};

///<summary>Клас за работа с таблица CITIES</summary>
class CCitiesTable : public CBaseTable<CCitiesAccessor, CITIES>
{
	//Constructors
public:
	///<summary>Конструктор по име на таблицата и сесия</summary>
	CCitiesTable(CString strTableName, CSession* oSession);

	///<summary>Конструктор по име на таблицата</summary>
	CCitiesTable(CString strTableName);

	//Methods
private:
	///<summary>Взима rowset-а</summary>
	virtual CITIES& GetRowSet() override;

	///<summary>Взима update_counter-а на град</summary>
	///<param "recCity">Града от който се взима uprade_counter-с</summary>
	virtual long* GetUpdateCounter(CITIES& recCity) override;

};