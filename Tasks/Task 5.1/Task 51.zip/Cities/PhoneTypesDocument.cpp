// PhoneTypesDocument.cpp : implementation file
//

#include "stdafx.h"

#include "PhoneBook.h"

#include "PhoneTypesDocument.h"


// CPhoneTypesDocument

IMPLEMENT_DYNCREATE(CPhoneTypesDocument, CDocument)

CPhoneTypesDocument::CPhoneTypesDocument()
{
};

void CPhoneTypesDocument::OnUpdateAllViews(UpdateCodes eUpdateCode, PHONE_TYPES recPhoneType)
{
	UpdateAllViews(NULL, eUpdateCode, (CObject*)&recPhoneType);
}

BOOL CPhoneTypesDocument::SelectAll()
{
	return m_oPhoneTypesData.SelectAll(m_oPhoneTypesArray);
}

BOOL CPhoneTypesDocument::InsertPhoneType(PHONE_TYPES & recPhoneTypes)
{
	BOOL bResult = m_oPhoneTypesData.Insert(recPhoneTypes);

	if (bResult != TRUE)
	{
		return FALSE;
	}

	PHONE_TYPES* pPhoneType = new PHONE_TYPES();
	pPhoneType->lID = recPhoneTypes.lID;
	pPhoneType->lUpdateCounter = recPhoneTypes.lUpdateCounter;
	wcscpy_s(pPhoneType->szPhoneType, recPhoneTypes.szPhoneType);
	m_oPhoneTypesArray.Add(pPhoneType);

	UpdateCodes eUpdateCode = UpdateCodeInsert;
	OnUpdateAllViews(eUpdateCode, recPhoneTypes);
	return bResult;
}

BOOL CPhoneTypesDocument::DeleteByID(int nID)
{
	BOOL bResult = m_oPhoneTypesData.DeleteWhereID(nID);

	if (bResult != TRUE)
	{
		return FALSE;
	}

	for (int i = 0; i < m_oPhoneTypesArray.GetCount(); i++)
	{
		if (m_oPhoneTypesArray.GetAt(i)->lID == nID)
		{
			m_oPhoneTypesArray.DeleteByIndex(i);
		}
	}

	PHONE_TYPES recPhoneType;
	recPhoneType.lID = nID;

	UpdateCodes eUpdateCode = UpdateCodeDelete;
	OnUpdateAllViews(eUpdateCode, recPhoneType);
	return bResult;
}

BOOL CPhoneTypesDocument::UpdatePhoneType(const PHONE_TYPES& recPhoneType)
{
	BOOL bResult = m_oPhoneTypesData.Update(recPhoneType);
	
	if (bResult != TRUE)
	{
		return FALSE;
	}

	for (int i = 0; i < m_oPhoneTypesArray.GetCount(); i++)
	{
		if (m_oPhoneTypesArray.GetAt(i)->lID == recPhoneType.lID)
		{
			m_oPhoneTypesArray.GetAt(i)->lID = recPhoneType.lID;
			m_oPhoneTypesArray.GetAt(i)->lUpdateCounter = recPhoneType.lUpdateCounter;
			wcscpy_s(m_oPhoneTypesArray.GetAt(i)->szPhoneType, recPhoneType.szPhoneType);
			break;
		}
	}

	UpdateCodes eUpdateCode = UpdateCodeUpdate;
	OnUpdateAllViews(eUpdateCode, recPhoneType);
	return bResult;
};

BOOL CPhoneTypesDocument::SelectByID(int nID, PHONE_TYPES& recPhoneType)
{
	return m_oPhoneTypesData.SelectWhereID(nID, recPhoneType);
}

BOOL CPhoneTypesDocument::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;
	return TRUE;
}

CPhoneTypesDocument::~CPhoneTypesDocument()
{
}

BEGIN_MESSAGE_MAP(CPhoneTypesDocument, CDocument)
END_MESSAGE_MAP()


// CPhoneTypesDocument diagnostics

#ifdef _DEBUG
void CPhoneTypesDocument::AssertValid() const
{
	CDocument::AssertValid();
}

#ifndef _WIN32_WCE
void CPhoneTypesDocument::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif
#endif //_DEBUG

#ifndef _WIN32_WCE
// CPhoneTypesDocument serialization

void CPhoneTypesDocument::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}
#endif


// CPhoneTypesDocument commands
