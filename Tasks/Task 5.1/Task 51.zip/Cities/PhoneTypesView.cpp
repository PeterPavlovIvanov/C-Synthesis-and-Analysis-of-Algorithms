﻿// CPhoneTypesView.cpp : implementation file
//

#include "stdafx.h"

#include "PhoneBook.h"

#include "PhoneTypesView.h"

#include "PhoneTypesDocument.h"

#include "Typedefs.h"

#include "UpdateCodes.h"

#include "PhoneTypesDialog.h"

// CPhoneTypesView

#define FIRST__COLUMN 0
#define SECOND__COLUMN 1
#define THIRD__COLUMN 2

IMPLEMENT_DYNCREATE(CPhoneTypesView, CListView)

CPhoneTypesView::CPhoneTypesView()
{

}

CPhoneTypesView::~CPhoneTypesView()
{
}

BEGIN_MESSAGE_MAP(CPhoneTypesView, CListView)
	ON_COMMAND(INSERT_PHONE_TYPE_OPTION_ID, &CPhoneTypesView::OnPhoneTypesInsert)
	ON_COMMAND(VIEW_PHONE_TYPE_OPTION_ID, &CPhoneTypesView::OnView)
	ON_COMMAND(DELETE_PHONE_TYPE_OPTION_ID, &CPhoneTypesView::OnDelete)
	ON_COMMAND(UPDATE_PHONE_TYPE_OPTION_ID, &CPhoneTypesView::OnPhoneTypeUpdate)
	ON_WM_PAINT()
	ON_WM_CONTEXTMENU()
END_MESSAGE_MAP()

// CPhoneTypesView diagnostics

#ifdef _DEBUG
void CPhoneTypesView::AssertValid() const
{
	CListView::AssertValid();
}

#ifndef _WIN32_WCE
void CPhoneTypesView::Dump(CDumpContext& dc) const
{
	CListView::Dump(dc);
}

void CPhoneTypesView::OnInitialUpdate()
{
	m_ListCtrl.SetView(LVS_REPORT);

	m_ListCtrl.SetExtendedStyle(m_ListCtrl.GetExtendedStyle() | LVS_EX_FULLROWSELECT);

	m_ListCtrl.InsertColumn(FIRST__COLUMN, _T("PHONE TYPE"), LVCFMT_CENTER, COLUMN_WIDTH);
	m_ListCtrl.InsertColumn(SECOND__COLUMN, _T("ID"), LVCFMT_CENTER, COLUMN_WIDTH);

	CListView::OnInitialUpdate();

	if (GetDocument()->SelectAll() == FALSE)
		return;

	for (int i = 0; i < GetDocument()->GetPhoneTypesArray().GetCount(); i++)
	{
		PHONE_TYPES* recPhoneType = GetDocument()->GetPhoneTypesArray().GetAt(i);
		CString strID;
		strID.Format(_T("%d"), recPhoneType->lID);

		int nIndex = m_ListCtrl.InsertItem(FIRST__COLUMN, recPhoneType->szPhoneType);
		m_ListCtrl.SetItemText(nIndex, SECOND__COLUMN, strID);
		m_ListCtrl.SetItemData(nIndex, recPhoneType->lID);
	}
}
#endif
#endif //_DEBUG

void CPhoneTypesView::OnUpdate(CView * pSender, LPARAM lHint, CObject * pHint)
{
	CString strID;

	switch (lHint)
	{
	case (UpdateCodes::UpdateCodeUpdate) :
	{
		for (int i = 0; i < m_ListCtrl.GetItemCount(); i++)
		{
			PHONE_TYPES* pPhoneType = (PHONE_TYPES*)pHint;
			if (m_ListCtrl.GetItemData(i) == pPhoneType->lID)
			{
				strID.Format(_T("%d"), pPhoneType->lID);

				m_ListCtrl.SetItemText(i, FIRST__COLUMN, pPhoneType->szPhoneType);
				m_ListCtrl.SetItemText(i, SECOND__COLUMN, strID);

				break;
			}
		}
		break;
	}
	case (UpdateCodes::UpdateCodeInsert) :
	{
		PHONE_TYPES* pPhoneType = (PHONE_TYPES*)pHint;
		strID.Format(_T("%d"), pPhoneType->lID);

		int nIndex = m_ListCtrl.InsertItem(FIRST__COLUMN, pPhoneType->szPhoneType);
		m_ListCtrl.SetItemText(nIndex, SECOND__COLUMN, strID);
		m_ListCtrl.SetItemData(nIndex, pPhoneType->lID);

		break;
	}
	case (UpdateCodes::UpdateCodeDelete) :
	{
		for (int i = 0; i < m_ListCtrl.GetItemCount(); i++)
		{
			PHONE_TYPES* pPhoneType = (PHONE_TYPES*)pHint;
			if (m_ListCtrl.GetItemData(i) == pPhoneType->lID)
			{
				m_ListCtrl.DeleteItem(i);
				break;
			}
		}
	}
	default:
		break;
	}
	__super::OnUpdate(pSender, lHint, pHint);
};

CPhoneTypesDocument * CPhoneTypesView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CPhoneTypesDocument)));
	return (CPhoneTypesDocument*)m_pDocument;
};

//Методи които само викат документа
// ----------------
BOOL CPhoneTypesView::InsertPhoneType(PHONE_TYPES & recPhoneTypes)
{
	return GetDocument()->InsertPhoneType(recPhoneTypes);
};

BOOL CPhoneTypesView::UpdatePhoneType(const PHONE_TYPES & recPhoneType)
{
	return GetDocument()->UpdatePhoneType(recPhoneType);
};

BOOL CPhoneTypesView::DeletePhoneType(int nID)
{
	return GetDocument()->DeleteByID(nID);
};

BOOL CPhoneTypesView::SelectPhoneTypeByID(int nID, PHONE_TYPES& recPhoneType)
{
	return GetDocument()->SelectByID(nID, recPhoneType);
};

//Методи отварящи диалог или меню
// ----------------
void CPhoneTypesView::OnContextMenu(CWnd* pWnd, CPoint point)
{
	//Sample 01: Declarations
	CRect client_rect;
	CMenu MainMenu;

	//Get Mouse Click position and convert it to the Screen Co-ordinate
	GetClientRect(&client_rect);
	ClientToScreen(&client_rect);

	//Check the mouse pointer position is inside the client area
	if (client_rect.PtInRect(point))
	{
		//Create the Main Menu
		MainMenu.CreatePopupMenu();
		MainMenu.AppendMenu(MF_STRING, INSERT_PHONE_TYPE_OPTION_ID, _T("Insert"));
		MainMenu.AppendMenu(MF_STRING, UPDATE_PHONE_TYPE_OPTION_ID, _T("Update"));
		MainMenu.AppendMenu(MF_STRING, DELETE_PHONE_TYPE_OPTION_ID, _T("Delete"));
		MainMenu.AppendMenu(MF_STRING, VIEW_PHONE_TYPE_OPTION_ID, _T("View"));

		//Display the Popup Menu
		MainMenu.TrackPopupMenu(TPM_LEFTALIGN, point.x, point.y, this);
	}
	else
	{
		CWnd::OnContextMenu(pWnd, point);
	}

};

void CPhoneTypesView::OnPhoneTypesInsert()
{
	PHONE_TYPES recPhoneType;
	DialogModes eDialogMode = DialogModeInsert;
	CPhoneTypesDialog oDialog(eDialogMode, recPhoneType);

	if (oDialog.DoModal() == IDOK)
	{
		InsertPhoneType(recPhoneType);
	}
};

void CPhoneTypesView::OnView()
{
	//Взимаме документа
	CPhoneTypesDocument* pPhoneTypesDocument = GetDocument();

	//Взимаме select-натия град
	int nIndex = m_ListCtrl.GetSelectionMark();
	long lID = m_ListCtrl.GetItemData(nIndex);

	//взимаме актуалния град от базата и го запазваме в recPhoneType
	PHONE_TYPES recPhoneType;
	if (pPhoneTypesDocument->SelectByID(lID, recPhoneType) == FALSE)
		return;

	//Инициализираме диалога със съответните заглавие и полета
	DialogModes eDialogMode = DialogModeView;
	CPhoneTypesDialog oDialog(eDialogMode, recPhoneType);

	oDialog.DoModal();
};

void CPhoneTypesView::OnDelete()
{
	//Взимаме документа
	CPhoneTypesDocument* pPhoneTypesDocument = GetDocument();

	//Взимаме select-натия град
	int nIndex = m_ListCtrl.GetSelectionMark();
	long lID = m_ListCtrl.GetItemData(nIndex);

	//взимаме актуалния град от базата и го запазваме в recPhoneType
	PHONE_TYPES recPhoneType;
	if (pPhoneTypesDocument->SelectByID(lID, recPhoneType) == FALSE)
		return;

	//Инициализираме диалога със съответните заглавие и полета
	DialogModes eDialogMode = DialogModeDelete;
	CPhoneTypesDialog oDialog(eDialogMode, recPhoneType);

	if (oDialog.DoModal() == IDOK)
	{
		GetDocument()->DeleteByID(lID);
	}
};

void CPhoneTypesView::OnPhoneTypeUpdate()
{
	//Взимаме документа	
	CPhoneTypesDocument* pPhoneTypesDocument = GetDocument();

	//Взимаме ID на select-натия град
	int nIndex = m_ListCtrl.GetSelectionMark();
	long lID = m_ListCtrl.GetItemData(nIndex);

	//Взимаме актуалния град по ID и го запазваме в recPhoneType  
	PHONE_TYPES recPhoneType;
	if (pPhoneTypesDocument->SelectByID(lID, recPhoneType) == FALSE)
		return;

	//Инициализираме диалога със съответните заглавие и полета
	DialogModes eDialogMode = DialogModeUpdate;
	CPhoneTypesDialog oDialog(eDialogMode, recPhoneType);

	if (oDialog.DoModal() == IDOK)
	{
		UpdatePhoneType(recPhoneType);
	}
};
