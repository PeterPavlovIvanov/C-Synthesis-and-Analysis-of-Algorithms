﻿#include "stdafx.h"

#include <atlbase.h>

#include <atldbcli.h>

#include <atldbsch.h>

#include <typeinfo>

#include "Typedefs.h"

#include "CitiesTable.h"

#include "PropertiesConnectionDB.h"

#include "DBConnectionCreator.h"

CCitiesTable::CCitiesTable(CString strTableName, CSession* oSession) : CBaseTable(strTableName, oSession)
{
};

CCitiesTable::CCitiesTable(CString strTableName) : CBaseTable(strTableName)
{
};

CITIES & CCitiesTable::GetRowSet()
{
	return m_recCity;
};

long* CCitiesTable::GetUpdateCounter(CITIES& recCity)
{
	return &(m_recCity.lUpdateCounter);
};
