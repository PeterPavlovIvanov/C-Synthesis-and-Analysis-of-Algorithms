﻿#pragma once

#include "CitiesTable.h"

#include "Typedefs.h"

/////////////////////////////////////////////////////////////////////////////
// CCitiesData

///<summary>Клас с бизнес логика</summary>
class CCitiesData
{

	// Constructor / Destructor
	// ----------------
public:
	///<summary>Default-ен конструктор</summary>
	CCitiesData();

	//Methods
	// ----------------
public:
	///<summary>Функция която взима всички градове</summary>
	///<param = "oCitiesArray">Масив от градове в който се запазва резултата от SelectAll</param>
	BOOL SelectAll(CCitiesArray& oCitiesArray);

	///<summary>Функция която добавя град</summary>
	///<param = "recCities">Град за добавяне</param>
	///<returns>Успешно ли е добавен градътс</returns>
	BOOL Insert(CITIES& recCities);

	///<summary>Функция която изтрива град</summary>
	///<param = "nID">ID на града за изтриване</param>
	///<returns>Успешно ли е изтрит градът</returns>
	BOOL DeleteWhereID(int nID);

	///<summary>Функция която променя град</summary>
	///<param = "recCity">Променения град</param>
	///<returns>Успешно ли е променен градът</returns>
	BOOL Update( CITIES& recCity);

	///<summary>Функция която взима град</summary>
	///<param = "recCities">Хранилище в което се запазва резултата от SelectWhereID</param>
	///<returns>Успешно ли е взет градът</returns>
	BOOL SelectWhereID(int nID, CITIES& recCities);

	//Members
	// ----------------
private:
	///<summary>Инстанция на CCitiesTable върху която се извикват методи</summary>
	//CCitiesTable m_oCitiesTable;
};