﻿// PersonsDialog.cpp : implementation file
//

#include "stdafx.h"

#include "PhoneBook.h"

#include "PersonsDialog.h"

#include "afxdialogex.h"

#include "PhoneNumbersDialog.h"

// CPersonsDialog dialog

IMPLEMENT_DYNAMIC(CPersonsDialog, CDialog)

CPersonsDialog::CPersonsDialog(CNumbersPerson& oNumbersPerson, CCitiesArray* pCitiesArray, 
	DialogModes eDialogMode, CPhoneTypesArray* pPhoneTypesArray, CWnd* pParent /*=NULL*/)
	: CDialog(IDD_PERSONS_DIALOG, pParent), 
	m_oNumbersPerson(oNumbersPerson), m_oCitiesArray(*pCitiesArray), m_oPhoneTypesArray(*pPhoneTypesArray)
{
	switch (eDialogMode)
	{
	case DialogModeUpdate:
		m_strDlgCaption = _T("Update Person");
		break;
	case DialogModeDelete:
		m_strDlgCaption = _T("Are you sure you want to delete this Person?");
		break;
	case DialogModeView:
		m_strDlgCaption = _T("View Person");
		break;
	case DialogModeInsert:
		m_strDlgCaption = _T("Insert Person");
		break;
	};

	m_eDialogMode = eDialogMode;
};

CPersonsDialog::~CPersonsDialog()
{
};

void CPersonsDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT_PERSONS_FIRST_NAME, editFirstName);
	DDX_Control(pDX, IDC_EDIT_PERSONS_MIDDLE_NAME, editMiddleName);
	DDX_Control(pDX, IDC_EDIT_PERSONS_LAST_NAME, editLastName);
	DDX_Control(pDX, IDC_EDIT_PERSONS_UCN, editUCN);
	DDX_Control(pDX, IDC_COMBO_PERSONS_CITY, comboCity);
	DDX_Control(pDX, IDC_EDIT_PERSONS_ADDRESS, editAddress);
	DDX_Control(pDX, IDC_LIST_PERSONS_NUMBERS, listCtrlPhoneNumbers);
};

void CPersonsDialog::DialogToBuf()
{
	CString strWindowText;

	editFirstName.GetWindowText(strWindowText);
	wcscpy_s(m_oNumbersPerson.recPerson.szFirstName, strWindowText);

	editMiddleName.GetWindowText(strWindowText);
	wcscpy_s(m_oNumbersPerson.recPerson.szMiddleName, strWindowText);

	editLastName.GetWindowText(strWindowText);
	wcscpy_s(m_oNumbersPerson.recPerson.szLastName, strWindowText);

	editUCN.GetWindowText(strWindowText);
	wcscpy_s(m_oNumbersPerson.recPerson.szUCN, strWindowText);

	editAddress.GetWindowText(strWindowText);
	wcscpy_s(m_oNumbersPerson.recPerson.szAddress, strWindowText);

	long lIndex = comboCity.GetCurSel();
	m_oNumbersPerson.recPerson.lCityID = comboCity.GetItemData(lIndex);

};

BOOL CPersonsDialog::OnInitDialog()
{
	__super::OnInitDialog();
	SetWindowText(m_strDlgCaption);
	

	//Edit controls
	SetDlgItemText(IDC_EDIT_PERSONS_FIRST_NAME, m_oNumbersPerson.recPerson.szFirstName);
	SetDlgItemText(IDC_EDIT_PERSONS_LAST_NAME, m_oNumbersPerson.recPerson.szLastName);
	SetDlgItemText(IDC_EDIT_PERSONS_MIDDLE_NAME, m_oNumbersPerson.recPerson.szMiddleName);
	SetDlgItemText(IDC_EDIT_PERSONS_ADDRESS, m_oNumbersPerson.recPerson.szAddress);
	SetDlgItemText(IDC_EDIT_PERSONS_UCN, m_oNumbersPerson.recPerson.szUCN);
	
	//ComboBox
	for (int i = 0; i < m_oCitiesArray.GetCount(); i++)
	{
		int nIndex = comboCity.AddString(m_oCitiesArray.GetAt(i)->szCityName);
		comboCity.SetItemData(nIndex, m_oCitiesArray.GetAt(i)->lID);
	}

	//CListCtrl
	listCtrlPhoneNumbers.SetView(LVS_REPORT);
	listCtrlPhoneNumbers.SetExtendedStyle(listCtrlPhoneNumbers.GetExtendedStyle() | LVS_EX_FULLROWSELECT);
	listCtrlPhoneNumbers.InsertColumn(ZERO_COLUMN, _T("NUMBER"), LVCFMT_CENTER, COLUMN_WIDTH);
	listCtrlPhoneNumbers.InsertColumn(ZERO_COLUMN, _T("PHONE_TYPE"), LVCFMT_CENTER, COLUMN_WIDTH / 2);

	if (m_eDialogMode != DialogModes::DialogModeInsert)
	{
		CString strCityName;
		for (int i = 0; i < m_oCitiesArray.GetCount(); i++)
		{
			if (m_oNumbersPerson.recPerson.lCityID == m_oCitiesArray.GetAt(i)->lID)
			{
				strCityName.Format(_T("%s"), m_oCitiesArray.GetAt(i)->szCityName);
				int lIndex = comboCity.SelectString(0, strCityName);
				comboCity.SetCurSel(lIndex);
				break;
			}
		}

		for (int i = 0; i < m_oNumbersPerson.oPhoneNumbersArray.GetCount(); i++)
		{
			PHONE_NUMBERS* recPhoneNumber = m_oNumbersPerson.oPhoneNumbersArray.GetAt(i);
			CString strPhoneType;
			TakePhoneType(m_oPhoneTypesArray.GetAt(i)->lID, strPhoneType, &m_oPhoneTypesArray);

			int nIndex = listCtrlPhoneNumbers.InsertItem(ZERO_COLUMN, strPhoneType);
			listCtrlPhoneNumbers.SetItemText(nIndex, FIRST_COLUMN, recPhoneNumber->szNumber);
			listCtrlPhoneNumbers.SetItemData(nIndex, recPhoneNumber->lID);
		}
	}

	if (m_eDialogMode == DialogModes::DialogModeView || m_eDialogMode == DialogModes::DialogModeDelete)
	{
		editAddress.SetReadOnly();
		editLastName.SetReadOnly();
		editMiddleName.SetReadOnly();
		editFirstName.SetReadOnly();
		editUCN.SetReadOnly();
		comboCity.EnableWindow(FALSE);	
	}
	return TRUE;
};

BEGIN_MESSAGE_MAP(CPersonsDialog, CDialog)
	ON_BN_CLICKED(IDOK, &CPersonsDialog::OnBnClickedOk)
	ON_NOTIFY(NM_RCLICK, IDC_LIST_PERSONS_NUMBERS, &CPersonsDialog::OnRclickList)
	ON_WM_PAINT()
	ON_WM_CONTEXTMENU()
	ON_COMMAND(INSERT_PHONE_NUMBERS_OPTION_ID, &CPersonsDialog::OnPhoneNumbersInsert)
	ON_COMMAND(UPDATE_PHONE_NUMBERS_OPTION_ID, &CPersonsDialog::OnPhoneNumbersUpdate)
	ON_COMMAND(DELETE_PHONE_NUMBERS_OPTION_ID, &CPersonsDialog::OnPhoneNumbersDelete)
END_MESSAGE_MAP()

// CPersonsDialog message handlers
void CPersonsDialog::OnRclickList(NMHDR * pNMHDR, LRESULT * pResult)
{
	//ContextMenu
	CRect client_rect;
	GetClientRect(&client_rect);
	ClientToScreen(&client_rect);

	CPoint point;
	point.x = GetCurrentMessage()->pt.x;
	point.y = GetCurrentMessage()->pt.y;

	if (client_rect.PtInRect(point))
	{
		CMenu* menu = new CMenu();
		menu->CreatePopupMenu();

		menu->AppendMenu(MF_STRING, INSERT_PHONE_NUMBERS_OPTION_ID, _T("Insert"));
		menu->AppendMenu(MF_STRING, UPDATE_PHONE_NUMBERS_OPTION_ID, _T("Update"));
		menu->AppendMenu(MF_STRING, DELETE_PHONE_NUMBERS_OPTION_ID, _T("Delete"));

		menu->TrackPopupMenu(TPM_LEFTALIGN, point.x, point.y, this);
		listCtrlPhoneNumbers.SetMenu(menu);
	}
};

void CPersonsDialog::OnBnClickedOk()
{
	DialogToBuf();
	CDialog::OnOK();
};

void CPersonsDialog::TakePhoneType(long lID, CString & strPhoneType, CPhoneTypesArray* oPhoneTypesArray)
{
	for (int i = 0; i < oPhoneTypesArray->GetCount(); i++)
	{
		if (oPhoneTypesArray->GetAt(i)->lID == lID)
		{
			strPhoneType.Format(_T("%s"), oPhoneTypesArray->GetAt(i)->szPhoneType);
			return;
		}
	}
};

void CPersonsDialog::OnPhoneNumbersInsert()
{
	DialogModes eDialogMode = DialogModeInsert;
	PHONE_NUMBERS* recPhoneNumber = new PHONE_NUMBERS();

	CPhoneNumbersDialog oPhoneNumbersDialog(eDialogMode, *recPhoneNumber, &m_oPhoneTypesArray);
	
	if (oPhoneNumbersDialog.DoModal() != IDOK)
		return;

	//enter in oNumbersPerson
	m_oNumbersPerson.oPhoneNumbersArray.Add(recPhoneNumber);

	//enter in listctrl
	CString strPhoneType;
	TakePhoneType(recPhoneNumber->lPhoneTypeID, strPhoneType, &m_oPhoneTypesArray);

	int nIndex = listCtrlPhoneNumbers.InsertItem(m_oNumbersPerson.oPhoneNumbersArray.GetCount(), ZERO_COLUMN);
	listCtrlPhoneNumbers.SetItemText(nIndex, ZERO_COLUMN, strPhoneType);
	listCtrlPhoneNumbers.SetItemText(nIndex, FIRST_COLUMN, recPhoneNumber->szNumber);
};

void CPersonsDialog::OnPhoneNumbersUpdate()
{
	DialogModes eDialogMode = DialogModeUpdate;
	PHONE_NUMBERS* pPhoneNumber = new PHONE_NUMBERS();

	//Взимаме select-натия Телефон
	int nIndex = listCtrlPhoneNumbers.GetSelectionMark();
	long lID = listCtrlPhoneNumbers.GetItemData(nIndex);

	//Запазваме го в recPhoneNumber
	for (int i = 0; i < m_oNumbersPerson.oPhoneNumbersArray.GetCount(); i++)
	{
		if (m_oNumbersPerson.oPhoneNumbersArray.GetAt(i)->lID == lID)
		{
			pPhoneNumber = m_oNumbersPerson.oPhoneNumbersArray.GetAt(i);
			break;
		}
	}

	//Инициализираме диалога Phone Numbers и го извикваме
	CPhoneNumbersDialog oPhoneNumbersDialog(eDialogMode, *pPhoneNumber, &m_oPhoneTypesArray);
	if (oPhoneNumbersDialog.DoModal() != IDOK)
		return;

	//Обновяваме в m_oNumbersPerson
	for (int i = 0; i < m_oNumbersPerson.oPhoneNumbersArray.GetCount(); i++)
	{
		if (m_oNumbersPerson.oPhoneNumbersArray.GetAt(i)->lID == pPhoneNumber->lID)
		{
			m_oNumbersPerson.oPhoneNumbersArray.SetAt(i, pPhoneNumber);
			break;
		}
	}

	//Взимаме името на телефонния тип 
	CString strPhoneType;
	TakePhoneType(pPhoneNumber->lPhoneTypeID, strPhoneType, &m_oPhoneTypesArray);

	//Обновяваме телефонът във view-то
	listCtrlPhoneNumbers.SetItemText(nIndex, ZERO_COLUMN, strPhoneType);
	listCtrlPhoneNumbers.SetItemText(nIndex, FIRST_COLUMN, pPhoneNumber->szNumber);
};

void CPersonsDialog::OnPhoneNumbersDelete()
{
	DialogModes eDialogMode = DialogModeDelete;
	PHONE_NUMBERS recPhoneNumber;

	//Взимаме select-натия Телефон
	int nIndex = listCtrlPhoneNumbers.GetSelectionMark();
	long lID = listCtrlPhoneNumbers.GetItemData(nIndex);

	//Запазваме го в recPhoneNumber
	for (int i = 0; i < m_oNumbersPerson.oPhoneNumbersArray.GetCount(); i++)
	{
		if (m_oNumbersPerson.oPhoneNumbersArray.GetAt(i)->lID == lID)
		{
			recPhoneNumber = *(m_oNumbersPerson.oPhoneNumbersArray.GetAt(i));
			break;
		}
	}

	//Отваряме диалога и го извикваме
	CPhoneNumbersDialog oPhoneNumbersDialog(eDialogMode, recPhoneNumber, &m_oPhoneTypesArray);
	if(oPhoneNumbersDialog.DoModal() != IDOK)
		return;

	//Изтриваме в oNumbersPerson
	for (int i = 0; i < m_oNumbersPerson.oPhoneNumbersArray.GetCount(); i++)
	{
		if (recPhoneNumber.lID == m_oNumbersPerson.oPhoneNumbersArray.GetAt(i)->lID)
		{
			m_oNumbersPerson.oPhoneNumbersArray.DeleteByIndex(i);
		}
	}

	//Изтриваме номерът от list control-ата
	listCtrlPhoneNumbers.DeleteItem(nIndex);
};
