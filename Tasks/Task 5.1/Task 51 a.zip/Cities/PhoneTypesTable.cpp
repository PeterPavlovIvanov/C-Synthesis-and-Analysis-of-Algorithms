#include "stdafx.h"

#include <atlbase.h>

#include <atldbcli.h>

#include <atldbsch.h>

#include "Typedefs.h"

#include "PhoneTypesTable.h"

CPhoneTypesTable::CPhoneTypesTable(CString strTableName, CSession* oSession) 
	: CBaseTable(strTableName, oSession)
{
};

CPhoneTypesTable::CPhoneTypesTable(CString strTableName) : CBaseTable(strTableName)
{
};

PHONE_TYPES & CPhoneTypesTable::GetRowSet()
{
	return m_recPhoneType;
};

long* CPhoneTypesTable::GetUpdateCounter(PHONE_TYPES& recPhoneType)
{
	return &(recPhoneType.lUpdateCounter);
};