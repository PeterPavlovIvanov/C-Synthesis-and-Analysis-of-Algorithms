#pragma once
enum DialogModes
{
	DialogModeInsert = 1,
	DialogModeUpdate = 2,
	DialogModeView = 3,
	DialogModeDelete = 4
};