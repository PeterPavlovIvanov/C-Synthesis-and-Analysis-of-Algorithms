﻿#include "stdafx.h"

#include "PhoneTypesData.h"

#include "DBConnectionCreator.h"

CPhoneTypesData::CPhoneTypesData()
{
};

BOOL CPhoneTypesData::SelectAll(CPhoneTypesArray& oPhoneTypesArray)
{
	CString strTableName;

	CPhoneTypesTable oPhoneTypesTable;

	BOOL hResult = oPhoneTypesTable.SelectAll(oPhoneTypesArray);

	return hResult;
};

BOOL CPhoneTypesData::Insert(PHONE_TYPES& recPhoneTypes)
{
	CString strTableName;

	CPhoneTypesTable oPhoneTypesTable;

	BOOL hResult = oPhoneTypesTable.Insert(recPhoneTypes);

	return hResult;
};

BOOL CPhoneTypesData::DeleteWhereID(int nID)
{
	CString strTableName;

	CPhoneTypesTable oPhoneTypesTable;

	BOOL hResult = oPhoneTypesTable.DeleteWhereID(nID);

	return hResult;
};

BOOL CPhoneTypesData::Update(PHONE_TYPES & recPhoneType)
{
	CString strTableName;

	CPhoneTypesTable oPhoneTypesTable;

	BOOL hResult = oPhoneTypesTable.UpdateWhereID(recPhoneType.lID, recPhoneType);

	return hResult;
};

BOOL CPhoneTypesData::SelectWhereID(int nID, PHONE_TYPES& recPhoneType)
{
	CString strTableName;

	CPhoneTypesTable oPhoneTypesTable;

	BOOL hResult = oPhoneTypesTable.SelectWhereID(nID, recPhoneType);

	return hResult;
};