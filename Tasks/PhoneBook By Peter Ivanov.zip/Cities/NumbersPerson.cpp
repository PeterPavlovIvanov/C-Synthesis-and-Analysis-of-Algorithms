#include "stdafx.h"

#include "NumbersPerson.h"

CNumbersPerson::CNumbersPerson()
{
};
