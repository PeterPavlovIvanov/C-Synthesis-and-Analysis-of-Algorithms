﻿#pragma once

#include "PhoneTypesTable.h"

#include "Typedefs.h"

/////////////////////////////////////////////////////////////////////////////
// CPhoneTypesData

///<summary>Клас с бизнес логика</summary>
class CPhoneTypesData
{

	// Constructor / Destructor
	// ----------------
public:
	///<summary>Default-ен конструктор</summary>
	CPhoneTypesData();

	//Methods
	// ----------------
public:
	///<summary>Функция която взима всички телефонни типове</summary>
	///<param = "m_oPhoneTypesArray">Масив от телефонни типове в който се запазва резултата от SelectAll</param>
	BOOL SelectAll(CPhoneTypesArray& oPhoneTypesArray);

	///<summary>Функция която добавя телефонен тип</summary>
	///<param = "recPhoneTypes">Телефонен тип за добавяне</param>
	///<returns>Успешно ли е добавен телефонния тип</returns>
	BOOL Insert(PHONE_TYPES& recPhoneTypes);

	///<summary>Функция която изтрива телефонен тип</summary>
	///<param = "nID">ID на телефонния тип за изтриване</param>
	///<returns>Успешно ли е изтрит телефонният тип</returns>
	BOOL DeleteWhereID(int nID);

	///<summary>Функция която променя телефонен тип</summary>
	///<param = "recPhoneType">Променения телефонен тип</param>
	///<returns>Успешно ли е променен телефонният тип</returns>
	BOOL Update(PHONE_TYPES& recPhoneType);

	///<summary>Функция която взима телефонен тип</summary>
	///<param = "recPhoneTypes">Хранилище в което се запазва резултата от SelectWhereID</param>
	///<returns>Успешно ли е взет телефонният тип</returns>
	BOOL SelectWhereID(int nID, PHONE_TYPES& recPhoneTypes);
};