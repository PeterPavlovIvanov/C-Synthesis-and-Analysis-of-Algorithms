﻿#pragma once

#include "BaseTable.h"

///<summary>Клас ацесор за телефонните типове</summary>
class CPhoneTypesAccessor
{
protected:
	PHONE_TYPES m_recPhoneType;

	BEGIN_ACCESSOR_MAP(CPhoneTypesAccessor, ACCESSOR_COUNT)
		BEGIN_ACCESSOR(FIRST_ACCESSOR, true)
		COLUMN_ENTRY(FIRST_COLUMN, m_recPhoneType.lID)
		END_ACCESSOR()

		BEGIN_ACCESSOR(FIRST_COLUMN, true)
		COLUMN_ENTRY(SECOND_COLUMN, m_recPhoneType.lUpdateCounter)
		COLUMN_ENTRY(THIRD_COLUMN, m_recPhoneType.szPhoneType)
		END_ACCESSOR()
	END_ACCESSOR_MAP()
};

///<summary>Клас за работа с таблица PHONE_TYPES</summary>
class CPhoneTypesTable : public CBaseTable<CPhoneTypesAccessor, PHONE_TYPES>
{
	//Constructors
public:
	///<summary>Конструктор по сесия</summary>
	CPhoneTypesTable(CSession* oSession);

	///<summary>Default Конструктор</summary>
	CPhoneTypesTable( );

	//Methods
private:
	///<summary>Взима rowset-а</summary>
	virtual PHONE_TYPES& GetRowSet() override;

	///<summary>Взима update_counter-а на телефонен тип</summary>
	///<param "recPhoneType">Телефонният тип от който се взима uprade_counter-с</summary>
	virtual long* GetUpdateCounter(PHONE_TYPES& recPhoneType) override;

	///<summary>Премахва ненужните space-ове, добавени от MoveNext()</summary>
	virtual void Trim() override;
};