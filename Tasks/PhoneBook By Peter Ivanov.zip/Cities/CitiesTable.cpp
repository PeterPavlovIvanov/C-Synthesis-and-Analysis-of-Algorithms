﻿#include "stdafx.h"

#include <atlbase.h>

#include <atldbcli.h>

#include <atldbsch.h>

#include <typeinfo>

#include "Typedefs.h"

#include "CitiesTable.h"

#include "PropertiesConnectionDB.h"

#include "DBConnectionCreator.h"

CCitiesTable::CCitiesTable(CSession* oSession) : CBaseTable(oSession)
{
	this->m_strTableName = CITIES_TABLE_NAME;
};

CCitiesTable::CCitiesTable() : CBaseTable()
{
	this->m_strTableName = CITIES_TABLE_NAME;
};

CITIES & CCitiesTable::GetRowSet()
{
	return m_recCity;
};

long* CCitiesTable::GetUpdateCounter(CITIES& recCity)
{
	return &(m_recCity.lUpdateCounter);
};

void CCitiesTable::Trim()
{
	wchar_t cSpace =  ' ';
	CString strCityName = m_recCity.szCityName, strRegion = m_recCity.szRegion;
	int nIndex = strCityName.GetLength() - FIX_TO_LAST_INDEX;

	//премахваме space-овете от името на града
	while (m_recCity.szCityName[nIndex] == cSpace) {
		m_recCity.szCityName[nIndex] = NULL;
		nIndex--;
	}

	nIndex = strRegion.GetLength() - FIX_TO_LAST_INDEX;

	//премахваме space-овете от региона на града
	while (m_recCity.szRegion[nIndex] == cSpace) {
		m_recCity.szRegion[nIndex] = NULL;
		nIndex--;
	}
};
