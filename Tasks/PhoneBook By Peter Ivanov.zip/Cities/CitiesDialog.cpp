﻿#include "stdafx.h"

#include "PhoneBook.h"

#include "CitiesDialog.h"

#include "afxdialogex.h"

#include "Typedefs.h"

#include "CitiesView.h"

// CCitiesDialog dialog

IMPLEMENT_DYNAMIC(CCitiesDialog, CDialog)

CCitiesDialog::CCitiesDialog(CITIES& recCity, DialogModes eDialogMode, CWnd* pParent /*=NULL*/) 
	: CDialog(IDD_CITIES_DIALOG, pParent), m_recCity(recCity)
{
	m_eDialogMode = eDialogMode;
	switch (eDialogMode)
	{
	case DialogModeUpdate:
		m_strDlgCaption = _T("Update city");
		break;
	case DialogModeDelete:
		m_strDlgCaption = _T("Are you sure you want to delete this city?");
		break;
	case DialogModeView:
		m_strDlgCaption = _T("View city");
		break;
	case DialogModeInsert:
		m_strDlgCaption = _T("Insert city");
		break;
	};
	this->m_strDlgCaption = m_strDlgCaption;
}

CCitiesDialog::~CCitiesDialog()
{
};

void CCitiesDialog::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDB_CITIES_NAME, editCityName);
	DDX_Control(pDX, IDC_EDB_CITIES_REGION, editRegion);
};

BOOL CCitiesDialog::OnInitDialog()
{
	__super::OnInitDialog();
	SetWindowText(m_strDlgCaption);
	if (m_eDialogMode == DialogModes::DialogModeView || m_eDialogMode == DialogModes::DialogModeDelete)
	{
		editCityName.SetReadOnly();
		editRegion.SetReadOnly();
	}
	SetDlgItemText(IDC_EDB_CITIES_NAME, m_recCity.szCityName);
	SetDlgItemText(IDC_EDB_CITIES_REGION, m_recCity.szRegion);
	return TRUE;
}

BEGIN_MESSAGE_MAP(CCitiesDialog, CDialog)
	ON_BN_CLICKED(IDOK, &CCitiesDialog::OnBnClickedOk)
	ON_BN_CLICKED(IDCANCEL, &CCitiesDialog::OnBnClickedCancel)
END_MESSAGE_MAP()

void CCitiesDialog::OnBnClickedOk()
{
	if (DialogToBuf() != TRUE)
		return;
	CDialog::OnOK();
};

void CCitiesDialog::OnBnClickedCancel()
{
	CDialog::OnCancel();
};

void CCitiesDialog::CleanFields()
{
	m_recCity.lID = NEW_LONG;
	m_recCity.lUpdateCounter = NEW_LONG;
	wcscpy_s(m_recCity.szCityName, _T(""));
	wcscpy_s(m_recCity.szRegion, _T(""));
};

void CCitiesDialog::ValidateStringOnlyLetters(CString strWindowText, CString & message, BOOL & bResult, CString strFieldName)
{
	if (strWindowText.GetLength() < BASE_STRING_LENGHT)
	{
		message.AppendFormat(_T("\n %s must be atleast %d symbols long."), strFieldName, BASE_STRING_LENGHT);
		bResult = FALSE;
	}

	for (int i = 0; i < strWindowText.GetLength(); i++)
	{
		if (!((strWindowText.GetAt(i) >= 'a' && strWindowText.GetAt(i) <= 'z') ||
			(strWindowText.GetAt(i) >= 'A' && strWindowText.GetAt(i) <= 'Z') || strWindowText.GetAt(i) == ' '))
		{
			message.AppendFormat(_T("\n %s must have only letters."), strFieldName, BASE_STRING_LENGHT);
			bResult = FALSE;
			break;
		}
	}
};

BOOL CCitiesDialog::DialogToBuf()
{
	CString strWindowText;
	CString message;
	BOOL bResult = TRUE;

	//име на града
	editCityName.GetWindowText(strWindowText);
	ValidateStringOnlyLetters(strWindowText, message, bResult, _T("City Name"));
	wcscpy_s(m_recCity.szCityName, strWindowText);

	//регион на града
	editRegion.GetWindowText(strWindowText);
	ValidateStringOnlyLetters(strWindowText, message, bResult, _T("Region"));
	wcscpy_s(m_recCity.szRegion, strWindowText);

	if (!bResult)
	{
		AfxMessageBox(message);
		return FALSE;
	}

	return TRUE;
};