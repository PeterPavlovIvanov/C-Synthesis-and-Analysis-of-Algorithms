﻿#pragma once

///<summary>Enum за код за обновяване на view</summary>
enum UpdateCodes 
{
	UpdateCodeInsert = 1,
	UpdateCodeUpdate = 2,
	UpdateCodeDelete = 3 
};